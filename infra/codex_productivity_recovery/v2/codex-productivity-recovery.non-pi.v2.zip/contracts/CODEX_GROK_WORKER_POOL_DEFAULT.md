# Codex → Grok 后台工人池（默认热路径）

**默认：** 派 N 路 Grok headless（CREATE_NO_WINDOW）  
**非默认：** 可见窗 Typeahead / dual delivery（门铃，仅用户点名）

## 本机隔离默认

- 本机默认走 Windows host；只读 common-contract 由公共 launcher 在 runtime 下创建 detached 临时 Git worktree，结束时检查无写入并移除。
- 有写入时只允许具名 candidate root／精确 write domain，不把公共仓库根当临时沙箱。
- Docker、Docker Compose 与 Docker 容器默认禁止。daemon 未启动是正常状态，不是待修故障。
- 只有具名、特殊、高价值且非容器方案不能取得同等效果时，才可同时提供 `-AllowExceptionalDocker` 与不少于 20 字符的 `-DockerJustification`；最内层 worker 也会复验。结束后必须退出 Docker。

## 一条命令

```powershell
C:\Users\xx363\CodexLaunchers\Invoke-Codex-GrokWorkerPool.ps1 -N 4 -Prompt "任务正文" -Cwd "工作目录"
# 或 PromptFile:
C:\Users\xx363\CodexLaunchers\Invoke-Codex-GrokWorkerPool.ps1 -N 4 -PromptFile D:\path\task.md -Cwd E:\repo
```

唯一公共入口是上面的 launcher。D 盘 bridge 是已封印的内部实现，不直接调用：

```powershell
D:\XINAO_RESEARCH_RUNTIME\tools\grok-worker-pool\bridge\Invoke-CodexDispatchGrokWorkerPool.ps1
```

运行包由同目录上层 `runtime-manifest.v1.json` 封印；公共 launcher 在认证、quota
或模型调用前核对完整文件集与 SHA。已退役的
`Grok_Admin_Isolated\workspace` 不再是任何活动依赖。

## OAuth 硬边界

冷启动、access token 约 6 小时、裸 `401`、旧报错或别的 profile 状态，都不准弹浏览器。
派工若报 `GROK_AUTHENTICATED_PROFILE_AUTH_REQUIRED`，先用同一公共 launcher、同一
`.grok-bg-workers` 通用工人传输/凭据 profile 做一次零模型 `-SelectionOnly` 复验。该
profile 不定义科学角色、任务来源或路线。只有复验仍精确失败，并且本次已证
`auth.json` 缺失/为空或出现 `invalid_grant / RefreshTokenRejected`，才允许一次 OAuth。
静默刷新成功或 selection 通过时，OAuth 被禁止，继续诊断下一层。

不得再手写或直接调用 `grok login --oauth`。唯一恢复入口是：

```powershell
# 默认只做零模型准入诊断，不启动浏览器
C:\Users\xx363\CodexLaunchers\Invoke-GrokWorkerOAuthRecovery.ps1

# 只有诊断回执 oauth_allowed=true 时，才可由同一入口执行恢复
C:\Users\xx363\CodexLaunchers\Invoke-GrokWorkerOAuthRecovery.ps1 -StartOAuth
```

该入口会在真正启动浏览器前再次执行同 profile `SelectionOnly`；只要静默刷新已经恢复，
第二次复验会硬拒绝 OAuth。它不复制、不打印凭据内容，也不回退到 `~\.grok`。

## 当前恢复身份

- live 运行真值只有 `D:\XINAO_RESEARCH_RUNTIME\tools\grok-worker-pool\runtime-manifest.v1.json` 及其封印的 15 个 bridge 文件；公共 launcher 每次在认证、quota 和模型接触前核验它。
- 当前冷恢复载体是 `E:\XINAO_RESEARCH_WORKSPACES\S\infra\codex_productivity_recovery\v2\codex-productivity-recovery.non-pi.v2.zip`，其 `manifest.v2.json` 同时封装公共入口、OAuth 恢复入口、operator 合同、live runtime manifest 与 15 个精确 transport 文件。
- `D:\XINAO_RESEARCH_RUNTIME\state\human-capabilities\worker-pool-recovery` 下的日期目录只保留当日事故与修复历史，不是当前恢复源，即使旧收据曾写 `verified_current` 也不能越过当前 manifest。
- selector release 从当前 S 仓的 `pyproject.toml`、`uv.lock` 与 `uv run python scripts/build_selector_release.py ...` 重建；裸 PATH Python 和日期快照都不是 selector 依赖真值。

恢复不能停在复制文件。恢复后先由公共 launcher 完成 15 文件核验和 fresh `-SelectionOnly`，再在 Docker 未运行的基线做一次真实 Grok dispatch；只有这两个消费者都通过才算恢复。

## 证据

- `D:\XINAO_RESEARCH_RUNTIME\state\grok_worker_pool\latest.json`
- `D:\XINAO_RESEARCH_RUNTIME\state\codex_dispatch_grok_worker_pool\latest.json`
- `D:\XINAO_RESEARCH_RUNTIME\readback\zh\grok_worker_pool_latest.md`

## 禁止当默认

- Send-CodexToGrokDualDelivery / ManagedVisible Typeahead
- 任何普通隔离、测试或 WorkerPool 为方便而自行启动 Docker
- Docker 容器内读桌面 `.lnk`
- Dify `docker-worker-1`
