# Codex → Grok 后台工人池（按需能力入口）

这个文件定义普通 Grok 的成熟 transport、隔离、认证、恢复和回读。在当前 S 窗口自己的
工程、实验控制、证据、恢复和共享 effect 职责锥内，普通 Grok 是可分离正收益劳动的默认
入口；宽度按净收益动态取零、一或多，不需要用户逐次批准。这个劳动默认不等于所有任务、
所有研究或所有 S 窗口的默认 cognition 路线：world-owning Sol 的研究不因该入口存在而
被改写成 supervisor/worker 流程，task-fit 事实也可以支持 Terra/Luna/native/direct 例外。

**选中本能力后的普通形态：** 派 N 路 Grok headless（CREATE_NO_WINDOW）  
**独立旁路：** 可见窗 Typeahead / dual delivery（门铃，仅用户点名）

## 本机隔离默认

- 本机默认走 Windows host；只读 common-contract 由公共 launcher 在 runtime 下创建 detached 临时 Git worktree，结束时检查无写入并移除。
- 有写入时只允许具名 candidate root／精确 write domain，不把公共仓库根当临时沙箱。
- Docker、Docker Compose 与 Docker 容器默认禁止。daemon 未启动是正常状态，不是待修故障。
- 只有具名、特殊、高价值且非容器方案不能取得同等效果时，才可同时提供 `-AllowExceptionalDocker` 与不少于 20 字符的 `-DockerJustification`；最内层 worker 也会复验。结束后必须退出 Docker。

## 一条命令

```powershell
C:\Users\xx363\CodexLaunchers\Invoke-Codex-GrokWorkerPool.ps1 -N 4 -Prompt "任务正文" -Cwd "工作目录"
# 或 PromptFile:
C:\Users\xx363\CodexLaunchers\Invoke-Codex-GrokWorkerPool.ps1 -N 4 -PromptFile D:\path\task.md -Cwd E:\repo
```

普通直连与 `-SelectionOnly` 省略 `-Model` 时都固定解析为当前全机默认
`grok-4.6`。只有密封 package 的 manifest 已绑定精确模型，或执行明确的恢复/回滚验证时，
才传显式 `-Model`；不得把 4.5、Composer 或历史 beta 名称重新带回普通默认。

唯一公共入口是上面的 launcher。D 盘 bridge 是已封印的内部实现，不直接调用：

```powershell
D:\XINAO_RESEARCH_RUNTIME\tools\grok-worker-pool\bridge\Invoke-CodexDispatchGrokWorkerPool.ps1
```

运行包由同目录上层 `runtime-manifest.v1.json` 封印；公共 launcher 在认证、quota
或模型调用前核对完整文件集与 SHA。已退役的
`Grok_Admin_Isolated\workspace` 不再是任何活动依赖。

## 选中 Grok 后，失败先修 Grok

公共 launcher 一旦失败，会在原始错误之前输出一行
`CODEX_GROK_REPAIR_FIRST_FAILURE: {...}`，其中 JSON schema 是
`xinao.grok.repair_first_failure.v1`。调用 AI 必须读取其中的
`failure_class`、`calling_ai_required_action` 与 `retry_same_public_entry`：修复具名的 Grok
模型/目录、认证 profile、封印 runtime、调用合同或 transport 后，用同一公共入口重试并回读。

该回执固定声明 `failure_is_provider_substitution_evidence=false`、
`native_codex_subagent_substitution_allowed=false`。因此不能因为 Grok 这次失败，就让 Codex
自己的子代理、Terra 或 Luna 接走已经选中的包。只有以下事实会释放重新选路：任务在选中
Grok 前就存在 task-fit/capability mismatch；明确 Pause/Stop；修复需要新的账号、秘密或重大
外部 effect；或有界修复和同入口复验已经证明该 Grok 路线不可用，且当前父合同允许改道。

模型失败时，不复用记忆中的旧模型名，也不静默任选另一个模型；取 fresh authenticated
catalog 与 active routing policy 的精确交集，再由同入口生成新 selection receipt。失败回执
本身不是改道事实，也不证明父任务完成。

## OAuth 硬边界

冷启动、access token 约 6 小时、裸 `401`、旧报错或别的 profile 状态，都不准弹浏览器。
派工若报 `GROK_AUTHENTICATED_PROFILE_AUTH_REQUIRED`，先用同一公共 launcher、同一
`.grok-bg-workers` 通用工人传输/凭据 profile 做一次零模型 `-SelectionOnly` 复验。该
profile 不定义科学角色、任务来源或路线。只有复验仍精确失败，并且本次已证
`auth.json` 缺失/为空或出现 `invalid_grant / RefreshTokenRejected`，才允许一次 OAuth。
静默刷新成功或 selection 通过时，OAuth 被禁止，继续诊断下一层。

不得再手写或直接调用 `grok login --oauth`。唯一恢复入口是：

```powershell
# 默认只做零模型准入诊断，不启动浏览器
C:\Users\xx363\CodexLaunchers\Invoke-GrokWorkerOAuthRecovery.ps1

# 只有诊断回执 oauth_allowed=true 时，才可由同一入口执行恢复
C:\Users\xx363\CodexLaunchers\Invoke-GrokWorkerOAuthRecovery.ps1 -StartOAuth
```

该入口会在真正启动浏览器前再次执行同 profile `SelectionOnly`；只要静默刷新已经恢复，
第二次复验会硬拒绝 OAuth。它不复制、不打印凭据内容，也不回退到 `~\.grok`。

## 当前恢复身份

- live 运行真值只有 `D:\XINAO_RESEARCH_RUNTIME\tools\grok-worker-pool\runtime-manifest.v1.json` 及其封印的 16 个 bridge 文件；公共 launcher 每次在认证、quota 和模型接触前核验它。
- 当前冷恢复载体是 `E:\XINAO_RESEARCH_WORKSPACES\S\infra\codex_productivity_recovery\v2\codex-productivity-recovery.non-pi.v2.zip`，其 `manifest.v2.json` 同时封装公共入口、OAuth 恢复入口、operator 合同、live runtime manifest 与 16 个精确 transport 文件。
- `D:\XINAO_RESEARCH_RUNTIME\state\human-capabilities\worker-pool-recovery` 下的日期目录只保留当日事故与修复历史，不是当前恢复源，即使旧收据曾写 `verified_current` 也不能越过当前 manifest。
- selector release 从当前 S 仓的 `pyproject.toml`、`uv.lock` 与 `uv run python scripts/build_selector_release.py ...` 重建；裸 PATH Python 和日期快照都不是 selector 依赖真值。

恢复不能停在复制文件。恢复后先由公共 launcher 完成 16 文件核验和 fresh `-SelectionOnly`，再在 Docker 未运行的基线做一次真实 Grok dispatch；只有这两个消费者都通过才算恢复。

## 证据

- `D:\XINAO_RESEARCH_RUNTIME\state\grok_worker_pool\latest.json`
- `D:\XINAO_RESEARCH_RUNTIME\state\codex_dispatch_grok_worker_pool\latest.json`
- `D:\XINAO_RESEARCH_RUNTIME\readback\zh\grok_worker_pool_latest.md`

## 不得取得认知默认权

- 仅因任务复杂、额度充足或本入口存在就自动派工
- 让 S 用 Grok 复制、审批或 steering 已任命 world-owning Sol 的认识
- 把 transport receipt、worker terminal 或多数票提升成 epistemic adoption、正式 effect 或父完成
- Send-CodexToGrokDualDelivery / ManagedVisible Typeahead
- 任何普通隔离、测试或 WorkerPool 为方便而自行启动 Docker
- Docker 容器内读桌面 `.lnk`
- Dify `docker-worker-1`
