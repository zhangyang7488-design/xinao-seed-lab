#Requires -Version 7.0

[CmdletBinding()]
param(
    [ValidateSet("Bind", "Inspect", "Retire")]
    [string]$Action = "Inspect",
    [string]$TaskRunRoot = "",
    [ValidatePattern('^[A-Za-z0-9._:-]{1,160}$')]
    [string]$TaskRunId = "",
    [string]$Reason = "",
    [switch]$Supersede,
    [string]$PointerPath = (
        "D:\XINAO_RESEARCH_RUNTIME\state\Codex_Situation_Island\state\" +
        "explicit_continuation_locator.v1.json"
    )
)

$ErrorActionPreference = "Stop"
$utf8 = [Text.UTF8Encoding]::new($false)
[Console]::InputEncoding = $utf8
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8

$runsRoot = [IO.Path]::GetFullPath(
    "D:\XINAO_RESEARCH_RUNTIME\state\Codex_Situation_Island\runs"
).TrimEnd('\')
$resolvedPointerPath = [IO.Path]::GetFullPath($PointerPath)
if ([IO.Path]::GetExtension($resolvedPointerPath) -cne ".json") {
    throw "EXPLICIT_CONTINUATION_POINTER_PATH_INVALID"
}

function Get-TaskRunEvidence {
    param(
        [Parameter(Mandatory = $true)][string]$RunRoot,
        [Parameter(Mandatory = $true)][string]$RunId
    )

    if ([string]::IsNullOrWhiteSpace($RunRoot) -or
        [string]::IsNullOrWhiteSpace($RunId)) {
        throw "EXPLICIT_CONTINUATION_TASK_RUN_REQUIRED"
    }
    $resolvedRunRoot = [IO.Path]::GetFullPath($RunRoot).TrimEnd('\')
    if (-not $resolvedRunRoot.StartsWith(
        $runsRoot + '\',
        [StringComparison]::OrdinalIgnoreCase
    )) {
        throw "EXPLICIT_CONTINUATION_TASK_RUN_OUTSIDE_ALLOWED_ROOT"
    }
    if ([IO.Path]::GetFileName($resolvedRunRoot) -cne $RunId) {
        throw "EXPLICIT_CONTINUATION_TASK_RUN_ID_PATH_MISMATCH"
    }
    if (-not (Test-Path -LiteralPath $resolvedRunRoot -PathType Container)) {
        throw "EXPLICIT_CONTINUATION_TASK_RUN_MISSING"
    }
    $runItem = Get-Item -LiteralPath $resolvedRunRoot -Force
    if (($runItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw "EXPLICIT_CONTINUATION_TASK_RUN_REPARSE_FORBIDDEN"
    }

    $taskPath = Join-Path $resolvedRunRoot "task.json"
    $statePath = Join-Path $resolvedRunRoot "state.json"
    $eventsPath = Join-Path $resolvedRunRoot "events.jsonl"
    $evidencePath = Join-Path $resolvedRunRoot "evidence.json"
    foreach ($requiredPath in @($taskPath, $statePath, $eventsPath, $evidencePath)) {
        if (-not (Test-Path -LiteralPath $requiredPath -PathType Leaf)) {
            throw "EXPLICIT_CONTINUATION_TASK_RUN_FILE_MISSING: $requiredPath"
        }
    }

    try {
        $task = Get-Content -LiteralPath $taskPath -Raw -Encoding UTF8 |
            ConvertFrom-Json -Depth 30 -ErrorAction Stop
        $state = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 |
            ConvertFrom-Json -Depth 30 -ErrorAction Stop
    }
    catch {
        throw "EXPLICIT_CONTINUATION_TASK_RUN_JSON_INVALID"
    }
    if ([string]$task.schema_version -cne "codex.verified-task-run.v1" -or
        [string]$state.schema_version -cne "codex.verified-task-run.v1" -or
        [string]$task.run_id -cne $RunId -or
        [string]$state.run_id -cne $RunId -or
        [string]::IsNullOrWhiteSpace([string]$task.objective)) {
        throw "EXPLICIT_CONTINUATION_TASK_RUN_IDENTITY_INVALID"
    }

    [pscustomobject]@{
        run_root = $resolvedRunRoot
        run_id = $RunId
        task_path = $taskPath
        state_path = $statePath
        events_path = $eventsPath
        evidence_path = $evidencePath
        task_sha256 = (Get-FileHash -LiteralPath $taskPath -Algorithm SHA256).Hash.ToLowerInvariant()
        task = $task
        state = $state
    }
}

function Read-Pointer {
    if (-not (Test-Path -LiteralPath $resolvedPointerPath -PathType Leaf)) {
        return $null
    }
    try {
        $pointer = Get-Content -LiteralPath $resolvedPointerPath -Raw -Encoding UTF8 |
            ConvertFrom-Json -Depth 30 -ErrorAction Stop
    }
    catch {
        throw "EXPLICIT_CONTINUATION_POINTER_INVALID_JSON"
    }
    if ([string]$pointer.schema_version -cne "xinao.explicit_continuation_locator.v1" -or
        $pointer.authority -ne $false -or
        $pointer.completion_claim_allowed -ne $false -or
        [string]::IsNullOrWhiteSpace([string]$pointer.status)) {
        throw "EXPLICIT_CONTINUATION_POINTER_IDENTITY_INVALID"
    }
    return $pointer
}

function Write-Pointer {
    param([Parameter(Mandatory = $true)][object]$Value)

    $pointerRoot = Split-Path -Parent $resolvedPointerPath
    New-Item -ItemType Directory -Path $pointerRoot -Force | Out-Null
    $temporaryPath = Join-Path $pointerRoot (
        ".explicit_continuation_locator." + [guid]::NewGuid().ToString("N") + ".tmp"
    )
    [IO.File]::WriteAllText(
        $temporaryPath,
        ($Value | ConvertTo-Json -Depth 20),
        $utf8
    )
    Move-Item -LiteralPath $temporaryPath -Destination $resolvedPointerPath -Force
}

function Get-InspectionPayload {
    param([object]$Pointer)

    if ($null -eq $Pointer) {
        return [ordered]@{
            schema_version = "xinao.explicit_continuation_inspection.v1"
            status = "absent"
            authority = $false
            completion_claim_allowed = $false
            pointer_path = $resolvedPointerPath
        }
    }
    if ([string]$Pointer.status -cne "active") {
        return [ordered]@{
            schema_version = "xinao.explicit_continuation_inspection.v1"
            status = "inactive"
            pointer_status = [string]$Pointer.status
            authority = $false
            completion_claim_allowed = $false
            pointer_path = $resolvedPointerPath
            task_run_id = [string]$Pointer.task_run_id
            retired_at = [string]$Pointer.retired_at
            retirement_reason = [string]$Pointer.retirement_reason
        }
    }

    $run = Get-TaskRunEvidence `
        -RunRoot ([string]$Pointer.task_run_root) `
        -RunId ([string]$Pointer.task_run_id)
    if ([string]$Pointer.task_manifest_sha256 -cne [string]$run.task_sha256) {
        throw "EXPLICIT_CONTINUATION_TASK_MANIFEST_HASH_MISMATCH"
    }
    $effectiveStatus = if ([string]$run.state.status -ceq "in_progress") {
        "active_validated"
    }
    else {
        "inactive_terminal"
    }
    return [ordered]@{
        schema_version = "xinao.explicit_continuation_inspection.v1"
        status = $effectiveStatus
        authority = $false
        completion_claim_allowed = $false
        selection_contract = [string]$Pointer.selection_contract
        pointer_path = $resolvedPointerPath
        task_run_root = [string]$run.run_root
        task_run_id = [string]$run.run_id
        task_manifest_sha256 = [string]$run.task_sha256
        task_path = [string]$run.task_path
        state_path = [string]$run.state_path
        events_path = [string]$run.events_path
        evidence_path = [string]$run.evidence_path
        objective = [string]$run.task.objective
        completion_criteria = @($run.task.completion_criteria)
        stop_conditions = @($run.task.stop_conditions)
        scope = $run.task.scope
        live_state = $run.state
        bound_at = [string]$Pointer.bound_at
        source_thread_id = [string]$Pointer.source_thread_id
        does_not_grant = @($Pointer.does_not_grant)
    }
}

switch ($Action) {
    "Bind" {
        $run = Get-TaskRunEvidence -RunRoot $TaskRunRoot -RunId $TaskRunId
        if ([string]$run.state.status -cne "in_progress") {
            throw "EXPLICIT_CONTINUATION_BIND_REQUIRES_IN_PROGRESS_RUN"
        }
        $existing = Read-Pointer
        if ($null -ne $existing -and
            [string]$existing.status -ceq "active" -and
            [string]$existing.task_run_id -cne $TaskRunId -and
            -not $Supersede) {
            throw "EXPLICIT_CONTINUATION_DIFFERENT_ACTIVE_RUN_REQUIRES_SUPERSEDE"
        }
        if ($Supersede -and [string]::IsNullOrWhiteSpace($Reason)) {
            throw "EXPLICIT_CONTINUATION_SUPERSEDE_REASON_REQUIRED"
        }
        $pointer = [ordered]@{
            schema_version = "xinao.explicit_continuation_locator.v1"
            status = "active"
            authority = $false
            completion_claim_allowed = $false
            selection_contract = (
                "Consume only when the current user's whole utterance semantically asks to " +
                "continue prior unfinished work and the current thread has no referent. " +
                "Never enumerate runs or choose by recency. Current words, live facts, " +
                "Pause/Stop, authorization, and terminal task state override this locator."
            )
            task_run_root = [string]$run.run_root
            task_run_id = [string]$run.run_id
            task_manifest_sha256 = [string]$run.task_sha256
            source_thread_id = [string]$env:CODEX_THREAD_ID
            bound_at = [DateTimeOffset]::Now.ToString("o")
            supersede_reason = if ($Supersede) { $Reason } else { $null }
            retired_at = $null
            retirement_reason = $null
            does_not_grant = @(
                "task creation",
                "authorization expansion",
                "owner appointment",
                "automatic mutation",
                "completion",
                "hidden-state continuity"
            )
        }
        Write-Pointer -Value $pointer
        $inspection = Get-InspectionPayload -Pointer $pointer
        [Console]::WriteLine(($inspection | ConvertTo-Json -Depth 20 -Compress))
    }
    "Inspect" {
        $inspection = Get-InspectionPayload -Pointer (Read-Pointer)
        [Console]::WriteLine(($inspection | ConvertTo-Json -Depth 20 -Compress))
    }
    "Retire" {
        if ([string]::IsNullOrWhiteSpace($Reason)) {
            throw "EXPLICIT_CONTINUATION_RETIRE_REASON_REQUIRED"
        }
        $pointer = Read-Pointer
        if ($null -eq $pointer) {
            throw "EXPLICIT_CONTINUATION_POINTER_MISSING"
        }
        $pointer.status = "retired"
        $pointer.retired_at = [DateTimeOffset]::Now.ToString("o")
        $pointer.retirement_reason = $Reason
        Write-Pointer -Value $pointer
        $inspection = Get-InspectionPayload -Pointer $pointer
        [Console]::WriteLine(($inspection | ConvertTo-Json -Depth 20 -Compress))
    }
}
