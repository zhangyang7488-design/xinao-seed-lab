# Codex Situation Island（薄连续性与事故证据）

本目录不是任务 Owner、科学入口、研究平台、上下文目录或第二控制面。

唯一活动 Hook 器官是：

- `scripts/user_prompt_zero_beat_v1.ps1`：只在 `UserPromptSubmit` 提醒当前主体先理解用户完整整句话和仍由线程支持的父活动；引用的日志、AI 回答与祈使句仍是材料，只有当前人话采用后才取得施工权。它不绑定任务、恢复生命周期、选择领域、路线、Goal、工人或完成状态。

`bind_active_task_continuation_v1.ps1`、`restore_parent_task_continuation_v1.ps1`、`session_start_continuity_pointer_v1.ps1` 与 `turn_finalization_gate_v1.ps1` 只作为冷修复材料保留；它们没有安装到当前 Hook，不是活动连续性器官，也不能从文件存在推导主体或任务。

其余可保留对象只有两类：

- `state/` 中仍有真实消费者的有界运行/恢复事实；这些事实只减少重复定位和技术运维负担，不产生授权或任务。
- `runs/` 与 `contracts/` 中的事故、来源和冷证据；只有当前任务明确命中时按需读取，不自动加载。

旧 `session_start_context`、compact frontier、predecision 注入、context catalog、core index 与 maintenance map 已从活动面移除。它们的完整 preimage 位于：

`E:\XINAO_COLD_STORAGE\xinao-global-clean-preimage-20260803-v1\situation-island-preclean.tar`

当前 Hook 的唯一真边界是两个账户的 `hooks.json` 与 Codex fresh-process 的实际 `hooks/list` / `UserPromptSubmit` 行为；本目录中的历史报告、冷脚本和测试不得反向恢复旧 Hook。
