# Codex Situation Island（薄情境与事故证据）

本目录不是任务 Owner、科学入口、研究平台、长期记忆或第二控制面。

当前 A/B 共用的活动 Hook 源码只有：

`E:\XINAO_RESEARCH_WORKSPACES\S\scripts\codex_situation_context_hook.py`

它承载两个互相受限的消费者：

- `UserPromptSubmit`：短 `HUMAN_WORDS_BEFORE_ARTIFACTS_V2` 在前，随后是紧凑、机械、非权威的 RuntimeObservation。观察描述 Hook 子进程、实际 cwd、Git 与活动规则文件；事件自报字段单独标记，权限和工具面未测得就保持 UNKNOWN。它不读取或回显用户 prompt，不从仓库状态生成任务。
- `SessionStart(source=resume|compact)`：只读取当前 exact 小写 UUID session 下、由显式管理器写入且未退役、未超过 7 天热窗口的 provisional CurrentSituation。不存在、损坏、过大、过期、link/redirect 或 tombstone 都 fail-open；它不枚举 session、不选“最新”、不消费 task-run frontier，也不恢复旧生命周期。

唯一 checkpoint 写入口是：

`E:\XINAO_RESEARCH_WORKSPACES\S\scripts\manage_current_situation.py`

它只接受显式 `initialize`、`apply`、`inspect`、`retire`。NO_MATERIAL_CHANGE 不落盘；MATERIAL_REVISION 使用 generation/hash CAS；被替换或退役的前像只进入同 session 的冷回执。checkpoint 始终 `provisional=true`、`authority=false`，不能授权行动、证明完成或证明“同一个主体”。

checkpoint 是会被下一次模型调用看见的明文上下文；禁止写入 token、密码、API key、cookie 或其他秘密。目录继承本机 ACL，不是跨 Windows 用户的秘密保险箱。

旧 `scripts/user_prompt_zero_beat_v1.ps1` 保留原字节，但已经从活动 Hook 退役，只用于精确回滚。`bind_active_task_continuation_v1.ps1`、`restore_parent_task_continuation_v1.ps1`、`session_start_continuity_pointer_v1.ps1` 与 `turn_finalization_gate_v1.ps1` 继续只是冷修复材料；新的 resume/compact reader 不恢复它们。

`scripts/manage_explicit_continuation_locator_v1.ps1` 仍是用户明确要求继续、当前线程又没有 referent 时的按需 locator；它不是 Hook，也不与 CurrentSituation 自动互转。

当前 checkpoint 根是 `state/current_situation/sessions/<exact-session-id>/`。旧 compact frontier 不再是该器官的来源。本次替换的所有精确 preimage、退役说明与 restore 脚本位于：

`recovery/situation-production-integration-20260811/`

更早的完整 preimage 仍位于：

`E:\XINAO_COLD_STORAGE\xinao-global-clean-preimage-20260803-v1\situation-island-preclean.tar`

生产事实只由 S 提交、共享 `hooks.json` / `config.toml`、A/B fresh `hooks/list`、JSON-stdio readback 和真实后续轨迹共同证明。文件存在、测试绿色或 checkpoint 内容不能反向取得任务权。
