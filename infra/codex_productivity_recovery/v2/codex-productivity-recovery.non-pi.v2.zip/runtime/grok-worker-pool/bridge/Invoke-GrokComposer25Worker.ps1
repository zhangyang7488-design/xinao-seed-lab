#Requires -Version 7.0
<#
Compatibility locator for pre-4.6 callers only. New callers and the sealed
WorkerPool use Invoke-GrokModelWorker.ps1.
#>

& (Join-Path $PSScriptRoot "Invoke-GrokModelWorker.ps1") @args
