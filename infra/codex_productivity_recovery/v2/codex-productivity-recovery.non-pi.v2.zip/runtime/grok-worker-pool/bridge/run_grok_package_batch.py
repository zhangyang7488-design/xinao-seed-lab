#!/usr/bin/env python3
"""Run one bounded heterogeneous Grok package batch through singleton contracts."""

from __future__ import annotations

import argparse
from concurrent.futures import FIRST_COMPLETED, Future, ThreadPoolExecutor, wait
import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tempfile
import time
from typing import Any, Callable, Mapping, Sequence
import uuid


DIRECT_ROUTE_TRANSPORT_ID = "direct-grok-worker-pool"
DIRECT_ROUTE_PROVIDER_ID = "grok_acpx_headless"
DIRECT_ROUTE_PROFILE_REF = "grok.com.cached_profile"
EXPECTED_PACKAGE_IDENTITY_SCHEMA = "xinao.worker_package_identity.v2"
EXPECTED_PACKAGE_BATCH_SCHEMA = "xinao.worker_package_batch.v3"
EXPECTED_DISPATCH_ENVELOPE_SCHEMA = "xinao.worker_dispatch_envelope.v2"
EXPECTED_LOGICAL_CANDIDATE_CONSUMER_ID = "worker_candidate_producer"
EXPECTED_DIRECT_ATTEMPT_CONSUMER_ID = "direct_grok_worker_pool"
EXPECTED_LOGICAL_CANDIDATE_EFFECT_CONTRACT = {
    "schema_version": "xinao.worker_candidate_effect_contract.v1",
    "effect_kind": "candidate_artifact_write",
    "output_boundary": "allowed_output_root",
    "authority": False,
    "completion_claim_allowed": False,
}
WINDOWLESS_CREATIONFLAGS = (
    getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
)


def _require_dispatch_contract_pin(contract: Any) -> None:
    """Fail on selector API/schema drift instead of inventing compatibility."""

    expected = {
        "PACKAGE_IDENTITY_SCHEMA": EXPECTED_PACKAGE_IDENTITY_SCHEMA,
        "PACKAGE_BATCH_SCHEMA": EXPECTED_PACKAGE_BATCH_SCHEMA,
        "DISPATCH_ENVELOPE_SCHEMA": EXPECTED_DISPATCH_ENVELOPE_SCHEMA,
        "LOGICAL_CANDIDATE_CONSUMER_ID": EXPECTED_LOGICAL_CANDIDATE_CONSUMER_ID,
        "LOGICAL_CANDIDATE_EFFECT_CONTRACT": (
            EXPECTED_LOGICAL_CANDIDATE_EFFECT_CONTRACT
        ),
    }
    for field, expected_value in expected.items():
        observed = getattr(contract, field, None)
        if observed != expected_value:
            raise RuntimeError(
                "S dispatch_economics contract pin drifted: "
                f"field={field};expected={expected_value!r};observed={observed!r}"
            )
    for name in (
        "build_dispatch_outcome_event",
        "claim_dispatch_route",
        "plan_package_frontier",
        "validate_candidate_consumer_binding",
        "validate_dispatch_envelope",
        "validate_dispatch_route_claim",
    ):
        if not callable(getattr(contract, name, None)):
            raise RuntimeError(
                f"S dispatch_economics contract seam missing: callable={name}"
            )


def _same_path(left: Path, right: Path) -> bool:
    return os.path.normcase(str(left)) == os.path.normcase(str(right))


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
    except ValueError:
        return False
    return True


def _contains_reparse_component(path: Path) -> bool:
    cursor = path
    reparse_flag = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    while True:
        try:
            if cursor.is_symlink():
                return True
            is_junction = getattr(cursor, "is_junction", None)
            if callable(is_junction) and is_junction():
                return True
            attributes = int(getattr(os.lstat(cursor), "st_file_attributes", 0))
            if attributes & reparse_flag:
                return True
        except OSError:
            return True
        if cursor.parent == cursor:
            return False
        cursor = cursor.parent


def _require_exact_candidate_cwd(
    *,
    package: dict[str, Any],
    candidate_cwd: Path,
    selector_root: Path,
    runtime_root: Path,
) -> Path:
    """Recheck an S-admitted candidate boundary immediately before spawn.

    This is deliberately not an admission policy.  The only allow-base decision
    comes from S ``validate_candidate_consumer_binding``; this helper protects
    the returned exact path against drift, aliasing, and reparse TOCTOU.
    """

    logical = str(package.get("allowed_output_root") or "").strip()
    if not logical:
        raise ValueError("candidate allowed_output_root is empty")
    if any(part in {".", ".."} for part in logical.replace("\\", "/").split("/")):
        raise ValueError("candidate allowed_output_root contains dot path traversal")
    lexical = Path(os.path.abspath(logical))
    bound = Path(os.path.abspath(os.fspath(candidate_cwd)))
    if not _same_path(lexical, bound):
        raise ValueError("candidate effective cwd drifted from allowed_output_root")
    if not bound.is_dir():
        raise ValueError(
            f"candidate effective cwd is not an existing directory: {bound}"
        )
    if _contains_reparse_component(bound):
        raise ValueError(
            "candidate effective cwd traverses a symlink, junction, or reparse point"
        )
    physical = bound.resolve(strict=True)
    if not _same_path(bound, physical):
        raise ValueError("candidate effective cwd resolves outside its exact boundary")

    source_cwd = Path(str(package.get("cwd") or "")).resolve(strict=True)
    if _is_within(physical, source_cwd):
        raise ValueError("candidate effective cwd must be isolated from source cwd")
    grok_repo = Path(__file__).resolve().parents[1]
    if _is_within(physical, grok_repo):
        raise ValueError("candidate effective cwd cannot be inside the Grok repository")
    selector = selector_root.resolve(strict=True)
    if _is_within(physical, selector):
        raise ValueError(
            "candidate effective cwd cannot be inside the selector repository"
        )
    runtime = runtime_root.resolve(strict=False)
    runtime_state = runtime / "state"
    if _same_path(physical, runtime) or _is_within(physical, runtime_state):
        raise ValueError("candidate effective cwd cannot be a runtime authority root")
    return physical


def _candidate_cwds_from_binding(
    *,
    binding: dict[str, Any],
    packages: dict[str, dict[str, Any]],
    route_choice_sha256: str,
    physical_consumer_id: str,
    selector_root: Path,
    runtime_root: Path,
) -> dict[str, Path]:
    if (
        binding.get("schema_version") != "xinao.worker_candidate_consumer_binding.v1"
        or binding.get("leg") != "A"
        or binding.get("logical_consumer_id") != EXPECTED_LOGICAL_CANDIDATE_CONSUMER_ID
        or binding.get("logical_effect_contract")
        != EXPECTED_LOGICAL_CANDIDATE_EFFECT_CONTRACT
        or binding.get("physical_consumer_id") != physical_consumer_id
        or binding.get("candidate_boundary_valid") is not True
        or binding.get("live_start_gate_required") is not True
        or "model_invocation_allowed" in binding
        or binding.get("authority") is not False
        or binding.get("completion_claim_allowed") is not False
        or (binding.get("route_choice") or {}).get("choice_sha256")
        != route_choice_sha256
    ):
        raise ValueError(
            "candidate consumer binding does not own this leg-A model start"
        )
    rows = binding.get("boundaries")
    if not isinstance(rows, list):
        raise TypeError("candidate consumer binding boundaries must be an array")
    candidate_base_raw = str(binding.get("candidate_output_base") or "").strip()
    if not candidate_base_raw:
        raise ValueError("candidate consumer binding has no admitted candidate base")
    candidate_base = Path(candidate_base_raw).resolve(strict=True)
    by_id: dict[str, dict[str, Any]] = {}
    for row in rows:
        if not isinstance(row, dict):
            raise TypeError("candidate consumer binding boundary must be an object")
        package_id = str(row.get("package_id") or "")
        if not package_id or package_id in by_id:
            raise ValueError("candidate consumer binding package identity is invalid")
        by_id[package_id] = row
    if set(by_id) != set(packages):
        raise ValueError("candidate consumer binding package set drifted")

    result: dict[str, Path] = {}
    for package_id, package in packages.items():
        if (
            package.get("logical_consumer_id") != EXPECTED_LOGICAL_CANDIDATE_CONSUMER_ID
            or package.get("logical_effect_contract")
            != EXPECTED_LOGICAL_CANDIDATE_EFFECT_CONTRACT
            or "consumer_id" in package
            or "physical_consumer_id" in package
            or "validated_physical_consumer_id" in package
        ):
            raise ValueError("neutral package manifest binds a physical consumer")
        boundary = by_id[package_id]
        if boundary.get("allowed_output_root") != package.get("allowed_output_root"):
            raise ValueError("candidate consumer logical output boundary drifted")
        effective_cwd = _require_exact_candidate_cwd(
            package=package,
            candidate_cwd=Path(str(boundary.get("physical_output_root") or "")),
            selector_root=selector_root,
            runtime_root=runtime_root,
        )
        if _same_path(effective_cwd, candidate_base) or not _is_within(
            effective_cwd, candidate_base
        ):
            raise ValueError(
                "candidate effective cwd escaped the S-admitted candidate base"
            )
        result[package_id] = effective_cwd
    return result


def _require_route_claim_binding(
    claim: dict[str, Any],
    *,
    route_choice_sha256: str,
    physical_consumer_id: str,
    final_start_gate: bool,
) -> None:
    gate_valid = (
        claim.get("model_invocation_allowed") is True
        if final_start_gate
        else (
            claim.get("route_claim_selected") is True
            and claim.get("live_start_gate_required") is True
            and "model_invocation_allowed" not in claim
        )
    )
    if (
        claim.get("leg") != "A"
        or claim.get("choice_sha256") != route_choice_sha256
        or claim.get("physical_consumer_id") != physical_consumer_id
        or not gate_valid
    ):
        raise ValueError("leg-A model start is not owned by this durable route claim")


def _require_direct_route_envelope(envelope: dict[str, Any]) -> dict[str, Any]:
    """Reject B/fake route choices before any provider process can start."""

    if envelope.get("leg") != "A":
        raise ValueError(
            "direct Grok package runner requires a leg-A dispatch envelope"
        )
    selected = envelope.get("validated_selected_candidate")
    if not isinstance(selected, dict):
        raise ValueError(
            "direct Grok package runner requires validated route selection"
        )
    expected = {
        "provider_id": DIRECT_ROUTE_PROVIDER_ID,
        "profile_ref": DIRECT_ROUTE_PROFILE_REF,
        "transport_id": DIRECT_ROUTE_TRANSPORT_ID,
    }
    for field, value in expected.items():
        if selected.get(field) != value:
            raise ValueError(
                f"direct Grok package route mismatch: field={field};"
                f"expected={value};observed={selected.get(field)}"
            )
    if envelope.get("validated_execution_adapter") is not None:
        raise ValueError(
            "direct Grok package runner cannot consume a provider route adapter"
        )
    route_choice = envelope.get("validated_route_choice")
    if not isinstance(route_choice, dict) or route_choice.get("leg") != "A":
        raise ValueError(
            "direct Grok package runner requires an exact leg-A route_choice"
        )
    if route_choice.get("selection_decision_sha256") != envelope.get(
        "selection", {}
    ).get("decision_sha256"):
        raise ValueError("direct Grok package route_choice decision drifted")
    return {
        "selected_route": selected,
        "route_choice": route_choice,
    }


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _canonical_bytes(value: object) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _common_dependency_arg(dependency: object) -> str:
    """Encode typed dependencies deterministically across the PS string seam."""

    if isinstance(dependency, str):
        return dependency
    if not isinstance(dependency, dict):
        raise TypeError("package dependency must be a string or typed object")
    return _canonical_bytes(dependency).decode("utf-8")


def _runtime_worker_dependencies(
    packages: dict[str, dict[str, Any]],
) -> dict[str, set[str]]:
    """Return only in-batch edges that a provider terminal may release.

    Owner-adopted and effect-verified edges carry exact immutable pins in a
    validated execution seal.  A provider terminal can never manufacture
    either fact, so those edges are deliberately absent from this runtime map.
    """

    batch_ids = set(packages)
    result: dict[str, set[str]] = {}
    for package_id, package in packages.items():
        dependencies: set[str] = set()
        for raw in package.get("depends_on", []):
            if not isinstance(raw, dict):
                raise TypeError("validated package dependency must be a typed object")
            dependency_id = str(raw.get("package_id") or "").strip()
            condition = str(raw.get("condition") or "").strip()
            if condition == "worker_terminal" and dependency_id in batch_ids:
                dependencies.add(dependency_id)
        result[package_id] = dependencies
    return result


def _pending_dependency_state(
    package_id: str,
    *,
    runtime_dependencies: dict[str, set[str]],
    provider_satisfied: set[str],
    failed: set[str],
    blocked: set[str],
) -> tuple[bool, set[str]]:
    dependencies = runtime_dependencies[package_id]
    blockers = dependencies & (failed | blocked)
    return dependencies <= provider_satisfied, blockers


def _atomic_bytes(path: Path, raw: bytes, *, replace: bool = False) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not replace:
        raise FileExistsError(f"immutable package artifact already exists: {path}")
    descriptor, temporary = tempfile.mkstemp(
        prefix=path.name + ".",
        suffix=".tmp",
        dir=path.parent,
    )
    temporary_path = Path(temporary)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary_path, path)
    finally:
        temporary_path.unlink(missing_ok=True)
    return hashlib.sha256(raw).hexdigest()


def _atomic_json(path: Path, value: object, *, replace: bool = False) -> str:
    raw = (
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8")
        + b"\n"
    )
    return _atomic_bytes(path, raw, replace=replace)


def _safe_package_component(value: object) -> str:
    text = str(value or "").strip()
    safe = "".join(
        char if char.isalnum() or char in {"-", "_"} else "_" for char in text
    )
    if not safe or safe in {".", ".."}:
        raise ValueError("package_id cannot form a sealed-input directory component")
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]
    return f"{safe[:79]}-{digest}"


def _write_or_verify_immutable(path: Path, raw: bytes) -> dict[str, str]:
    expected = hashlib.sha256(raw).hexdigest()
    if path.exists():
        if not path.is_file() or _sha(path) != expected:
            raise FileExistsError(f"immutable model-input artifact collision: {path}")
    else:
        _atomic_bytes(path, raw)
    return {"path": str(path.resolve(strict=True)), "sha256": expected}


def _sealed_input_root(path: Path) -> Path:
    # The builder owns physical directory naming.  The consumer binds identity
    # from the exact catalog contents instead of duplicating that naming
    # algorithm and creating a cross-release compatibility trap.
    matches = [
        parent
        for parent in path.parents
        if parent.parent.name.casefold() == "packages"
        and (parent / "catalog.json").is_file()
    ]
    if len(matches) != 1:
        raise ValueError(
            "package input is not inside one canonical sealed-input package root: "
            f"{path}"
        )
    return matches[0]


def _require_exact_sealed_input_inventory(
    root: Path, expected_files: Sequence[Path]
) -> None:
    """Reject anything outside the catalog-bound package projection."""

    physical_root = root.resolve(strict=True)
    expected = {path.resolve(strict=True) for path in expected_files}
    allowed_directories = {physical_root}
    for path in expected:
        if not path.is_relative_to(physical_root):
            raise ValueError(f"sealed input inventory escapes package root: {path}")
        parent = path.parent
        while parent != physical_root:
            allowed_directories.add(parent)
            parent = parent.parent

    observed_files: set[Path] = set()
    observed_directories = {physical_root}
    for current, directory_names, file_names in os.walk(
        physical_root, topdown=True, followlinks=False
    ):
        current_path = Path(current)
        for name in directory_names:
            candidate = current_path / name
            if _contains_reparse_component(candidate):
                raise ValueError(
                    f"sealed input inventory contains a reparse directory: {candidate}"
                )
            observed_directories.add(candidate.resolve(strict=True))
        for name in file_names:
            candidate = current_path / name
            if _contains_reparse_component(candidate) or not candidate.is_file():
                raise ValueError(
                    f"sealed input inventory contains a non-regular file: {candidate}"
                )
            observed_files.add(candidate.resolve(strict=True))

    extra_files = sorted(str(path) for path in observed_files - expected)
    missing_files = sorted(str(path) for path in expected - observed_files)
    extra_directories = sorted(
        str(path) for path in observed_directories - allowed_directories
    )
    if extra_files or missing_files or extra_directories:
        raise ValueError(
            "sealed input mount is not the exact catalog projection: "
            f"extra_files={extra_files};missing_files={missing_files};"
            f"extra_directories={extra_directories}"
        )


def _prepare_sealed_model_input(
    *, package: Mapping[str, Any], task_run_dir: Path
) -> dict[str, Any]:
    """Expose bound package inputs through one read-only container mount.

    Thick inputs stay as files and are not inlined into the initial prompt.
    Only a deterministic catalog pointer is appended there; later required
    ``read_file`` results intentionally enter the provider model context.
    """

    package_id = str(package.get("package_id") or "").strip()
    package_component = _safe_package_component(package_id)
    raw_refs = package.get("input_refs")
    if not isinstance(raw_refs, list) or not raw_refs:
        raise ValueError("package requires non-empty sealed input_refs")

    host_root: Path | None = None
    model_inputs: list[dict[str, object]] = []
    host_inputs: list[dict[str, object]] = []
    for index, raw_ref in enumerate(raw_refs):
        if not isinstance(raw_ref, Mapping):
            raise TypeError(f"package input_refs[{index}] must be an object")
        expected_sha256 = str(raw_ref.get("sha256") or "").strip().lower()
        if not re.fullmatch(r"[0-9a-f]{64}", expected_sha256):
            raise ValueError(f"package input_refs[{index}].sha256 is invalid")
        lexical = Path(os.path.abspath(str(raw_ref.get("path") or "")))
        if not lexical.is_file() or _contains_reparse_component(lexical):
            raise ValueError(
                f"package sealed input is missing or traverses a reparse point: {lexical}"
            )
        physical = lexical.resolve(strict=True)
        if not _same_path(lexical, physical):
            raise ValueError(f"package sealed input path is aliased: {lexical}")
        observed_sha256 = _sha(physical)
        if observed_sha256 != expected_sha256:
            raise ValueError(
                "package sealed input changed before model composition: "
                f"path={physical};expected={expected_sha256};observed={observed_sha256}"
            )
        candidate_root = _sealed_input_root(physical)
        if _contains_reparse_component(candidate_root):
            raise ValueError(
                f"package sealed input root traverses a reparse point: {candidate_root}"
            )
        candidate_root = candidate_root.resolve(strict=True)
        if host_root is None:
            host_root = candidate_root
        elif not _same_path(host_root, candidate_root):
            raise ValueError("package input_refs span multiple sealed-input roots")
        relative = physical.relative_to(candidate_root).as_posix()
        container_path = f"/sealed-inputs/{relative}"
        if any(row["path"] == container_path for row in model_inputs):
            raise ValueError(
                f"package input_refs contain a duplicate sealed input: {container_path}"
            )
        size = physical.stat().st_size
        model_inputs.append(
            {
                "slot": index,
                "path": container_path,
                "sha256": expected_sha256,
                "bytes": size,
            }
        )
        host_inputs.append(
            {
                "slot": index,
                "host_path": str(physical),
                "container_path": container_path,
                "sha256": expected_sha256,
                "bytes": size,
            }
        )
    assert host_root is not None

    expected_catalog = {
        "schema_version": "xinao.worker_sealed_input_catalog.v2",
        "package_id": package_id,
        "container_root": "/sealed-inputs",
        "mount_scope": "catalog_and_required_entries_only",
        "external_input_admission": {
            "status": "owner_reviewed_redacted",
            "scope": "all_package_sources",
            "reviewer_role": "codex_owner",
        },
        "entries": [
            {
                **row,
                "required": True,
                "read_strategy": "read_file_required_selected_content",
            }
            for row in model_inputs
        ],
        "authority": False,
        "completion_claim_allowed": False,
    }
    catalog_path = host_root / "catalog.json"
    if not catalog_path.is_file() or _contains_reparse_component(catalog_path):
        raise ValueError("package sealed input catalog is missing or aliased")
    observed_catalog, catalog_ref = _load_hash_bound_object(
        catalog_path, "package sealed input catalog"
    )
    if observed_catalog != expected_catalog:
        raise ValueError(
            "package sealed input catalog does not exactly bind input_refs"
        )
    _require_exact_sealed_input_inventory(
        host_root,
        [catalog_path, *(Path(str(row["host_path"])) for row in host_inputs)],
    )
    prompt_binding = (
        "# Sealed package input binding\n\n"
        "catalog=/sealed-inputs/catalog.json\n"
        f"catalog_sha256={catalog_ref['sha256']}\n"
        f"required_entry_count={len(model_inputs)}\n"
        "Read the catalog first. In a later model turn, call read_file at least once for every "
        "required entry before forming findings. The catalog is an index, not the file content; "
        "do not substitute live paths or treat a listed hash as consumption.\n"
    )

    prompt_ref = package.get("prompt_ref")
    if not isinstance(prompt_ref, Mapping):
        raise TypeError("package prompt_ref must be an object")
    prompt_path = Path(str(prompt_ref.get("path") or "")).resolve(strict=True)
    prompt_bytes = prompt_path.read_bytes()
    expected_prompt_sha = str(prompt_ref.get("sha256") or "").lower()
    if hashlib.sha256(prompt_bytes).hexdigest() != expected_prompt_sha:
        raise ValueError("package prompt changed before sealed model-input composition")
    try:
        prompt_text = prompt_bytes.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValueError("package prompt is not valid UTF-8") from exc
    effective_prompt_bytes = (
        prompt_text.rstrip() + "\n\n---\n\n" + prompt_binding
    ).encode("utf-8")

    artifact_root = (
        task_run_dir
        / "sealed-model-inputs"
        / package_component
        / str(package["package_identity_sha256"])
    )
    artifact_root.mkdir(parents=True, exist_ok=True)
    binding_receipt = {
        "schema_version": "xinao.worker_sealed_model_input_binding.v1",
        "package_id": package_id,
        "package_identity_sha256": package["package_identity_sha256"],
        "package_input_sha256": package["input_sha256"],
        "host_root": str(host_root),
        "host_inputs": host_inputs,
        "catalog_ref": catalog_ref,
        "required_entry_count": len(model_inputs),
        "authority": False,
        "completion_claim_allowed": False,
    }
    binding_raw = (
        json.dumps(
            binding_receipt, ensure_ascii=False, indent=2, sort_keys=True
        ).encode("utf-8")
        + b"\n"
    )
    binding_ref = _write_or_verify_immutable(
        artifact_root / "binding.json", binding_raw
    )
    prompt_ref = _write_or_verify_immutable(
        artifact_root / "effective-package-prompt.md", effective_prompt_bytes
    )
    return {
        "package_id": package_id,
        "artifact_root": artifact_root,
        "host_root": host_root,
        "container_root": "/sealed-inputs",
        "catalog_ref": catalog_ref,
        "binding_ref": binding_ref,
        "effective_prompt_ref": prompt_ref,
        "input_refs": host_inputs,
    }


def _revalidate_sealed_model_input(binding: Mapping[str, Any]) -> None:
    root = Path(str(binding.get("host_root") or ""))
    if not root.is_dir() or _contains_reparse_component(root):
        raise ValueError("sealed input root changed during provider execution")
    catalog_ref = binding.get("catalog_ref")
    if not isinstance(catalog_ref, Mapping):
        raise ValueError("sealed input catalog binding is missing")
    catalog_path = Path(str(catalog_ref.get("path") or ""))
    if (
        not catalog_path.is_file()
        or _contains_reparse_component(catalog_path)
        or _sha(catalog_path) != catalog_ref.get("sha256")
    ):
        raise ValueError("sealed input catalog changed during provider execution")
    for row in binding.get("input_refs", []):
        path = Path(str(row["host_path"]))
        if not path.is_file() or _contains_reparse_component(path):
            raise ValueError(
                f"sealed input disappeared during provider execution: {path}"
            )
        observed = _sha(path)
        if observed != row["sha256"]:
            raise ValueError(
                "sealed input changed during provider execution: "
                f"path={path};expected={row['sha256']};observed={observed}"
            )
    _require_exact_sealed_input_inventory(
        root,
        [
            catalog_path,
            *(Path(str(row["host_path"])) for row in binding.get("input_refs", [])),
        ],
    )


def _normalize_container_path(value: object) -> str:
    text = str(value or "").strip().replace("\\", "/")
    while "//" in text:
        text = text.replace("//", "/")
    return text.rstrip("/") or "/"


def _verify_sealed_input_tool_readback(
    *, meta: Mapping[str, Any], binding: Mapping[str, Any]
) -> dict[str, str]:
    """Bind provider-native read_file/tool_result observations for every sealed input.

    This proves that the provider requested each exact bound path and received a
    paired result after reading the catalog.  Results must be non-empty except
    for catalog-declared zero-byte inputs.  It intentionally does not claim that
    the model semantically understood or exhaustively consumed every byte;
    substantive use remains part of candidate and Owner review.
    """

    session_dir = Path(str(meta.get("session_evidence_dir") or ""))
    if not session_dir.is_dir() or _contains_reparse_component(session_dir):
        raise ValueError("provider session evidence directory is missing or aliased")
    chat_history = session_dir / "chat_history.jsonl"
    if not chat_history.is_file() or _contains_reparse_component(chat_history):
        raise ValueError("provider chat_history.jsonl is missing or aliased")
    updates_path = session_dir / "updates.jsonl"
    if not updates_path.is_file() or _contains_reparse_component(updates_path):
        raise ValueError("provider updates.jsonl is missing or aliased")

    required = {
        _normalize_container_path(row["container_path"]): []
        for row in binding.get("input_refs", [])
    }
    required_bytes = {
        _normalize_container_path(row["container_path"]): int(row["bytes"])
        for row in binding.get("input_refs", [])
    }
    catalog_path = "/sealed-inputs/catalog.json"
    catalog_calls: list[str] = []
    call_lines: dict[str, int] = {}
    tool_results: dict[str, tuple[str, int, bool]] = {}
    seen_call_ids: set[str] = set()
    chat_raw, chat_ref = _read_hash_bound_bytes(chat_history, "provider chat history")
    updates_raw, updates_ref = _read_hash_bound_bytes(updates_path, "provider updates")
    for line_number, raw_line in enumerate(
        chat_raw.decode("utf-8-sig").splitlines(), start=1
    ):
        if not raw_line.strip():
            continue
        try:
            event = json.loads(raw_line)
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"provider chat history line {line_number} is invalid JSON"
            ) from exc
        if not isinstance(event, Mapping):
            raise ValueError(
                f"provider chat history line {line_number} is not an object"
            )
        if event.get("type") == "assistant":
            calls = event.get("tool_calls", [])
            if calls is None:
                calls = []
            if not isinstance(calls, list):
                raise ValueError("provider assistant tool_calls is not an array")
            for raw_call in calls:
                if not isinstance(raw_call, Mapping):
                    continue
                call_id = str(raw_call.get("id") or "").strip()
                if call_id:
                    if call_id in seen_call_ids:
                        raise ValueError(
                            f"provider chat history repeats tool call id: {call_id}"
                        )
                    seen_call_ids.add(call_id)
                if raw_call.get("name") != "read_file":
                    continue
                arguments = raw_call.get("arguments")
                if isinstance(arguments, str):
                    try:
                        arguments = json.loads(arguments)
                    except json.JSONDecodeError:
                        continue
                if not isinstance(arguments, Mapping):
                    continue
                target = _normalize_container_path(arguments.get("target_file"))
                if call_id:
                    call_lines[call_id] = line_number
                    if target == catalog_path:
                        catalog_calls.append(call_id)
                    elif target in required:
                        required[target].append(call_id)
        elif event.get("type") == "tool_result":
            call_id = str(event.get("tool_call_id") or "").strip()
            content = event.get("content")
            if call_id and content is not None:
                if call_id in tool_results:
                    raise ValueError(
                        f"provider chat history repeats tool result id: {call_id}"
                    )
                rendered = str(content)
                tool_results[call_id] = (
                    hashlib.sha256(rendered.encode("utf-8")).hexdigest(),
                    line_number,
                    bool(rendered.strip()),
                )

    successful_native_reads: set[str] = set()
    terminal_updates: set[str] = set()
    for line_number, raw_line in enumerate(
        updates_raw.decode("utf-8-sig").splitlines(), start=1
    ):
        if not raw_line.strip():
            continue
        try:
            event = json.loads(raw_line)
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"provider updates line {line_number} is invalid JSON"
            ) from exc
        if not isinstance(event, Mapping):
            raise ValueError(f"provider updates line {line_number} is not an object")
        params = event.get("params")
        update = params.get("update") if isinstance(params, Mapping) else None
        if (
            not isinstance(update, Mapping)
            or update.get("sessionUpdate") != "tool_call_update"
        ):
            continue
        call_id = str(update.get("toolCallId") or "").strip()
        status = str(update.get("status") or "").strip().casefold()
        if not call_id or status not in {"completed", "failed"}:
            continue
        if call_id in terminal_updates:
            raise ValueError(f"provider updates repeat terminal tool status: {call_id}")
        terminal_updates.add(call_id)
        raw_output = update.get("rawOutput")
        if (
            status == "completed"
            and isinstance(raw_output, Mapping)
            and str(raw_output.get("type") or "").casefold() == "readfile"
        ):
            successful_native_reads.add(call_id)

    def valid_readback(
        call_id: str, *, after_line: int = 0, allow_empty: bool = False
    ) -> bool:
        result = tool_results.get(call_id)
        call_line = call_lines.get(call_id, 0)
        return bool(
            result is not None
            and call_id in successful_native_reads
            and call_line > after_line
            and result[1] > call_line
            and (result[2] or allow_empty)
        )

    valid_catalog_calls = [
        call_id for call_id in catalog_calls if valid_readback(call_id)
    ]
    catalog_results = [tool_results[call_id] for call_id in valid_catalog_calls]
    if not catalog_results:
        raise ValueError(
            "provider did not prove ordered successful catalog read_file plus non-empty tool_result"
        )
    catalog_result_line = min(line for _, line, _ in catalog_results)

    missing = sorted(
        path
        for path, call_ids in required.items()
        if not any(
            valid_readback(
                call_id,
                after_line=catalog_result_line,
                allow_empty=required_bytes[path] == 0,
            )
            for call_id in call_ids
        )
    )
    if missing:
        raise ValueError(
            "provider did not prove later read_file plus size-consistent tool_result for: "
            + ", ".join(missing)
        )
    receipt = {
        "schema_version": "xinao.worker_sealed_input_readback.v1",
        "package_id": binding["package_id"],
        "chat_history_ref": chat_ref,
        "updates_ref": updates_ref,
        "catalog_ref": binding["catalog_ref"],
        "catalog_read_call_ids": sorted(valid_catalog_calls),
        "catalog_result_line": catalog_result_line,
        "required_paths": sorted(required),
        "readbacks": [
            {
                "path": path,
                "tool_call_ids": sorted(required[path]),
                "tool_result_sha256": sorted(
                    {
                        tool_results[call_id][0]
                        for call_id in required[path]
                        if valid_readback(
                            call_id,
                            after_line=catalog_result_line,
                            allow_empty=required_bytes[path] == 0,
                        )
                    }
                ),
            }
            for path in sorted(required)
        ],
        "all_required_entry_readbacks_observed": True,
        "authority": False,
        "completion_claim_allowed": False,
    }
    readback_identity = hashlib.sha256(
        _canonical_bytes(
            {
                "package_id": binding["package_id"],
                "catalog_ref": binding["catalog_ref"],
                "chat_history_ref": chat_ref,
                "updates_ref": updates_ref,
            }
        )
    ).hexdigest()
    receipt["readback_identity_sha256"] = readback_identity
    raw = (
        json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True).encode(
            "utf-8"
        )
        + b"\n"
    )
    receipt_ref = _write_or_verify_immutable(
        Path(str(binding["artifact_root"]))
        / "readbacks"
        / readback_identity
        / "tool-readback.json",
        raw,
    )
    return {
        **receipt_ref,
        "chat_history_path": chat_ref["path"],
        "chat_history_sha256": chat_ref["sha256"],
        "updates_path": updates_ref["path"],
        "updates_sha256": updates_ref["sha256"],
    }


def _load_object(path: Path, label: str) -> dict[str, Any]:
    if not path.is_file():
        raise ValueError(f"{label} missing: {path}")
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise TypeError(f"{label} must be an object")
    return value


def _read_hash_bound_bytes(
    path: Path, label: str, expected_sha256: str | None = None
) -> tuple[bytes, dict[str, str]]:
    resolved = path.resolve(strict=True)
    if not resolved.is_file() or _contains_reparse_component(resolved):
        raise ValueError(f"{label} is missing or aliased: {resolved}")
    raw = resolved.read_bytes()
    observed = hashlib.sha256(raw).hexdigest()
    if expected_sha256 and observed != expected_sha256:
        raise ValueError(
            f"{label} hash drifted: expected={expected_sha256}; observed={observed}"
        )
    return raw, {"path": str(resolved), "sha256": observed}


def _load_hash_bound_object(
    path: Path, label: str, expected_sha256: str | None = None
) -> tuple[dict[str, Any], dict[str, str]]:
    raw, ref = _read_hash_bound_bytes(path, label, expected_sha256)
    try:
        value = json.loads(raw.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"{label} is not valid UTF-8 JSON") from exc
    if not isinstance(value, dict):
        raise TypeError(f"{label} must be an object")
    return value, ref


def _identifier(prefix: str) -> str:
    from datetime import datetime

    return f"{prefix}_{datetime.now().strftime('%Y%m%dT%H%M%S')}_{uuid.uuid4().hex[:8]}"


def _operation_id(package: dict[str, Any]) -> str:
    digest = hashlib.sha256(
        _canonical_bytes(
            {
                "package_id": package["package_id"],
                "work_key": package["work_key"],
                "package_identity_sha256": package["package_identity_sha256"],
            }
        )
    ).hexdigest()
    return f"op_direct_package_{digest[:32]}"


def _hash_bound_ref(path: Path, expected_sha256: str | None = None) -> dict[str, str]:
    resolved = path.resolve(strict=True)
    observed = _sha(resolved)
    if expected_sha256 and observed != expected_sha256:
        raise ValueError(
            f"hash-bound artifact drifted: {resolved}; "
            f"expected={expected_sha256}; observed={observed}"
        )
    return {"path": str(resolved), "sha256": observed}


def _package_artifact_ref(
    package: dict[str, Any], field: str, *, expected_sha256_field: str | None = None
) -> dict[str, str]:
    raw = package.get(field)
    if not isinstance(raw, dict) or set(raw) != {"path", "sha256"}:
        raise ValueError(f"package {field} must be one exact hash-bound artifact ref")
    expected = str(raw.get("sha256") or "").strip().lower()
    if len(expected) != 64 or any(char not in "0123456789abcdef" for char in expected):
        raise ValueError(f"package {field}.sha256 is invalid")
    if expected_sha256_field is not None:
        package_expected = str(package.get(expected_sha256_field) or "").strip().lower()
        if package_expected != expected:
            raise ValueError(
                f"package {field}.sha256 does not match {expected_sha256_field}"
            )
    return _hash_bound_ref(Path(str(raw.get("path") or "")), expected)


def _same_file_path(left: object, right: Path) -> bool:
    try:
        candidate = Path(str(left)).resolve(strict=True)
    except (OSError, RuntimeError, ValueError):
        return False
    return os.path.normcase(str(candidate)) == os.path.normcase(str(right))


def _prior_reuse_contract_binding(
    *,
    package: dict[str, Any],
    validated_manifest: dict[str, Any],
    current_manifest_path: Path,
    current_manifest_sha256: str,
    validate_attempt_receipt: Callable[..., Any],
) -> dict[str, str]:
    """Bind prior reuse to the exact accepted ancestor contract.

    Adding ``prior_attempt_receipt_ref`` necessarily reseals the physical batch
    manifest.  That carrier change must not silently rewrite the already
    accepted logical contract, but it also must not loosen receipt validation.
    The old binding is reusable only when its adapter artifacts are intact and
    its hash-bound task manifest is a verified ancestor carrying the same
    package identity and work key.
    """

    prior_raw = package.get("prior_attempt_receipt_ref")
    if prior_raw is None:
        return {
            "task_contract_ref": (
                f"{current_manifest_path}#sha256={current_manifest_sha256}"
            ),
            "subject_manifest_sha256": current_manifest_sha256,
            "binding_source": "current_manifest",
        }
    prior_ref = _package_artifact_ref(package, "prior_attempt_receipt_ref")
    prior_path = Path(prior_ref["path"])
    lane_root = prior_path.parent
    adapter_path = lane_root / "common_adapter_receipt.json"
    contract_path = lane_root / "common_logical_contract.json"
    adapter = _load_object(adapter_path, "prior common adapter receipt")
    contract = _load_object(contract_path, "prior common logical contract")
    attempt = _load_object(prior_path, "prior common attempt receipt")

    artifact_paths = adapter.get("artifact_paths")
    artifact_sha256 = adapter.get("artifact_sha256")
    if not isinstance(artifact_paths, dict) or not isinstance(artifact_sha256, dict):
        raise ValueError("prior adapter receipt has no exact artifact bindings")
    if (
        not _same_file_path(artifact_paths.get("attempt_receipt"), prior_path)
        or str(artifact_sha256.get("attempt_receipt") or "") != prior_ref["sha256"]
        or not _same_file_path(artifact_paths.get("logical_contract"), contract_path)
        or str(artifact_sha256.get("logical_contract") or "") != _sha(contract_path)
    ):
        raise ValueError("prior adapter receipt artifact binding drifted")
    if (
        adapter.get("common_receipt_accepted") is not True
        or adapter.get("provider_native_accepted") is not True
        or adapter.get("authority") is not False
        or adapter.get("completion_claim_allowed") is not False
    ):
        raise ValueError("prior adapter receipt is not an accepted candidate-only fact")
    provider_ref_text = str(attempt.get("provider_evidence_ref") or "")
    provider_sha256 = str(attempt.get("provider_evidence_sha256") or "")
    if not provider_ref_text or not re.fullmatch(r"[0-9a-f]{64}", provider_sha256):
        raise ValueError("prior receipt provider evidence binding is invalid")
    provider_path = Path(provider_ref_text).resolve(strict=True)
    if _sha(provider_path) != provider_sha256:
        raise ValueError("prior receipt provider evidence bytes drifted")
    meta = _load_object(provider_path, "prior provider evidence")
    preflight = meta.get("common_contract_preflight")
    if not isinstance(preflight, dict) or preflight.get("validated") is not True:
        raise ValueError("prior provider evidence has no validated common preflight")
    contract_digest = str(attempt.get("contract_sha256") or "")
    if (
        not re.fullmatch(r"[0-9a-f]{64}", contract_digest)
        or str(adapter.get("contract_sha256") or "") != contract_digest
        or str(preflight.get("logical_contract_sha256") or "") != contract_digest
    ):
        raise ValueError("prior logical contract digest binding drifted")
    try:
        verdict = validate_attempt_receipt(
            contract,
            attempt,
            expected_consumer_id=EXPECTED_DIRECT_ATTEMPT_CONSUMER_ID,
        )
    except Exception as exc:
        raise ValueError(f"prior attempt receipt validation failed: {exc}") from exc
    if getattr(verdict, "accepted", False) is not True:
        reasons = ",".join(str(value) for value in getattr(verdict, "reason_codes", ()))
        raise ValueError(f"prior attempt receipt is not accepted: {reasons}")
    if (
        str(contract.get("logical_operation_id") or "") != _operation_id(package)
        or str(contract.get("work_key") or "") != str(package.get("work_key") or "")
        or str(attempt.get("logical_operation_id") or "") != _operation_id(package)
        or str(attempt.get("work_key") or "") != str(package.get("work_key") or "")
    ):
        raise ValueError("prior receipt operation or work identity drifted")

    task_contract_ref = str(contract.get("task_contract_ref") or "")
    task_path_text, separator, task_sha256 = task_contract_ref.rpartition("#sha256=")
    if not separator or not re.fullmatch(r"[0-9a-f]{64}", task_sha256):
        raise ValueError("prior task_contract_ref is not hash-bound")
    task_path_input = Path(task_path_text)
    if not task_path_input.is_absolute():
        raise ValueError("prior task_contract_ref path must be absolute")
    task_path = task_path_input.resolve(strict=True)
    if _sha(task_path) != task_sha256:
        raise ValueError("prior task_contract_ref bytes drifted")
    subject_sha256 = str(preflight.get("subject_manifest_sha256") or "")
    if subject_sha256 != task_sha256:
        raise ValueError("prior subject manifest is not its task contract carrier")

    ancestor_ref = validated_manifest.get("predecessor_manifest_ref")
    current_revision = int(validated_manifest.get("graph_revision") or 0)
    current_parent_work_key = str(validated_manifest.get("parent_work_key") or "")
    if current_revision < 2 or not current_parent_work_key:
        raise ValueError("prior reuse requires a validated reseal manifest")
    seen: set[tuple[str, str]] = set()
    matched_ancestor = False
    depth = 0
    while ancestor_ref is not None:
        depth += 1
        if depth > 32:
            raise ValueError("reseal ancestor chain exceeds depth 32")
        if not isinstance(ancestor_ref, dict) or set(ancestor_ref) != {
            "path",
            "sha256",
        }:
            raise ValueError("reseal ancestor ref is not exact and hash-bound")
        ancestor_path = Path(str(ancestor_ref["path"])).resolve(strict=True)
        ancestor_sha = str(ancestor_ref["sha256"])
        key = (os.path.normcase(str(ancestor_path)), ancestor_sha)
        if key in seen:
            raise ValueError("reseal ancestor chain contains a cycle")
        seen.add(key)
        if _sha(ancestor_path) != ancestor_sha:
            raise ValueError("reseal ancestor manifest bytes drifted")
        ancestor = _load_object(ancestor_path, "reseal ancestor manifest")
        if ancestor.get("schema_version") != EXPECTED_PACKAGE_BATCH_SCHEMA:
            raise ValueError("reseal ancestor manifest schema drifted")
        ancestor_revision = int(ancestor.get("graph_revision") or 0)
        if ancestor_revision != current_revision - depth:
            raise ValueError("reseal ancestor graph revision drifted")
        if str(ancestor.get("parent_work_key") or "") != current_parent_work_key:
            raise ValueError("reseal ancestor parent work key drifted")
        ancestor_packages = ancestor.get("packages")
        if not isinstance(ancestor_packages, list):
            raise ValueError("reseal ancestor package set is invalid")
        prior_package = next(
            (
                row
                for row in ancestor_packages
                if isinstance(row, dict)
                and str(row.get("package_id") or "")
                == str(package.get("package_id") or "")
            ),
            None,
        )
        if prior_package is None:
            raise ValueError("reseal ancestor is missing the prior package")
        if (
            str(prior_package.get("package_identity_sha256") or "")
            != str(package.get("package_identity_sha256") or "")
            or str(prior_package.get("work_key") or "")
            != str(package.get("work_key") or "")
            or str(prior_package.get("parent_work_key") or "")
            != str(package.get("parent_work_key") or "")
        ):
            raise ValueError("reseal ancestor package identity drifted")
        if _same_file_path(task_path, ancestor_path) and task_sha256 == ancestor_sha:
            matched_ancestor = True
            break
        ancestor_ref = ancestor.get("predecessor_manifest_ref")
    if not matched_ancestor:
        raise ValueError(
            "prior accepted task contract is not in the reseal ancestor chain"
        )
    return {
        "task_contract_ref": task_contract_ref,
        "subject_manifest_sha256": subject_sha256,
        "binding_source": "prior_accepted_ancestor_manifest",
        "prior_attempt_receipt_ref": str(prior_path),
        "prior_attempt_receipt_sha256": prior_ref["sha256"],
        "prior_logical_contract_ref": str(contract_path.resolve(strict=True)),
        "prior_logical_contract_sha256": _sha(contract_path),
        "frozen_context_sha256": str(preflight.get("frozen_context_sha256") or ""),
        "provider_evidence_ref": str(provider_path),
        "provider_evidence_sha256": provider_sha256,
    }


def _candidate_write_domain(candidate_root: Path) -> str:
    """Name the physical candidate boundary without granting an authority domain."""

    normalized = str(candidate_root.resolve(strict=True)).replace("\\", "/").rstrip("/")
    if not normalized:
        raise ValueError("candidate output root is empty")
    return "candidate_output_root:" + normalized.casefold()


def _extract_cli_final_text(
    cli_json_path: Path | Mapping[str, Any], lane_meta: dict[str, Any]
) -> str:
    """Reproduce the provider validator's exact effective-output selection."""

    payload = (
        dict(cli_json_path)
        if isinstance(cli_json_path, Mapping)
        else _load_object(cli_json_path, "provider CLI JSON")
    )
    source = str(lane_meta.get("effective_output_source") or "").strip()
    if source == "structuredOutput":
        structured = payload.get("structuredOutput")
        if not isinstance(structured, dict):
            raise ValueError("structuredOutput final value must be an object")
        return json.dumps(
            structured,
            ensure_ascii=False,
            separators=(",", ":"),
        )
    if source == "text":
        text = payload.get("text")
        if text is None:
            return ""
        if not isinstance(text, str):
            raise ValueError("provider CLI text final value must be a string")
        return text
    raise ValueError(
        f"provider lane effective_output_source is unsupported: {source!r}"
    )


def _locate_common_receipt(
    summary: dict[str, Any], lane: dict[str, Any]
) -> tuple[Path, str] | None:
    candidates: list[Path] = []
    explicit = str(summary.get("common_adapter_receipt_path") or "").strip()
    if explicit:
        candidates.append(Path(explicit))
    evidence_dir = str(lane.get("evidence_dir") or "").strip()
    if evidence_dir:
        candidates.append(Path(evidence_dir) / "common_adapter_receipt.json")
    expected = str(summary.get("common_adapter_receipt_sha256") or "").strip().lower()
    for candidate in candidates:
        if candidate.is_file():
            observed = _sha(candidate)
            if expected and observed != expected:
                raise ValueError(
                    "common adapter receipt hash drifted: "
                    f"expected={expected}; observed={observed}"
                )
            return candidate.resolve(strict=True), observed
    return None


def _materialize_model_input_binding(
    *,
    package: Mapping[str, Any],
    sealed_model_input: Mapping[str, Any],
    contract: Mapping[str, Any],
    contract_path: Path,
    contract_sha256: str,
    logical_contract_sha256: str,
    attempt_receipt: Mapping[str, Any],
    attempt_path: Path,
    attempt_sha256: str,
    pool_summary: Mapping[str, Any],
    pool_summary_path: Path,
    runtime_root: Path,
    dispatch_id: str,
    pool_id: str,
    operation_id: str,
    subject_manifest_sha256: str,
    attempt_root: Path,
) -> dict[str, str] | None:
    """Bind the two prompt transforms and the consumed lane prompt as control evidence.

    Provider output artifacts must stay adoption-pure.  The input lineage is
    therefore carried by one separate hash-bound receipt instead of being mixed
    into ``artifact_refs``.
    """

    package_prompt_ref = _package_artifact_ref(dict(package), "prompt_ref")
    contract_input_sha = str(contract.get("input_sha256") or "").strip().lower()
    if contract_input_sha == package_prompt_ref["sha256"]:
        return None
    if not re.fullmatch(r"[0-9a-f]{64}", contract_input_sha):
        raise ValueError("common contract input_sha256 is invalid")
    if not re.fullmatch(r"[0-9a-f]{64}", logical_contract_sha256):
        raise ValueError("logical contract digest is invalid")
    common_attempt_ref = _hash_bound_ref(attempt_path, attempt_sha256)
    attempt_lineage = attempt_receipt.get("lineage")
    attempt_observed = attempt_receipt.get("observed")
    if not isinstance(attempt_lineage, Mapping) or not isinstance(
        attempt_observed, Mapping
    ):
        raise TypeError("common attempt lineage and observed identity must be objects")
    provider_evidence_ref = _hash_bound_ref(
        Path(str(attempt_receipt.get("provider_evidence_ref") or "")),
        str(attempt_receipt.get("provider_evidence_sha256") or ""),
    )

    sealed_prompt_raw = sealed_model_input.get("effective_prompt_ref")
    catalog_raw = sealed_model_input.get("catalog_ref")
    if not isinstance(sealed_prompt_raw, Mapping) or not isinstance(
        catalog_raw, Mapping
    ):
        raise TypeError("sealed model input refs must be hash-bound objects")
    sealed_prompt_ref = _hash_bound_ref(
        Path(str(sealed_prompt_raw.get("path") or "")),
        str(sealed_prompt_raw.get("sha256") or ""),
    )
    catalog_ref = _hash_bound_ref(
        Path(str(catalog_raw.get("path") or "")),
        str(catalog_raw.get("sha256") or ""),
    )
    dispatch_meta_path = (
        runtime_root
        / "state"
        / "codex_dispatch_grok_worker_pool"
        / f"{dispatch_id}.json"
    )
    dispatch_meta, dispatch_meta_ref = _load_hash_bound_object(
        dispatch_meta_path, "worker-pool dispatch metadata"
    )
    prepared_contract_ref = _hash_bound_ref(
        Path(str(dispatch_meta.get("common_contract_path") or "")),
        contract_sha256,
    )
    prepare_path = Path(prepared_contract_ref["path"]).with_name(
        "contract_prepare_receipt.json"
    )
    prepare, prepare_ref = _load_hash_bound_object(
        prepare_path, "common contract prepare receipt"
    )
    effective_path = Path(str(prepare.get("effective_prompt_file") or ""))
    effective_raw, effective_ref = _read_hash_bound_bytes(
        effective_path,
        "common effective prompt",
        str(prepare.get("effective_prompt_sha256") or "").strip().lower(),
    )
    if (
        prepare.get("schema_version")
        != "xinao.direct_worker_pool.contract_prepare_receipt.v1"
        or prepare.get("authority") is not False
        or prepare.get("completion_claim_allowed") is not False
        or prepare.get("context_binding_mode") != "validated_context_slice_manifest"
        or prepare.get("context_application_status")
        != "effective_prompt_artifact_written"
        or prepare.get("model_input_effect_verified") is not False
        or prepare.get("original_prompt_sha256") != sealed_prompt_ref["sha256"]
        or prepare.get("prompt_sha256") != sealed_prompt_ref["sha256"]
        or not _same_path(
            Path(str(prepare.get("prompt_file") or "")),
            Path(sealed_prompt_ref["path"]),
        )
        or prepare.get("effective_prompt_sha256") != contract_input_sha
        or prepare.get("effective_prompt_bytes") != len(effective_raw)
        or prepare.get("logical_contract_sha256") != logical_contract_sha256
        or prepare.get("subject_manifest_sha256") != subject_manifest_sha256
    ):
        raise ValueError(
            "common prepare receipt does not bind the package prompt transform"
        )

    context_ref = _package_artifact_ref(dict(package), "context_manifest_ref")
    rules_ref = _package_artifact_ref(
        dict(package), "rules_ref", expected_sha256_field="rules_sha256"
    )
    if (
        prepare.get("context_manifest_sha256") != context_ref["sha256"]
        or not _same_path(
            Path(str(prepare.get("context_manifest_file") or "")),
            Path(context_ref["path"]),
        )
        or prepare.get("rules_sha256") != rules_ref["sha256"]
        or not _same_path(
            Path(str(prepare.get("rules_file") or "")), Path(rules_ref["path"])
        )
    ):
        raise ValueError("common prepare receipt context or rules binding drifted")

    pool_summary_ref = _hash_bound_ref(pool_summary_path)
    lane_prompt_path = Path(
        str(dispatch_meta.get("common_pool_lane_prompt_file") or "")
    )
    lane_prompt_raw, lane_prompt_ref = _read_hash_bound_bytes(
        lane_prompt_path, "worker-pool lane prompt"
    )
    if (
        dispatch_meta.get("schema_version")
        != "xinao.codex_dispatch_grok_worker_pool.v1"
        or dispatch_meta.get("sentinel") != "SENTINEL:CODEX_DISPATCH_GROK_WORKER_POOL"
        or dispatch_meta.get("dispatch_id") != dispatch_id
        or dispatch_meta.get("pool_id") != pool_id
        or dispatch_meta.get("status") not in {"accepted", "rejected"}
        or dispatch_meta.get("common_model_input_effect_verified") is not True
        or dispatch_meta.get("common_pool_lane_prompt_effect_verified") is not True
        or dispatch_meta.get("common_context_effect_status")
        != "model_attempt_consumed_lane_prompt_with_verified_effective_suffix"
        or dispatch_meta.get("completion_claim_allowed") is not False
        or not _same_path(
            Path(str(dispatch_meta.get("common_contract_path") or "")),
            Path(prepared_contract_ref["path"]),
        )
        or not _same_path(
            Path(str(dispatch_meta.get("common_effective_prompt_file") or "")),
            Path(effective_ref["path"]),
        )
        or dispatch_meta.get("common_effective_prompt_sha256")
        != effective_ref["sha256"]
        or dispatch_meta.get("common_effective_prompt_bytes") != len(effective_raw)
        or dispatch_meta.get("pool_summary_sha256") != pool_summary_ref["sha256"]
        or not _same_path(
            Path(str(dispatch_meta.get("pool_summary_path") or "")),
            Path(pool_summary_ref["path"]),
        )
    ):
        raise ValueError(
            "worker-pool dispatch metadata does not prove model-input effect"
        )
    if not lane_prompt_raw.endswith(effective_raw):
        raise ValueError(
            "worker-pool lane prompt does not end with the common effective prompt"
        )

    rows = pool_summary.get("results")
    usage = pool_summary.get("usage")
    if (
        pool_summary.get("schema_version") != "xinao.grok_worker_pool.v2"
        or pool_summary.get("pool_id") != pool_id
        or pool_summary.get("n") != 1
        or pool_summary.get("usage_accounting_complete") is not True
        or not isinstance(usage, Mapping)
        or int(usage.get("attempt_count") or 0) < 1
        or int(usage.get("input_tokens") or 0) < 1
        or not isinstance(rows, list)
        or len(rows) != 1
        or not isinstance(rows[0], Mapping)
        or rows[0].get("status")
        not in {"accepted", "rejected", "timeout", "incomplete"}
        or rows[0].get("outcome")
        not in {"accepted", "rejected", "timeout", "incomplete"}
    ):
        raise ValueError(
            "worker-pool summary does not prove one accepted model attempt"
        )
    row = rows[0]
    if (
        attempt_lineage.get("workflow_id") != pool_id
        or row.get("run_id") != attempt_observed.get("executor_id")
        or not _same_path(
            Path(str(row.get("meta_path") or "")).resolve(strict=True),
            Path(provider_evidence_ref["path"]),
        )
    ):
        raise ValueError(
            "worker-pool summary does not bind the common attempt provider evidence"
        )
    preflight = row.get("common_contract_preflight")
    if (
        not isinstance(preflight, Mapping)
        or preflight.get("validated") is not True
        or preflight.get("logical_contract_sha256") != logical_contract_sha256
        or preflight.get("input_sha256") != contract_input_sha
        or preflight.get("rules_sha256") != rules_ref["sha256"]
    ):
        raise ValueError(
            "worker-pool lane preflight does not bind the common contract input"
        )

    binding = {
        "schema_version": "xinao.worker_model_input_binding.v1",
        "package_id": str(package.get("package_id") or ""),
        "work_key": str(package.get("work_key") or ""),
        "logical_operation_id": operation_id,
        "dispatch_id": dispatch_id,
        "pool_id": pool_id,
        "package_prompt_ref": package_prompt_ref,
        "sealed_package_prompt_ref": sealed_prompt_ref,
        "sealed_input_catalog_ref": catalog_ref,
        "common_prepare_receipt_ref": prepare_ref,
        "common_effective_prompt_ref": effective_ref,
        "common_contract_ref": _hash_bound_ref(contract_path, contract_sha256),
        "common_attempt_ref": common_attempt_ref,
        "prepared_common_contract_ref": prepared_contract_ref,
        "logical_contract_sha256": logical_contract_sha256,
        "dispatch_meta_ref": dispatch_meta_ref,
        "pool_summary_ref": pool_summary_ref,
        "pool_lane_prompt_ref": lane_prompt_ref,
        "authority": False,
        "completion_claim_allowed": False,
    }
    raw = (
        json.dumps(binding, ensure_ascii=False, indent=2, sort_keys=True).encode(
            "utf-8"
        )
        + b"\n"
    )
    return _write_or_verify_immutable(attempt_root / "model-input-binding.json", raw)


def _terminal_lane_missing_common_failure(lane: Mapping[str, Any]) -> dict[str, str]:
    raw_error = str(lane.get("error") or "").strip()
    match = re.search(r"\b((?:GROK|CODEX|XINAO)_[A-Z0-9_]+)\b", raw_error)
    provider_failure_code = match.group(1) if match else "UNCLASSIFIED_LANE_FAILURE"
    return {
        "failure": (
            "terminal lane has no valid common receipt; "
            f"provider_failure_code={provider_failure_code}"
        ),
        "provider_failure_code": provider_failure_code,
        "provider_lane_status": str(lane.get("status") or "unknown"),
        "provider_lane_outcome": str(lane.get("outcome") or "unknown"),
    }


def _terminal_side_effect_id(
    *, logical_operation_id: str, attempt: int, dispatch_id: str
) -> str:
    return (
        "se:worker-terminal:"
        f"{logical_operation_id}:attempt-{int(attempt)}:retry-{dispatch_id}"
    )


def _build_worker_terminal_event(
    *,
    builder: Callable[..., dict[str, Any]],
    package: dict[str, Any],
    result: dict[str, Any],
    package_manifest_ref: dict[str, str],
    dispatch_envelope_ref: dict[str, str],
    leg: str,
) -> dict[str, Any]:
    return builder(
        event_type="worker_terminal",
        parent_work_key=package["parent_work_key"],
        work_key=package["work_key"],
        package_id=package["package_id"],
        package_manifest_ref=package_manifest_ref,
        dispatch_envelope_ref=dispatch_envelope_ref,
        logical_operation_id=result["operation_id"],
        leg=leg,
        role=package["role"],
        artifact_refs=list(result["event_artifact_refs"]),
        common_attempt_ref={
            "path": result["common_attempt_ref"],
            "sha256": result["common_attempt_sha256"],
        },
        common_contract_ref={
            "path": result["common_contract_ref"],
            "sha256": result["common_contract_sha256"],
        },
        model_input_binding_ref=(
            dict(result["model_input_binding_ref"])
            if isinstance(result.get("model_input_binding_ref"), Mapping)
            else None
        ),
    )


def _terminate_process_tree(process: subprocess.Popen[str]) -> None:
    """Terminate only the exact provider wrapper tree started by this runner."""

    if process.poll() is not None:
        return
    if os.name == "nt":
        subprocess.run(
            ["taskkill", "/PID", str(process.pid), "/T", "/F"],
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=WINDOWLESS_CREATIONFLAGS,
        )
    else:
        process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)


def _run_process_with_live_guard(
    command: list[str],
    *,
    timeout_seconds: int,
    live_guard: Callable[[], object],
) -> subprocess.CompletedProcess[str]:
    """Run one provider wrapper while periodically re-reading task-run guards."""

    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
        creationflags=WINDOWLESS_CREATIONFLAGS,
    )
    deadline = time.monotonic() + timeout_seconds
    try:
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise subprocess.TimeoutExpired(command, timeout_seconds)
            try:
                stdout, stderr = process.communicate(timeout=min(2.0, remaining))
            except subprocess.TimeoutExpired:
                live_guard()
                continue
            return subprocess.CompletedProcess(
                command, int(process.returncode or 0), stdout, stderr
            )
    except BaseException:
        _terminate_process_tree(process)
        raise


def _run_package(
    *,
    package: dict[str, Any],
    candidate_cwd: Path,
    manifest_path: Path,
    manifest_sha256: str,
    dispatch_envelope_path: Path,
    dispatch_envelope_sha256: str,
    dispatch_script: Path,
    pwsh: str,
    runtime_root: Path,
    model: str,
    selection_path: Path,
    selection_sha256: str,
    dispatch_epoch: dict[str, Any],
    selector_root: Path,
    selector_python: Path,
    route_claim_evidence_ref: str,
    route_choice_sha256: str,
    physical_consumer_id: str,
    task_run_dir: Path,
    task_run_id: str,
    common_contract_binding: Mapping[str, str],
    validate_dispatch_route_claim: Callable[..., dict[str, Any]],
    timeout_sec: int,
    validate_attempt_receipt: Callable[[dict[str, Any], dict[str, Any]], Any],
) -> dict[str, Any]:
    package_id = str(package["package_id"])
    effective_cwd = _require_exact_candidate_cwd(
        package=package,
        candidate_cwd=candidate_cwd,
        selector_root=selector_root,
        runtime_root=runtime_root,
    )

    def live_route_guard() -> dict[str, Any]:
        validation = validate_dispatch_route_claim(
            route_claim_evidence_ref=route_claim_evidence_ref,
            dispatch_envelope_ref={
                "path": str(dispatch_envelope_path),
                "sha256": dispatch_envelope_sha256,
            },
            expected_task_run_dir=task_run_dir,
            expected_run_id=task_run_id,
        )
        _require_route_claim_binding(
            validation,
            route_choice_sha256=route_choice_sha256,
            physical_consumer_id=physical_consumer_id,
            final_start_gate=True,
        )
        return validation

    live_route_guard()
    if package.get("write_domains"):
        raise ValueError(
            "candidate-only package cannot pass authority write domains to leg A"
        )
    rules_ref = _package_artifact_ref(
        package,
        "rules_ref",
        expected_sha256_field="rules_sha256",
    )
    sealed_model_input = _prepare_sealed_model_input(
        package=package,
        task_run_dir=task_run_dir,
    )
    candidate_write_domain = _candidate_write_domain(effective_cwd)
    dispatch_id = _identifier("cdx")
    pool_id = _identifier("gwp")
    operation_id = _operation_id(package)
    if (
        common_contract_binding.get("binding_source")
        == "prior_accepted_ancestor_manifest"
    ):
        contract_binding_args = [
            "-CommonLogicalContractPath",
            str(common_contract_binding["prior_logical_contract_ref"]),
            "-CommonSubjectManifestSha256",
            str(common_contract_binding["subject_manifest_sha256"]),
            "-CommonFrozenContextSha256",
            str(common_contract_binding["frozen_context_sha256"]),
        ]
    else:
        contract_binding_args = [
            "-CommonTaskContractRef",
            str(common_contract_binding["task_contract_ref"]),
            "-CommonSubjectManifestSha256",
            str(common_contract_binding["subject_manifest_sha256"]),
            "-CommonContextManifestPath",
            str(package["context_manifest_ref"]["path"]),
        ]
    command = [
        pwsh,
        "-NoProfile",
        "-NonInteractive",
        "-File",
        str(dispatch_script),
        "-N",
        "1",
        "-PromptFile",
        str(sealed_model_input["effective_prompt_ref"]["path"]),
        "-Cwd",
        str(effective_cwd),
        "-Model",
        model,
        "-SelectionPath",
        str(selection_path),
        "-ExpectedSelectionDecisionSha256",
        selection_sha256,
        "-RuntimeRoot",
        str(runtime_root),
        "-DispatchEpochId",
        str(dispatch_epoch["epoch_id"]),
        "-DispatchEpochSource",
        "neutral_package_manifest",
        "-QuotaSnapshotId",
        str(dispatch_epoch["quota_snapshot_id"]),
        "-QuotaSnapshotRef",
        str(dispatch_epoch["quota_snapshot_ref"]),
        "-QuotaSnapshotSha256",
        str(dispatch_epoch["quota_snapshot_sha256"]),
        "-QuotaResolutionStatus",
        "sealed_manifest",
        "-CommonWorkKey",
        str(package["work_key"]),
        "-CommonOperationId",
        operation_id,
        "-CommonCorrelationId",
        str(package["parent_work_key"]),
        *contract_binding_args,
        "-CommonRulesFile",
        rules_ref["path"],
        "-CommonRulesSha256",
        rules_ref["sha256"],
        "-CommonSealedInputRoot",
        str(sealed_model_input["host_root"]),
        "-CommonCandidateOutputRoot",
        str(effective_cwd),
        "-CommonPhase",
        str(package["phase"]),
        "-CommonAdapterRoot",
        str(selector_root),
        "-CommonPythonExe",
        str(selector_python),
        "-MinResultChars",
        str(package["acceptance"]["min_result_chars"]),
        "-TimeoutSec",
        str(min(timeout_sec, int(package["timeout_sec"]))),
        "-DispatchId",
        dispatch_id,
        "-PoolId",
        pool_id,
        "-Quiet",
        "-CommonWriteDomains",
        candidate_write_domain,
    ]
    if package["acceptance"]["required_result_markers"]:
        # Native -> pwsh -File argument binding does not preserve multiple
        # values for a PowerShell array parameter. Carry the complete list as
        # one JSON argument so the wrapper can reconstruct it losslessly.
        command.extend(
            [
                "-RequiredResultMarkersJson",
                json.dumps(
                    package["acceptance"]["required_result_markers"],
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
            ]
        )
    if package["acceptance"]["require_json_object"]:
        command.append("-RequireJsonObject")
        command.extend(
            ["-JsonSchemaPath", str(package["acceptance"]["json_schema_ref"]["path"])]
        )
    if package["depends_on"]:
        command.append("-CommonDependsOn")
        command.extend(
            _common_dependency_arg(dependency) for dependency in package["depends_on"]
        )
    prior = package.get("prior_attempt_receipt_ref")
    if isinstance(prior, dict) and prior.get("path"):
        command.extend(["-CommonPriorAttemptReceiptPath", str(prior["path"])])
    # The first validation admits construction of this package invocation.
    # Re-read the live scoped mutation guards at the physical side-effect
    # boundary so a pause/stop racing with command assembly cannot start the
    # provider from a stale route claim.
    live_route_guard()
    completed = _run_process_with_live_guard(
        command,
        timeout_seconds=max(30, min(timeout_sec, int(package["timeout_sec"])) + 60),
        live_guard=live_route_guard,
    )
    try:
        _revalidate_sealed_model_input(sealed_model_input)
    except (OSError, TypeError, ValueError) as exc:
        return {
            "package_id": package_id,
            "work_key": package["work_key"],
            "operation_id": operation_id,
            "dispatch_id": dispatch_id,
            "pool_id": pool_id,
            "exit_code": completed.returncode,
            "status": "failed",
            "failure": f"sealed model input integrity failed after provider: {exc}",
            "sealed_input_catalog_ref": sealed_model_input["catalog_ref"],
            "effective_package_prompt_ref": sealed_model_input["effective_prompt_ref"],
        }
    pool_summary = (
        runtime_root / "state" / "grok_worker_pool" / pool_id / "pool_summary.json"
    )
    result: dict[str, Any] = {
        "package_id": package_id,
        "work_key": package["work_key"],
        "operation_id": operation_id,
        "dispatch_id": dispatch_id,
        "pool_id": pool_id,
        "common_contract_binding": dict(common_contract_binding),
        "exit_code": completed.returncode,
        "stdout_tail": completed.stdout[-2000:],
        "stderr_tail": completed.stderr[-2000:],
        "pool_summary_ref": str(pool_summary),
        "sealed_input_catalog_ref": sealed_model_input["catalog_ref"],
        "effective_package_prompt_ref": sealed_model_input["effective_prompt_ref"],
    }
    if not pool_summary.is_file():
        result.update(
            status="failed", failure="singleton dispatch did not produce a pool summary"
        )
        return result
    summary = _load_object(pool_summary, "pool summary")
    if (
        summary.get("n") != 1
        or summary.get("model") != model
        or summary.get("selection_decision_sha256") != selection_sha256
    ):
        result.update(status="failed", failure="singleton pool identity drifted")
        return result
    rows = summary.get("results")
    if summary.get("reuse_skipped_execution") is True:
        result.update(
            status="reused",
            pool_summary_sha256=_sha(pool_summary),
            reuse_disposition=summary.get("reuse_disposition"),
        )
        return result
    if not isinstance(rows, list) or len(rows) != 1 or not isinstance(rows[0], dict):
        result.update(
            status="failed", failure="singleton pool did not expose one terminal lane"
        )
        return result
    lane = dict(rows[0])
    meta_path = Path(str(lane.get("meta_path") or ""))
    try:
        located_common = _locate_common_receipt(summary, lane)
    except (OSError, ValueError) as exc:
        result.update(status="failed", failure=f"common receipt invalid: {exc}")
        return result
    if located_common is None:
        result.update(status="failed", **_terminal_lane_missing_common_failure(lane))
        return result
    common_receipt_path, common_receipt_sha = located_common
    common = _load_object(common_receipt_path, "common adapter receipt")
    attempt_path = Path(
        str((common.get("artifact_paths") or {}).get("attempt_receipt") or "")
    )
    attempt_sha = str(
        (common.get("artifact_sha256") or {}).get("attempt_receipt") or ""
    )
    contract_path = Path(
        str((common.get("artifact_paths") or {}).get("logical_contract") or "")
    )
    contract_sha = str(
        (common.get("artifact_sha256") or {}).get("logical_contract") or ""
    )
    if (
        common.get("work_key") != package["work_key"]
        or common.get("logical_operation_id") != operation_id
        or not attempt_path.is_file()
        or _sha(attempt_path) != attempt_sha
        or not contract_path.is_file()
        or _sha(contract_path) != contract_sha
    ):
        result.update(
            status="failed", failure="common receipt package identity drifted"
        )
        return result
    contract = _load_object(contract_path, "common logical contract")
    attempt_receipt = _load_object(attempt_path, "common attempt receipt")
    try:
        validate_attempt_receipt(
            contract,
            attempt_receipt,
            expected_consumer_id=EXPECTED_DIRECT_ATTEMPT_CONSUMER_ID,
        )
    except (TypeError, ValueError) as exc:
        result.update(status="failed", failure=f"common attempt receipt invalid: {exc}")
        return result
    if (
        contract.get("logical_operation_id") != operation_id
        or contract.get("work_key") != package["work_key"]
        or attempt_receipt.get("logical_operation_id") != operation_id
        or attempt_receipt.get("work_key") != package["work_key"]
    ):
        result.update(
            status="failed", failure="common contract or attempt identity drifted"
        )
        return result
    attempt_number = attempt_receipt.get("attempt")
    if (
        isinstance(attempt_number, bool)
        or not isinstance(attempt_number, int)
        or attempt_number < 1
    ):
        result.update(status="failed", failure="common attempt number is invalid")
        return result

    output_root = effective_cwd
    attempt_root = output_root / f"attempt-{attempt_number:04d}-{dispatch_id}"
    try:
        model_input_binding_ref = _materialize_model_input_binding(
            package=package,
            sealed_model_input=sealed_model_input,
            contract=contract,
            contract_path=contract_path,
            contract_sha256=contract_sha,
            logical_contract_sha256=str(attempt_receipt.get("contract_sha256") or ""),
            attempt_receipt=attempt_receipt,
            attempt_path=attempt_path,
            attempt_sha256=attempt_sha,
            pool_summary=summary,
            pool_summary_path=pool_summary,
            runtime_root=runtime_root,
            dispatch_id=dispatch_id,
            pool_id=pool_id,
            operation_id=operation_id,
            subject_manifest_sha256=manifest_sha256,
            attempt_root=attempt_root,
        )
    except (OSError, TypeError, ValueError, json.JSONDecodeError) as exc:
        result.update(
            status="failed",
            failure=f"model input binding invalid: {exc}",
            common_attempt_ref=str(attempt_path),
            common_attempt_sha256=attempt_sha,
            common_contract_ref=str(contract_path),
            common_contract_sha256=contract_sha,
            attempt=attempt_number,
        )
        return result
    control_artifact_refs: list[dict[str, str]] = [
        dict(sealed_model_input["catalog_ref"]),
        dict(sealed_model_input["effective_prompt_ref"]),
        _hash_bound_ref(common_receipt_path, common_receipt_sha),
        _hash_bound_ref(attempt_path, attempt_sha),
        _hash_bound_ref(contract_path, contract_sha),
        _hash_bound_ref(pool_summary),
    ]
    if model_input_binding_ref is not None:
        control_artifact_refs.append(model_input_binding_ref)
    provider_artifact_refs: list[dict[str, str]] = []
    provider_output_ref: dict[str, str] | None = None
    provider_cli_ref: dict[str, str] | None = None
    provider_meta_ref: dict[str, str] | None = None
    sealed_input_readback_ref: dict[str, str] | None = None
    provider_chat_history_ref: dict[str, str] | None = None
    provider_output_error = ""
    try:
        expected_meta_sha = (
            str(common.get("provider_evidence_sha256") or "").strip().lower()
        )
        expected_meta_path = str(common.get("provider_evidence_ref") or "").strip()
        meta, provider_meta_ref = _load_hash_bound_object(
            meta_path,
            "provider lane metadata",
            expected_meta_sha or None,
        )
        if expected_meta_path and (
            Path(expected_meta_path).resolve(strict=False)
            != Path(provider_meta_ref["path"]).resolve(strict=False)
        ):
            raise ValueError(
                "provider metadata does not match common receipt evidence path"
            )
        if (
            meta.get("container_sealed_input_read_only") is not True
            or meta.get("container_sealed_input_root")
            != sealed_model_input["container_root"]
            or not _same_path(
                Path(str(meta.get("sealed_input_root") or "")),
                Path(str(sealed_model_input["host_root"])),
            )
        ):
            raise ValueError(
                "provider metadata does not prove the sealed input read-only mount"
            )
        readback = _verify_sealed_input_tool_readback(
            meta=meta,
            binding=sealed_model_input,
        )
        sealed_input_readback_ref = {
            "path": readback["path"],
            "sha256": readback["sha256"],
        }
        provider_chat_history_ref = {
            "path": readback["chat_history_path"],
            "sha256": readback["chat_history_sha256"],
        }
        cli_json = Path(str(meta.get("cli_json") or ""))
        cli_payload, provider_cli_ref = _load_hash_bound_object(
            cli_json, "provider CLI JSON"
        )
        final_text = _extract_cli_final_text(cli_payload, meta)
        provider_output_path = attempt_root / "provider-output"
        provider_output_sha = _atomic_bytes(
            provider_output_path, final_text.encode("utf-8")
        )
        provider_output_ref = {
            "path": str(provider_output_path.resolve(strict=True)),
            "sha256": provider_output_sha,
        }
        expected_output_sha = str(
            (attempt_receipt.get("output") or {}).get("content_sha256") or ""
        ).lower()
        if provider_output_sha != expected_output_sha:
            raise ValueError(
                "provider-output sha256 does not match common attempt output.content_sha256: "
                f"expected={expected_output_sha}; observed={provider_output_sha}"
            )
    except (OSError, TypeError, ValueError, json.JSONDecodeError) as exc:
        provider_output_error = str(exc)

    if provider_output_error:
        result.update(
            status="failed",
            failure=provider_output_error,
            common_attempt_ref=str(attempt_path),
            common_attempt_sha256=attempt_sha,
            common_contract_ref=str(contract_path),
            common_contract_sha256=contract_sha,
            attempt=attempt_number,
        )
        return result
    if sealed_input_readback_ref is not None:
        control_artifact_refs.append(sealed_input_readback_ref)
    for ref in (
        provider_output_ref,
        provider_cli_ref,
        provider_meta_ref,
        provider_chat_history_ref,
    ):
        if ref is not None and ref not in provider_artifact_refs:
            provider_artifact_refs.append(ref)

    artifact_refs = [*control_artifact_refs, *provider_artifact_refs]

    envelope = {
        "schema_version": "xinao.worker_package_result.v2",
        "package_id": package_id,
        "work_key": package["work_key"],
        "parent_work_key": package["parent_work_key"],
        "logical_operation_id": operation_id,
        "attempt": attempt_number,
        "dispatch_id": dispatch_id,
        "pool_id": pool_id,
        "role": package["role"],
        "selection_decision_sha256": selection_sha256,
        "package_manifest_ref": _hash_bound_ref(manifest_path, manifest_sha256),
        "dispatch_envelope_ref": _hash_bound_ref(
            dispatch_envelope_path, dispatch_envelope_sha256
        ),
        "common_adapter_receipt_ref": _hash_bound_ref(
            common_receipt_path, common_receipt_sha
        ),
        "common_attempt_ref": _hash_bound_ref(attempt_path, attempt_sha),
        "common_contract_ref": _hash_bound_ref(contract_path, contract_sha),
        "provider_output_ref": provider_output_ref,
        "sealed_input_catalog_ref": sealed_model_input["catalog_ref"],
        "effective_package_prompt_ref": sealed_model_input["effective_prompt_ref"],
        "model_input_binding_ref": model_input_binding_ref,
        "sealed_input_readback_ref": sealed_input_readback_ref,
        "provider_chat_history_ref": provider_chat_history_ref,
        "artifact_refs": artifact_refs,
        "authority": False,
        "completion_claim_allowed": False,
    }
    envelope_path = attempt_root / "package-result.json"
    envelope_sha = _atomic_json(envelope_path, envelope)
    artifact_refs.append(
        {"path": str(envelope_path.resolve(strict=True)), "sha256": envelope_sha}
    )
    result.update(
        status="terminal_ready",
        terminal_recordable=True,
        package_result_ref=str(envelope_path),
        package_result_sha256=envelope_sha,
        provider_output_ref=provider_output_ref,
        sealed_input_readback_ref=sealed_input_readback_ref,
        provider_chat_history_ref=provider_chat_history_ref,
        common_attempt_ref=str(attempt_path),
        common_attempt_sha256=attempt_sha,
        common_contract_ref=str(contract_path),
        common_contract_sha256=contract_sha,
        common_adapter_receipt_ref=str(common_receipt_path),
        common_adapter_receipt_sha256=common_receipt_sha,
        model_input_binding_ref=model_input_binding_ref,
        attempt=attempt_number,
        event_artifact_refs=provider_artifact_refs,
        pool_summary_sha256=_sha(pool_summary),
    )
    return result


def _append_task_run_event(
    *,
    task_run_cli: Path,
    task_run_root: Path,
    task_run_id: str,
    event_path: Path,
    event_sha256: str,
    work_key: str,
    package_id: str,
    logical_operation_id: str,
    attempt: int,
    dispatch_id: str,
    provider_accepted: bool,
    provider_exit_code: int,
) -> None:
    terminal_label = "accepted" if provider_accepted else "rejected"
    exit_code = 0 if provider_accepted else (provider_exit_code or 3)
    command = [
        sys.executable,
        str(task_run_cli),
        "--root",
        str(task_run_root),
        "event",
        "--run-id",
        task_run_id,
        "--event-id",
        f"evt-dispatch-{event_sha256[:32]}",
        "--actor",
        "grok-worker-pool",
        "--kind",
        "result",
        "--phase",
        "worker_terminal",
        "--summary",
        (
            f"provider {terminal_label} package {package_id}; "
            f"operation={logical_operation_id}; attempt={attempt}; retry={dispatch_id}"
        ),
        "--evidence-ref",
        f"{event_path}#sha256={event_sha256}",
        "--target",
        work_key,
        "--exit-code",
        str(exit_code),
        "--retry-class",
        "none",
        "--side-effect-id",
        _terminal_side_effect_id(
            logical_operation_id=logical_operation_id,
            attempt=attempt,
            dispatch_id=dispatch_id,
        ),
    ]
    completed = subprocess.run(
        command,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        creationflags=WINDOWLESS_CREATIONFLAGS,
    )
    if completed.returncode != 0:
        raise RuntimeError(
            f"task-run append failed exit={completed.returncode}: {completed.stderr.strip()}"
        )


def _append_task_run_non_conversion(
    *,
    task_run_cli: Path,
    task_run_root: Path,
    task_run_id: str,
    result: Mapping[str, Any],
) -> bool:
    pool_summary = Path(str(result.get("pool_summary_ref") or ""))
    if not pool_summary.is_file():
        return False
    observed_pool_summary_sha = _sha(pool_summary)
    declared_pool_summary_sha = str(result.get("pool_summary_sha256") or "").lower()
    if declared_pool_summary_sha and (
        not re.fullmatch(r"[0-9a-f]{64}", declared_pool_summary_sha)
        or declared_pool_summary_sha != observed_pool_summary_sha
    ):
        raise RuntimeError(
            "pool summary sha256 drifted before non-conversion recording"
        )
    pool_summary_sha = observed_pool_summary_sha
    package_id = str(result.get("package_id") or "unknown-package")
    work_key = str(result.get("work_key") or "unknown-work-key")
    failure = str(
        result.get("failure") or "dispatch attempt did not reach worker_terminal"
    )
    provider_exit_code = int(result.get("exit_code") or 0)
    retry_class = str(result.get("retry_class") or "").lower()
    if retry_class not in {"transient", "deterministic"}:
        failure_lower = failure.lower()
        retry_class = (
            "transient"
            if result.get("timed_out") is True or "timeout" in failure_lower
            else "deterministic"
        )
    command = [
        sys.executable,
        str(task_run_cli),
        "--root",
        str(task_run_root),
        "event",
        "--run-id",
        task_run_id,
        "--event-id",
        f"evt-dispatch-nonconversion-{pool_summary_sha[:24]}",
        "--actor",
        "grok-worker-pool",
        "--kind",
        "failure",
        "--phase",
        "dispatch_attempt_non_conversion",
        "--summary",
        f"package {package_id} did not convert to worker_terminal: {failure}",
        "--evidence-ref",
        f"{pool_summary.resolve(strict=True)}#sha256={pool_summary_sha}",
        "--target",
        work_key,
        "--exit-code",
        str(provider_exit_code or 20),
        "--retry-class",
        retry_class,
        "--side-effect-id",
        f"se:dispatch-nonconversion:{task_run_id}:{pool_summary_sha[:32]}",
    ]
    completed = subprocess.run(
        command,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        creationflags=WINDOWLESS_CREATIONFLAGS,
    )
    if completed.returncode != 0:
        raise RuntimeError(
            "task-run non-conversion append failed "
            f"exit={completed.returncode}: {completed.stderr.strip()}"
        )
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--dispatch-envelope",
        "--manifest",
        dest="dispatch_envelope",
        type=Path,
        required=True,
    )
    parser.add_argument("--selector-root", type=Path, required=True)
    parser.add_argument("--selector-python", type=Path, required=True)
    parser.add_argument("--dispatch-script", type=Path, required=True)
    parser.add_argument("--pwsh", default="pwsh")
    parser.add_argument("--runtime-root", type=Path, required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--selection-path", type=Path, required=True)
    parser.add_argument("--checkpoint-path", type=Path, required=True)
    parser.add_argument("--task-run-cli", type=Path, required=True)
    parser.add_argument("--task-run-root", type=Path, required=True)
    parser.add_argument("--task-run-id", required=True)
    parser.add_argument("--summary-output", type=Path, required=True)
    parser.add_argument("--timeout-sec", type=int, default=600)
    args = parser.parse_args()

    selector_root = args.selector_root.resolve(strict=True)
    sys.path.insert(0, str(selector_root))
    dispatch_contract = importlib.import_module(
        "services.agent_runtime.dispatch_economics"
    )
    _require_dispatch_contract_pin(dispatch_contract)
    build_dispatch_outcome_event = dispatch_contract.build_dispatch_outcome_event
    claim_dispatch_route = dispatch_contract.claim_dispatch_route
    plan_package_frontier = dispatch_contract.plan_package_frontier
    validate_candidate_consumer_binding = (
        dispatch_contract.validate_candidate_consumer_binding
    )
    validate_dispatch_envelope = dispatch_contract.validate_dispatch_envelope
    validate_dispatch_route_claim = dispatch_contract.validate_dispatch_route_claim
    from services.agent_runtime.execution_contract import (  # type: ignore
        validate_attempt_receipt,
    )

    dispatch_envelope_path = args.dispatch_envelope.resolve(strict=True)
    dispatch_envelope_sha = _sha(dispatch_envelope_path)
    dispatch_envelope_raw = _load_object(
        dispatch_envelope_path, "worker dispatch envelope"
    )
    dispatch_envelope = validate_dispatch_envelope(dispatch_envelope_raw)
    direct_route = _require_direct_route_envelope(dispatch_envelope)
    manifest_path = Path(dispatch_envelope["package_manifest_ref"]["path"]).resolve(
        strict=True
    )
    manifest_sha = _sha(manifest_path)
    validated = dispatch_envelope["validated_package_manifest"]
    if dispatch_envelope["selection"]["model_id"] != args.model:
        raise ValueError(
            "dispatch envelope model does not match explicit launcher model"
        )
    selection_path = args.selection_path.resolve(strict=True)
    if str(selection_path) != str(
        Path(dispatch_envelope["selection"]["receipt_ref"]).resolve(strict=True)
    ):
        raise ValueError("dispatch envelope selection path mismatch")
    selection_sha = str(dispatch_envelope["selection"]["decision_sha256"])
    checkpoint_path = args.checkpoint_path.resolve(strict=True)
    task_run_cli = args.task_run_cli.resolve(strict=True)
    task_run_root = args.task_run_root.resolve(strict=True)
    task_run_id = str(args.task_run_id).strip()
    if not task_run_id:
        raise ValueError("task-run id must be non-empty")
    task_run_dir = (task_run_root / task_run_id).resolve(strict=True)
    if not task_run_dir.is_dir():
        raise ValueError(f"task-run directory missing: {task_run_dir}")

    admitted_ids = set(dispatch_envelope["package_ids"])
    frontier = plan_package_frontier(validated)
    planned_worker_ids = {
        str(row["package_id"])
        for row in frontier["admitted"]
        if row["candidate_only"] is True and row["execution_seal_ready"] is True
    }
    outside_frontier = sorted(admitted_ids - planned_worker_ids)
    if outside_frontier:
        raise ValueError(
            "dispatch envelope contains packages outside the planned worker frontier: "
            + ",".join(outside_frontier)
        )
    packages = {
        str(row["package_id"]): row
        for row in validated["packages"]
        if str(row["package_id"]) in admitted_ids
    }
    if set(packages) != admitted_ids:
        raise ValueError(
            "dispatch envelope package identities drifted after validation"
        )
    physical_consumer_id = str(dispatch_envelope["validated_physical_consumer_id"])
    requested_output_roots = {
        package_id: package["allowed_output_root"]
        for package_id, package in packages.items()
    }
    candidate_binding = validate_candidate_consumer_binding(
        dispatch_envelope_raw,
        physical_consumer_id=physical_consumer_id,
        expected_leg="A",
        requested_output_roots=requested_output_roots,
    )
    candidate_cwds = _candidate_cwds_from_binding(
        binding=candidate_binding,
        packages=packages,
        route_choice_sha256=direct_route["route_choice"]["choice_sha256"],
        physical_consumer_id=physical_consumer_id,
        selector_root=selector_root,
        runtime_root=args.runtime_root,
    )
    if _sha(manifest_path) != manifest_sha:
        raise ValueError("neutral package manifest changed during leg-A admission")

    common_contract_bindings = {
        package_id: _prior_reuse_contract_binding(
            package=package,
            validated_manifest=validated,
            current_manifest_path=manifest_path,
            current_manifest_sha256=manifest_sha,
            validate_attempt_receipt=validate_attempt_receipt,
        )
        for package_id, package in packages.items()
    }

    dispatch_envelope_ref = {
        "path": str(dispatch_envelope_path),
        "sha256": dispatch_envelope_sha,
    }
    route_claim = claim_dispatch_route(
        dispatch_envelope_ref=dispatch_envelope_ref,
        checkpoint_path=checkpoint_path,
        task_run_dir=task_run_dir,
        task_run_cli=task_run_cli,
        holder_id=f"grok-leg-a:{os.getpid()}",
    )
    if route_claim.get("status") not in {"won", "reused"}:
        raise ValueError("leg-A durable route claim did not reach won or reused")
    _require_route_claim_binding(
        route_claim,
        route_choice_sha256=direct_route["route_choice"]["choice_sha256"],
        physical_consumer_id=physical_consumer_id,
        final_start_gate=False,
    )
    route_claim_evidence_ref = str(route_claim.get("route_claim_evidence_ref") or "")
    if not route_claim_evidence_ref:
        raise ValueError("leg-A durable route claim has no evidence ref")
    route_claim_validation = validate_dispatch_route_claim(
        route_claim_evidence_ref=route_claim_evidence_ref,
        dispatch_envelope_ref=dispatch_envelope_ref,
        expected_task_run_dir=task_run_dir,
        expected_run_id=task_run_id,
    )
    _require_route_claim_binding(
        route_claim_validation,
        route_choice_sha256=direct_route["route_choice"]["choice_sha256"],
        physical_consumer_id=physical_consumer_id,
        final_start_gate=True,
    )
    runtime_dependencies = _runtime_worker_dependencies(packages)
    pending = set(packages)
    provider_satisfied: set[str] = set()
    provider_accepted: set[str] = set()
    reused: set[str] = set()
    failed: set[str] = set()
    blocked: set[str] = set()
    results: dict[str, dict[str, Any]] = {}
    active: dict[Future[dict[str, Any]], str] = {}
    max_parallel = int(validated["limits"]["max_parallel"])
    fan_in_capacity = int(validated["limits"]["fan_in_capacity"])
    backpressure_cycles = 0

    def submit(executor: ThreadPoolExecutor, package_id: str) -> None:
        package = packages[package_id]
        future = executor.submit(
            _run_package,
            package=package,
            candidate_cwd=candidate_cwds[package_id],
            manifest_path=manifest_path,
            manifest_sha256=manifest_sha,
            dispatch_envelope_path=dispatch_envelope_path,
            dispatch_envelope_sha256=dispatch_envelope_sha,
            dispatch_script=args.dispatch_script.resolve(strict=True),
            pwsh=args.pwsh,
            runtime_root=args.runtime_root.resolve(strict=False),
            model=args.model,
            selection_path=selection_path,
            selection_sha256=selection_sha,
            dispatch_epoch=dispatch_envelope["dispatch_epoch"],
            selector_root=selector_root,
            selector_python=args.selector_python.resolve(strict=True),
            route_claim_evidence_ref=route_claim_evidence_ref,
            route_choice_sha256=direct_route["route_choice"]["choice_sha256"],
            physical_consumer_id=physical_consumer_id,
            task_run_dir=task_run_dir,
            task_run_id=task_run_id,
            common_contract_binding=common_contract_bindings[package_id],
            validate_dispatch_route_claim=validate_dispatch_route_claim,
            timeout_sec=args.timeout_sec,
            validate_attempt_receipt=validate_attempt_receipt,
        )
        active[future] = package_id
        pending.remove(package_id)

    with ThreadPoolExecutor(max_workers=max_parallel) as executor:
        while pending or active:
            progress = True
            while progress:
                progress = False
                for package_id in sorted(
                    pending, key=lambda value: packages[value]["lane_index"]
                ):
                    ready, blocked_by = _pending_dependency_state(
                        package_id,
                        runtime_dependencies=runtime_dependencies,
                        provider_satisfied=provider_satisfied,
                        failed=failed,
                        blocked=blocked,
                    )
                    if blocked_by:
                        pending.remove(package_id)
                        blocked.add(package_id)
                        results[package_id] = {
                            "package_id": package_id,
                            "work_key": packages[package_id]["work_key"],
                            "status": "blocked_dependency",
                            "blocked_by": sorted(blocked_by),
                        }
                        progress = True
                        break
                    if ready and len(active) < max_parallel:
                        submit(executor, package_id)
                        progress = True
                        break
            if not active:
                if pending:
                    raise RuntimeError("package frontier stalled after validated DAG")
                break
            done, _ = wait(tuple(active), return_when=FIRST_COMPLETED)
            ordered_done = sorted(
                done, key=lambda future: packages[active[future]]["lane_index"]
            )
            if len(ordered_done) > fan_in_capacity:
                backpressure_cycles += 1
            for future in ordered_done[:fan_in_capacity]:
                package_id = active.pop(future)
                try:
                    result = future.result()
                except Exception as exc:
                    result = {
                        "package_id": package_id,
                        "work_key": packages[package_id]["work_key"],
                        "status": "failed",
                        "failure": f"{type(exc).__name__}: {exc}",
                    }
                results[package_id] = result
                if result.get("status") == "reused":
                    reused.add(package_id)
                    provider_satisfied.add(package_id)
                    continue
                if result.get("terminal_recordable") is not True:
                    try:
                        recorded = _append_task_run_non_conversion(
                            task_run_cli=task_run_cli,
                            task_run_root=task_run_root,
                            task_run_id=task_run_id,
                            result=result,
                        )
                        result["non_conversion_event_recorded"] = recorded
                        if not recorded:
                            result["non_conversion_recording_error"] = (
                                "pool summary unavailable; native usage could not be hash-bound"
                            )
                    except Exception as exc:
                        result["non_conversion_event_recorded"] = False
                        result["non_conversion_recording_error"] = (
                            f"{type(exc).__name__}: {exc}"
                        )
                    failed.add(package_id)
                    continue
                try:
                    package = packages[package_id]
                    event = _build_worker_terminal_event(
                        builder=build_dispatch_outcome_event,
                        package=package,
                        result=result,
                        package_manifest_ref={
                            "path": str(manifest_path),
                            "sha256": manifest_sha,
                        },
                        dispatch_envelope_ref={
                            "path": str(dispatch_envelope_path),
                            "sha256": dispatch_envelope_sha,
                        },
                        leg=str(dispatch_envelope["leg"]),
                    )
                    event_path = Path(result["package_result_ref"]).with_name(
                        "worker-terminal-event.json"
                    )
                    event_sha = _atomic_json(event_path, event)
                    _append_task_run_event(
                        task_run_cli=task_run_cli,
                        task_run_root=task_run_root,
                        task_run_id=task_run_id,
                        event_path=event_path,
                        event_sha256=event_sha,
                        work_key=str(package["work_key"]),
                        package_id=package_id,
                        logical_operation_id=str(result["operation_id"]),
                        attempt=int(result["attempt"]),
                        dispatch_id=str(result["dispatch_id"]),
                        provider_accepted=event["provider_accepted"] is True,
                        provider_exit_code=int(result["exit_code"]),
                    )
                    result["worker_terminal_event_ref"] = str(event_path)
                    result["worker_terminal_event_sha256"] = event_sha
                    if event["provider_accepted"] is True:
                        result["status"] = "accepted"
                        provider_accepted.add(package_id)
                        provider_satisfied.add(package_id)
                    else:
                        result["status"] = "rejected"
                        failed.add(package_id)
                except Exception as exc:
                    result["status"] = "failed"
                    result["failure"] = (
                        f"worker terminal recording failed: {type(exc).__name__}: {exc}"
                    )
                    try:
                        recorded = _append_task_run_non_conversion(
                            task_run_cli=task_run_cli,
                            task_run_root=task_run_root,
                            task_run_id=task_run_id,
                            result=result,
                        )
                        result["non_conversion_event_recorded"] = recorded
                        if not recorded:
                            result["non_conversion_recording_error"] = (
                                "pool summary unavailable; native usage could not be hash-bound"
                            )
                    except Exception as record_exc:
                        result["non_conversion_event_recorded"] = False
                        result["non_conversion_recording_error"] = (
                            f"{type(record_exc).__name__}: {record_exc}"
                        )
                    failed.add(package_id)

    ordered_results = [
        results[str(row["package_id"])]
        for row in validated["packages"]
        if str(row["package_id"]) in packages
    ]
    summary = {
        "schema_version": "xinao.grok_worker_package_batch_result.v2",
        "package_manifest_ref": {"path": str(manifest_path), "sha256": manifest_sha},
        "dispatch_envelope_ref": {
            "path": str(dispatch_envelope_path),
            "sha256": dispatch_envelope_sha,
        },
        "validated_manifest_sha256": validated["validated_manifest_sha256"],
        "selection_decision_sha256": selection_sha,
        "alternative_group_sha256": direct_route["route_choice"][
            "alternative_group_sha256"
        ],
        "route_choice_sha256": direct_route["route_choice"]["choice_sha256"],
        "route_transport_id": direct_route["selected_route"]["transport_id"],
        "dispatch_route_claim": {
            "status": route_claim["status"],
            "alternative_group_sha256": route_claim["alternative_group_sha256"],
            "choice_sha256": route_claim["choice_sha256"],
            "route_claim_evidence_ref": route_claim_evidence_ref,
        },
        "dispatch_epoch": {
            "epoch_id": dispatch_envelope["dispatch_epoch"]["epoch_id"],
            "quota_snapshot_id": dispatch_envelope["dispatch_epoch"][
                "quota_snapshot_id"
            ],
            "quota_snapshot_ref": dispatch_envelope["dispatch_epoch"][
                "quota_snapshot_ref"
            ],
            "quota_snapshot_sha256": dispatch_envelope["dispatch_epoch"][
                "quota_snapshot_sha256"
            ],
        },
        "max_parallel": max_parallel,
        "fan_in_capacity": fan_in_capacity,
        "backpressure_cycles": backpressure_cycles,
        "provider_accepted_package_ids": sorted(provider_accepted),
        "reused_package_ids": sorted(reused),
        "satisfied_package_ids": sorted(provider_satisfied),
        "failed_package_ids": sorted(failed),
        "blocked_package_ids": sorted(blocked),
        "results": ordered_results,
        "all_packages_satisfied": len(provider_satisfied) == len(packages),
        "authority": False,
        "completion_claim_allowed": False,
    }
    summary_sha = _atomic_json(args.summary_output.resolve(strict=False), summary)
    print(
        json.dumps(
            {
                "summary_ref": str(args.summary_output.resolve(strict=True)),
                "summary_sha256": summary_sha,
                "provider_accepted": len(provider_accepted),
                "reused": len(reused),
                "failed": len(failed),
                "blocked": len(blocked),
            },
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
    )
    return 0 if len(provider_satisfied) == len(packages) else 2


if __name__ == "__main__":
    raise SystemExit(main())
