#Requires -Version 5.1
<#
.SYNOPSIS
  Explicit leg-A entry: dispatch bounded Grok headless workers.
.DESCRIPTION
  Use when a bounded direct Grok batch has positive net benefit for parallel
  work, diagnosis, or evidence when selected by task fit or an existing
  leg-A route receipt. This is a normal bounded transport, not a fallback. Thin
  wrapper over Invoke-GrokWorkerPool.ps1; never durable truth.
.EXAMPLE
  .\Invoke-CodexDispatchGrokWorkerPool.ps1 -N 4 -Prompt "Implement X; write evidence" -Cwd E:\repo -Model grok-4.5
  .\Invoke-CodexDispatchGrokWorkerPool.ps1 -N 2 -PromptFile .\task.md -Cwd E:\repo -Model grok-4.5 -SelectionPath D:\decision.json
#>
param(
    [ValidateRange(1, 32)]
    [int]$N = 2,
    [string]$Prompt = "",
    [string]$PromptFile = "",
    [string]$Cwd = "",
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$Model,
    [string]$SelectionPath = "",
    [switch]$SelectionOnly,
    [string]$SelectionProbeGrokExe = "",
    [string]$SupervisorRoot = "",
    [string]$SelectorReleasePointer = "",
    [string]$DispatchEpochId = "",
    [string]$DispatchEpochSource = "",
    [int]$DispatchEpochMaxAgeSec = 0,
    [string]$QuotaSnapshotId = "",
    [string]$QuotaSnapshotRef = "",
    [string]$QuotaSnapshotSha256 = "",
    [string]$QuotaResolutionStatus = "",
    [string]$QuotaResolutionError = "",
    [string]$RuntimeRoot = "D:\XINAO_RESEARCH_RUNTIME",
    [string]$ExpectedSelectionDecisionSha256 = "",
    [string]$MaxTurns = "auto",
    [int]$TimeoutSec = 600,
    [string]$GrokHome = "C:\Users\xx363\.grok-bg-workers",
    [ValidateRange(1, 200000)]
    [int]$MinResultChars = 256,
    [string[]]$RequiredResultMarkers = @(),
    [string]$RequiredResultMarkersJson = "",
    [switch]$RequireJsonObject,
    [string]$JsonSchemaPath = "",
    [string]$CommonLogicalContractPath = "",
    [string]$CommonWorkKey = "",
    [string]$CommonOperationId = "",
    [string]$CommonTaskContractRef = "",
    [string]$CommonParentOperationId = "",
    [string]$CommonCorrelationId = "",
    [string]$CommonSubjectManifestSha256 = "",
    [string]$CommonFrozenContextSha256 = "",
    [string]$CommonContextManifestPath = "",
    [string]$CommonRulesFile = "",
    [string]$CommonRulesSha256 = "",
    [string]$CommonSealedInputRoot = "",
    [string]$CommonCandidateOutputRoot = "",
    [string]$CommonPhase = "",
    [string[]]$CommonWriteDomains = @(),
    [string[]]$CommonDependsOn = @(),
    [string]$CommonPriorAttemptReceiptPath = "",
    [string]$CommonAdapterRoot = "",
    [string]$CommonPythonExe = "",
    [switch]$AllowExceptionalDocker,
    [string]$DockerJustification = "",
    [string]$DispatchId = "",
    [string]$PoolId = "",
    [switch]$SkipPauseGate,
    [switch]$Quiet
)

$ErrorActionPreference = "Stop"

if ($SelectionOnly) {
    $selectionOnlyConflicts = [Collections.Generic.List[string]]::new()
    if ($N -ne 1) { $selectionOnlyConflicts.Add("N must be 1") }
    if (-not [string]::IsNullOrWhiteSpace($Prompt)) { $selectionOnlyConflicts.Add("Prompt is not allowed") }
    if (-not [string]::IsNullOrWhiteSpace($PromptFile)) { $selectionOnlyConflicts.Add("PromptFile is not allowed") }
    if (-not [string]::IsNullOrWhiteSpace($SelectionPath)) { $selectionOnlyConflicts.Add("SelectionPath is output-owned and must be omitted") }
    if (-not [string]::IsNullOrWhiteSpace($DispatchEpochId)) { $selectionOnlyConflicts.Add("DispatchEpochId is not allowed") }
    if (-not [string]::IsNullOrWhiteSpace($QuotaSnapshotId)) { $selectionOnlyConflicts.Add("QuotaSnapshotId is not allowed") }
    if (-not [string]::IsNullOrWhiteSpace($QuotaSnapshotRef)) { $selectionOnlyConflicts.Add("QuotaSnapshotRef is not allowed") }
    if (-not [string]::IsNullOrWhiteSpace($QuotaSnapshotSha256)) { $selectionOnlyConflicts.Add("QuotaSnapshotSha256 is not allowed") }
    foreach ($value in @(
        $CommonLogicalContractPath, $CommonWorkKey, $CommonOperationId,
        $CommonTaskContractRef, $CommonParentOperationId, $CommonCorrelationId,
        $CommonSubjectManifestSha256, $CommonFrozenContextSha256,
        $CommonContextManifestPath, $CommonRulesFile, $CommonRulesSha256,
        $CommonSealedInputRoot, $CommonCandidateOutputRoot, $CommonPhase,
        $CommonPriorAttemptReceiptPath, $CommonAdapterRoot
    )) {
        if (-not [string]::IsNullOrWhiteSpace([string]$value)) {
            $selectionOnlyConflicts.Add("Common contract fields are not allowed")
            break
        }
    }
    if (@($CommonWriteDomains).Count -gt 0 -or @($CommonDependsOn).Count -gt 0) {
        $selectionOnlyConflicts.Add("Common contract arrays are not allowed")
    }
    if ($selectionOnlyConflicts.Count -gt 0) {
        throw (
            "CODEX_GROK_SELECTION_ONLY_PREFLIGHT_FAILED: " +
            [string]::Join("; ", $selectionOnlyConflicts.ToArray())
        )
    }
}

function Write-GrokJsonAtomic {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [Parameter(Mandatory = $true)]
        [object]$Value,
        [switch]$CreateNew
    )

    $directory = Split-Path -Parent $Path
    $leaf = Split-Path -Leaf $Path
    $temporary = Join-Path $directory ("." + $leaf + "." + [guid]::NewGuid().ToString("N") + ".tmp")
    $backup = Join-Path $directory ("." + $leaf + "." + [guid]::NewGuid().ToString("N") + ".bak")
    $encoding = New-Object System.Text.UTF8Encoding $false
    try {
        $bytes = $encoding.GetBytes(($Value | ConvertTo-Json -Depth 8))
        $stream = [IO.File]::Open(
            $temporary,
            [IO.FileMode]::CreateNew,
            [IO.FileAccess]::Write,
            [IO.FileShare]::None
        )
        try {
            $stream.Write($bytes, 0, $bytes.Length)
            $stream.Flush()
        }
        finally {
            $stream.Dispose()
        }
        if ($CreateNew) {
            [IO.File]::Move($temporary, $Path)
        }
        elseif (Test-Path -LiteralPath $Path -PathType Leaf) {
            [IO.File]::Replace($temporary, $Path, $backup, $true)
        }
        else {
            [IO.File]::Move($temporary, $Path)
        }
    }
    finally {
        if (Test-Path -LiteralPath $temporary -PathType Leaf) {
            Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue
        }
        if (Test-Path -LiteralPath $backup -PathType Leaf) {
            Remove-Item -LiteralPath $backup -Force -ErrorAction SilentlyContinue
        }
    }
}

function Publish-GrokAdvisoryLatest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$SourcePath,
        [Parameter(Mandatory = $true)]
        [string]$DestinationPath
    )

    $mutex = [Threading.Mutex]::new($false, "Local\XinaoCodexGrokDispatchLatestV1")
    $acquired = $false
    try {
        try {
            $acquired = $mutex.WaitOne([TimeSpan]::FromSeconds(10))
        }
        catch [Threading.AbandonedMutexException] {
            $acquired = $true
        }
        if (-not $acquired) {
            return [pscustomobject]@{ published = $false; error = "latest_projection_mutex_timeout" }
        }
        $payload = Get-Content -LiteralPath $SourcePath -Raw -Encoding UTF8 |
            ConvertFrom-Json -ErrorAction Stop
        Write-GrokJsonAtomic -Path $DestinationPath -Value $payload
        return [pscustomobject]@{ published = $true; error = "" }
    }
    catch {
        return [pscustomobject]@{ published = $false; error = [string]$_.Exception.Message }
    }
    finally {
        if ($acquired) {
            try { $mutex.ReleaseMutex() } catch {}
        }
        $mutex.Dispose()
    }
}
if (-not [string]::IsNullOrWhiteSpace($RequiredResultMarkersJson)) {
    if (@($RequiredResultMarkers).Count -gt 0) {
        throw "CODEX_GROK_RESULT_MARKERS_AMBIGUOUS: use either RequiredResultMarkers or RequiredResultMarkersJson"
    }
    try {
        $decodedMarkers = @(
            $RequiredResultMarkersJson |
                ConvertFrom-Json -ErrorAction Stop
        )
    } catch {
        throw "CODEX_GROK_RESULT_MARKERS_JSON_INVALID"
    }
    if ($decodedMarkers.Count -lt 1 -or $decodedMarkers.Count -gt 32) {
        throw "CODEX_GROK_RESULT_MARKERS_JSON_COUNT_INVALID"
    }
    $normalizedMarkers = @()
    foreach ($marker in $decodedMarkers) {
        if ($marker -isnot [string] -or [string]::IsNullOrWhiteSpace([string]$marker)) {
            throw "CODEX_GROK_RESULT_MARKERS_JSON_ITEM_INVALID"
        }
        $normalizedMarkers += [string]$marker
    }
    if (@($normalizedMarkers | Select-Object -Unique).Count -ne $normalizedMarkers.Count) {
        throw "CODEX_GROK_RESULT_MARKERS_JSON_DUPLICATE"
    }
    $RequiredResultMarkers = $normalizedMarkers
}
$bridge = $PSScriptRoot
. (Join-Path $bridge "GrokWindowsPathIdentity.ps1")
$catalogTimeHelper = Join-Path $bridge "GrokAuthenticatedCatalogTime.ps1"
$catalogRefreshHelper = Join-Path $bridge "GrokAuthenticatedCatalogRefresh.ps1"
if (-not (Test-Path -LiteralPath $catalogTimeHelper -PathType Leaf)) {
    throw "CODEX_GROK_AUTHENTICATED_CATALOG_TIME_HELPER_MISSING: $catalogTimeHelper"
}
if (-not (Test-Path -LiteralPath $catalogRefreshHelper -PathType Leaf)) {
    throw "CODEX_GROK_AUTHENTICATED_CATALOG_REFRESH_HELPER_MISSING: $catalogRefreshHelper"
}
. $catalogTimeHelper
. $catalogRefreshHelper
$dispatchId = if ([string]::IsNullOrWhiteSpace($DispatchId)) {
    "cdx_" + (Get-Date -Format "yyyyMMddTHHmmss") + "_" + ([guid]::NewGuid().ToString("N").Substring(0, 8))
} else {
    $DispatchId
}
if ($dispatchId -notmatch '^cdx_[0-9]{8}T[0-9]{6}_[0-9a-f]{8}$') {
    throw "CODEX_GROK_DISPATCH_ID_INVALID: $dispatchId"
}
$poolId = if ([string]::IsNullOrWhiteSpace($PoolId)) {
    "gwp_" + (Get-Date -Format "yyyyMMddTHHmmss") + "_" + ([guid]::NewGuid().ToString("N").Substring(0, 8))
} else {
    $PoolId
}
if ($poolId -notmatch '^gwp_[0-9]{8}T[0-9]{6}_[0-9a-f]{8}$') {
    throw "CODEX_GROK_POOL_ID_INVALID: $poolId"
}
$pool = Join-Path $bridge "Invoke-GrokWorkerPool.ps1"
if (-not (Test-Path -LiteralPath $pool)) {
    throw "MISSING_FALLBACK_PATH: $pool — install/copy Invoke-GrokWorkerPool.ps1"
}
$selectionHelper = Join-Path $bridge "GrokWorkerSelectionReceipt.ps1"
if (-not (Test-Path -LiteralPath $selectionHelper -PathType Leaf)) {
    throw "CODEX_GROK_SELECTION_HELPER_MISSING: $selectionHelper"
}
$selectionResolver = Join-Path $bridge "resolve_grok_worker_selection_receipt.py"
$supervisorCapabilityHelper = Join-Path $bridge "GrokSupervisorRootCapability.ps1"
if (-not (Test-Path -LiteralPath $supervisorCapabilityHelper -PathType Leaf)) {
    throw "CODEX_GROK_SUPERVISOR_CAPABILITY_HELPER_MISSING: $supervisorCapabilityHelper"
}
. $supervisorCapabilityHelper
if ([string]::IsNullOrWhiteSpace($Model)) {
    throw "CODEX_GROK_MODEL_REQUIRED"
}
$priorReuseClassificationOnly = (
    -not $SelectionOnly -and
    -not [string]::IsNullOrWhiteSpace($CommonPriorAttemptReceiptPath)
)
$authenticatedCatalogRefresh = $null
if ([string]::IsNullOrWhiteSpace($SelectionPath)) {
    if ([string]::IsNullOrWhiteSpace($Cwd)) {
        throw "CODEX_GROK_CWD_REQUIRED"
    }
    $requestedModel = $Model.Trim()
    if (-not (Test-Path -LiteralPath $selectionResolver -PathType Leaf)) {
        throw "CODEX_GROK_SELECTION_RESOLVER_MISSING: $selectionResolver"
    }
    if (-not $priorReuseClassificationOnly) {
        $resolvedProbe = ""
        if (-not [string]::IsNullOrWhiteSpace($SelectionProbeGrokExe)) {
            try { $resolvedProbe = [IO.Path]::GetFullPath($SelectionProbeGrokExe) }
            catch { throw "CODEX_GROK_SELECTION_PROBE_INVALID: $SelectionProbeGrokExe" }
        }
        else {
            $resolvedProbe = [string](
                (Get-Command grok.exe -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Source)
            )
            if ([string]::IsNullOrWhiteSpace($resolvedProbe)) {
                $resolvedProbe = "C:\Users\xx363\.grok\bin\grok.exe"
            }
        }
        if (-not (Test-Path -LiteralPath $resolvedProbe -PathType Leaf)) {
            throw "CODEX_GROK_SELECTION_PROBE_MISSING: $resolvedProbe"
        }
        $previousGrokHome = $env:GROK_HOME
        try {
            $env:GROK_HOME = $GrokHome
            $selectionCatalogRefreshAction = {
                $previousProbeErrorPreference = $ErrorActionPreference
                try {
                    $ErrorActionPreference = "Continue"
                    $probeOutput = @(
                        & $resolvedProbe models 2>&1 | ForEach-Object { [string]$_ }
                    )
                    $probeExit = $LASTEXITCODE
                }
                finally {
                    $ErrorActionPreference = $previousProbeErrorPreference
                }
                [pscustomobject]@{
                    exit_code = $probeExit
                    stdout = $probeOutput -join "`n"
                    stderr = ""
                }
            }
            try {
                $authenticatedCatalogRefresh = Invoke-GrokAuthenticatedCatalogSingleFlight `
                    -GrokHome $GrokHome `
                    -Model $requestedModel `
                    -TtlSeconds 300 `
                    -RefreshAction $selectionCatalogRefreshAction
            }
            catch {
                if ([string]$_.Exception.Message -eq
                    "GROK_AUTHENTICATED_MODEL_CATALOG_REFRESH_FAILED: requested_model_absent") {
                    throw "CODEX_GROK_SELECTED_MODEL_UNHEALTHY: requested=$Model profile=$GrokHome"
                }
                throw
            }
        }
        finally {
            if ($null -eq $previousGrokHome) {
                Remove-Item Env:\GROK_HOME -ErrorAction SilentlyContinue
            }
            else {
                $env:GROK_HOME = $previousGrokHome
            }
        }
    }
    $supervisorCapability = Resolve-GrokSupervisorSelectorRoot `
        -SupervisorRoot $SupervisorRoot `
        -Cwd $Cwd `
        -SelectionResolver $selectionResolver `
        -RuntimeRoot $RuntimeRoot `
        -ReleasePointer $SelectorReleasePointer
    $resolvedSupervisorRoot = [string]$supervisorCapability.resolved_root
    $supervisorPython = [string]$supervisorCapability.python_executable
    if (-not (Test-Path -LiteralPath $RuntimeRoot -PathType Container)) {
        throw "CODEX_GROK_RUNTIME_ROOT_MISSING: $RuntimeRoot"
    }
    $selectionDir = Join-Path $RuntimeRoot ("state\grok_worker_selection\" + $dispatchId)
    $SelectionPath = Join-Path $selectionDir "selection.receipt.json"
    $expectedSelectorSha256 = [string]$supervisorCapability.selector_source_sha256
    $resolverOutput = @(
        & $supervisorPython -I -B $selectionResolver `
            --supervisor-root $resolvedSupervisorRoot `
            --runtime-root $RuntimeRoot `
            --model $requestedModel `
            --output $SelectionPath `
            --expected-selector-sha256 $expectedSelectorSha256 2>&1 |
            ForEach-Object { [string]$_ }
    )
    $resolverExit = $LASTEXITCODE
    if ($resolverExit -ne 0 -or -not (Test-Path -LiteralPath $SelectionPath -PathType Leaf)) {
        throw (
            "CODEX_GROK_SELECTION_RESOLUTION_FAILED: " +
            ($resolverOutput -join "`n")
        )
    }
}
. $selectionHelper
$selection = Read-GrokWorkerSelectionReceipt `
    -SelectionPath $SelectionPath `
    -Model $Model `
    -Cwd $Cwd `
    -RequiredPrefix "CODEX_GROK"
$SelectionPath = [string]$selection.selection_path
$Model = [string]$selection.model_id
$Cwd = [string]$selection.cwd
if ($SelectionOnly) {
    $selectionReceiptSha256 = (Get-FileHash -LiteralPath $SelectionPath -Algorithm SHA256).Hash.ToLowerInvariant()
    [ordered]@{
        schema_version = "xinao.codex_grok_selection_only_result.v1"
        selection_path = $SelectionPath
        selection_receipt_sha256 = $selectionReceiptSha256
        decision_sha256 = [string]$selection.decision_sha256
        provider_id = [string]$selection.provider_id
        profile_ref = [string]$selection.profile_ref
        model_id = [string]$selection.model_id
        transport_id = [string]$selection.transport_id
        selector_source_sha256 = [string]$supervisorCapability.selector_source_sha256
        selector_release_binding = $supervisorCapability.release_binding
        quota_query_performed = $false
        dispatch_artifact_created = $false
        pool_artifact_created = $false
        model_invocation_count = 0
        auth_recovery_admission = [ordered]@{
            schema_version = "xinao.grok.oauth_recovery_admission.v1"
            profile_ref = [IO.Path]::GetFullPath($GrokHome)
            authenticated_catalog_valid = $true
            selection_succeeded = $true
            oauth_allowed = $false
            oauth_forbidden_reason = "selection_only_succeeded"
            host_profile_singleflight = $authenticatedCatalogRefresh
        }
        completion_claim_allowed = $false
    } | ConvertTo-Json -Compress
    exit 0
}
$commonPrepareReceipt = $null
$commonPreparedContract = $null
$commonEffectivePromptFile = ""
$commonEffectivePromptSha256 = ""
$commonEffectivePromptBytes = 0
$commonContextEffectStatus = "not_requested"
$commonModelInputEffectVerified = $false
$commonPoolLanePromptFile = ""
$commonPoolLanePromptEffectVerified = $false
$commonRequested = (
    -not [string]::IsNullOrWhiteSpace($CommonLogicalContractPath) -or
    -not [string]::IsNullOrWhiteSpace($CommonWorkKey) -or
    -not [string]::IsNullOrWhiteSpace($CommonOperationId) -or
    -not [string]::IsNullOrWhiteSpace($CommonSubjectManifestSha256) -or
    -not [string]::IsNullOrWhiteSpace($CommonFrozenContextSha256) -or
    -not [string]::IsNullOrWhiteSpace($CommonContextManifestPath) -or
    -not [string]::IsNullOrWhiteSpace($CommonRulesFile) -or
    -not [string]::IsNullOrWhiteSpace($CommonRulesSha256) -or
    -not [string]::IsNullOrWhiteSpace($CommonCandidateOutputRoot) -or
    -not [string]::IsNullOrWhiteSpace($CommonPhase) -or
    -not [string]::IsNullOrWhiteSpace($CommonPriorAttemptReceiptPath)
)
if ($commonRequested) {
    if ($N -ne 1) { throw "CODEX_GROK_COMMON_REQUIRES_SINGLE_LANE" }
    if ([string]::IsNullOrWhiteSpace($CommonRulesFile)) {
        throw "CODEX_GROK_COMMON_REQUIRED: rules_file"
    }
    if ($CommonRulesSha256 -notmatch '^[0-9a-f]{64}$') {
        throw "CODEX_GROK_COMMON_RULES_SHA256_INVALID"
    }
    try { $CommonRulesFile = [IO.Path]::GetFullPath($CommonRulesFile) }
    catch { throw "CODEX_GROK_COMMON_RULES_FILE_INVALID: $CommonRulesFile" }
    if (-not (Test-Path -LiteralPath $CommonRulesFile -PathType Leaf)) {
        throw "CODEX_GROK_COMMON_RULES_FILE_MISSING: $CommonRulesFile"
    }
    $observedRulesSha256 = (Get-FileHash -LiteralPath $CommonRulesFile -Algorithm SHA256).Hash.ToLowerInvariant()
    if (-not [string]::Equals($observedRulesSha256, $CommonRulesSha256, [StringComparison]::Ordinal)) {
        throw "CODEX_GROK_COMMON_RULES_FILE_HASH_MISMATCH"
    }
    if (-not [string]::IsNullOrWhiteSpace($CommonCandidateOutputRoot)) {
        try { $CommonCandidateOutputRoot = [IO.Path]::GetFullPath($CommonCandidateOutputRoot) }
        catch { throw "CODEX_GROK_COMMON_CANDIDATE_OUTPUT_ROOT_INVALID: $CommonCandidateOutputRoot" }
        if (-not (Test-Path -LiteralPath $CommonCandidateOutputRoot -PathType Container)) {
            throw "CODEX_GROK_COMMON_CANDIDATE_OUTPUT_ROOT_MISSING: $CommonCandidateOutputRoot"
        }
        $resolvedCwd = [IO.Path]::GetFullPath($Cwd)
        if (-not [string]::Equals($CommonCandidateOutputRoot, $resolvedCwd, [StringComparison]::OrdinalIgnoreCase)) {
            throw "CODEX_GROK_COMMON_CANDIDATE_OUTPUT_ROOT_CWD_MISMATCH"
        }
        $expectedCandidateWriteDomain = "candidate_output_root:" + ($CommonCandidateOutputRoot.Replace('\', '/').TrimEnd('/').ToLowerInvariant())
        if (
            @($CommonWriteDomains).Count -ne 1 -or
            -not [string]::Equals([string]$CommonWriteDomains[0], $expectedCandidateWriteDomain, [StringComparison]::Ordinal)
        ) {
            throw "CODEX_GROK_COMMON_CANDIDATE_WRITE_DOMAIN_MISMATCH"
        }
    }
    if (
        -not [string]::IsNullOrWhiteSpace($CommonLogicalContractPath) -and
        -not [string]::IsNullOrWhiteSpace($CommonContextManifestPath)
    ) {
        throw "CODEX_GROK_COMMON_CONTEXT_MANIFEST_REQUIRES_PREPARATION"
    }
    if ($null -eq $supervisorCapability) {
        $supervisorCapability = Resolve-GrokSupervisorSelectorRoot `
            -SupervisorRoot $SupervisorRoot `
            -Cwd $Cwd `
            -SelectionResolver $selectionResolver `
            -RuntimeRoot $RuntimeRoot `
            -ReleasePointer $SelectorReleasePointer
    }
    if ([string]::IsNullOrWhiteSpace($CommonPythonExe)) {
        $CommonPythonExe = [string]$supervisorCapability.python_executable
    }
    if ([string]::IsNullOrWhiteSpace($CommonAdapterRoot)) {
        $CommonAdapterRoot = [string]$supervisorCapability.resolved_root
    }
    $CommonAdapterRoot = [IO.Path]::GetFullPath($CommonAdapterRoot)
    if (-not (Test-Path -LiteralPath $CommonAdapterRoot -PathType Container)) {
        throw "CODEX_GROK_COMMON_ADAPTER_ROOT_MISSING: $CommonAdapterRoot"
    }
    if ([string]::IsNullOrWhiteSpace($CommonLogicalContractPath)) {
        foreach ($entry in ([ordered]@{
            work_key = $CommonWorkKey
            operation_id = $CommonOperationId
            subject_manifest_sha256 = $CommonSubjectManifestSha256
            phase = $CommonPhase
            prompt_file = $PromptFile
        }).GetEnumerator()) {
            if ([string]::IsNullOrWhiteSpace([string]$entry.Value)) {
                throw "CODEX_GROK_COMMON_REQUIRED: $($entry.Key)"
            }
        }
        if (
            [string]::IsNullOrWhiteSpace($CommonFrozenContextSha256) -and
            [string]::IsNullOrWhiteSpace($CommonContextManifestPath)
        ) {
            throw "CODEX_GROK_COMMON_REQUIRED: frozen_context_sha256_or_context_manifest_path"
        }
        if (-not [string]::IsNullOrWhiteSpace($CommonContextManifestPath)) {
            try { $CommonContextManifestPath = [IO.Path]::GetFullPath($CommonContextManifestPath) }
            catch { throw "CODEX_GROK_COMMON_CONTEXT_MANIFEST_INVALID: $CommonContextManifestPath" }
            if (-not (Test-Path -LiteralPath $CommonContextManifestPath -PathType Leaf)) {
                throw "CODEX_GROK_COMMON_CONTEXT_MANIFEST_MISSING: $CommonContextManifestPath"
            }
        }
        $prepareScript = Join-Path $CommonAdapterRoot "scripts\prepare_direct_worker_pool_common_contract.py"
        if (-not (Test-Path -LiteralPath $prepareScript -PathType Leaf)) {
            throw "CODEX_GROK_COMMON_PREPARER_MISSING: $prepareScript"
        }
        if (-not (Get-Command $CommonPythonExe -ErrorAction SilentlyContinue)) {
            throw "CODEX_GROK_COMMON_PYTHON_MISSING: $CommonPythonExe"
        }
        $commonContractDir = Join-Path $RuntimeRoot (
            "state\codex_dispatch_grok_worker_pool\common_contracts\" + $dispatchId
        )
        New-Item -ItemType Directory -Force -Path $commonContractDir | Out-Null
        $CommonLogicalContractPath = Join-Path $commonContractDir "logical_contract.json"
        $originalPromptFile = [IO.Path]::GetFullPath($PromptFile)
        $originalPromptSha256 = (
            Get-FileHash -LiteralPath $originalPromptFile -Algorithm SHA256
        ).Hash.ToLowerInvariant()
        $expectedEffectivePromptFile = Join-Path $commonContractDir "effective_prompt.md"
        $prepareArgs = @(
            $prepareScript,
            "--prompt-file", $originalPromptFile,
            "--selection-receipt", $SelectionPath,
            "--subject-manifest-sha256", $CommonSubjectManifestSha256,
            "--work-key", $CommonWorkKey,
            "--operation-id", $CommonOperationId,
            "--rules-file", $CommonRulesFile,
            "--min-result-chars", ([string]$MinResultChars),
            "--deadline-seconds", ([string]$TimeoutSec),
            "--output", $CommonLogicalContractPath
        )
        if (-not [string]::IsNullOrWhiteSpace($CommonTaskContractRef)) {
            $prepareArgs += @("--task-contract-ref", $CommonTaskContractRef)
        }
        if (-not [string]::IsNullOrWhiteSpace($CommonParentOperationId)) {
            $prepareArgs += @("--parent-operation-id", $CommonParentOperationId)
        }
        if (-not [string]::IsNullOrWhiteSpace($CommonCorrelationId)) {
            $prepareArgs += @("--correlation-id", $CommonCorrelationId)
        }
        if (-not [string]::IsNullOrWhiteSpace($CommonFrozenContextSha256)) {
            $prepareArgs += @("--frozen-context-sha256", $CommonFrozenContextSha256)
        }
        if (-not [string]::IsNullOrWhiteSpace($CommonContextManifestPath)) {
            $prepareArgs += @(
                "--context-manifest-file", $CommonContextManifestPath,
                "--effective-prompt-output", $expectedEffectivePromptFile
            )
        }
        foreach ($marker in @($RequiredResultMarkers)) {
            $prepareArgs += @("--required-result-marker", [string]$marker)
        }
        if ($RequireJsonObject) { $prepareArgs += "--require-json-object" }
        if ($JsonSchemaPath) {
            $prepareArgs += @("--json-schema-file", ([IO.Path]::GetFullPath($JsonSchemaPath)))
        }
        if (@($CommonWriteDomains).Count -gt 0) { $prepareArgs += "--write" }
        $prepareOutput = @(& $CommonPythonExe @prepareArgs 2>&1)
        $prepareExit = if ($null -eq $LASTEXITCODE) { 0 } else { [int]$LASTEXITCODE }
        if ($prepareExit -ne 0 -or -not (Test-Path -LiteralPath $CommonLogicalContractPath -PathType Leaf)) {
            throw (
                "CODEX_GROK_COMMON_PREPARE_FAILED: exit=$prepareExit output=" +
                (($prepareOutput | ForEach-Object { "$_" }) -join [Environment]::NewLine)
            )
        }
        $prepareReceiptPath = Join-Path $commonContractDir "contract_prepare_receipt.json"
        if (-not (Test-Path -LiteralPath $prepareReceiptPath -PathType Leaf)) {
            throw "CODEX_GROK_COMMON_PREPARE_RECEIPT_MISSING: $prepareReceiptPath"
        }
        try {
            $commonPrepareReceipt = Get-Content -LiteralPath $prepareReceiptPath -Raw -Encoding UTF8 |
                ConvertFrom-Json -ErrorAction Stop
        }
        catch {
            throw "CODEX_GROK_COMMON_PREPARE_RECEIPT_INVALID: $prepareReceiptPath"
        }
        $preparedContextSha256 = [string]$commonPrepareReceipt.frozen_context_sha256
        if ($preparedContextSha256 -notmatch '^[0-9a-f]{64}$') {
            throw "CODEX_GROK_COMMON_PREPARE_CONTEXT_INVALID"
        }
        if (-not [string]::IsNullOrWhiteSpace($CommonContextManifestPath)) {
            if ([string]$commonPrepareReceipt.context_binding_mode -ne "validated_context_slice_manifest") {
                throw "CODEX_GROK_COMMON_CONTEXT_MANIFEST_NOT_BOUND"
            }
            try {
                $commonEffectivePromptFile = [IO.Path]::GetFullPath(
                    [string]$commonPrepareReceipt.effective_prompt_file
                )
            }
            catch {
                throw "CODEX_GROK_COMMON_EFFECTIVE_PROMPT_PATH_INVALID"
            }
            if (-not [string]::Equals(
                $commonEffectivePromptFile,
                [IO.Path]::GetFullPath($expectedEffectivePromptFile),
                [StringComparison]::OrdinalIgnoreCase
            )) {
                throw "CODEX_GROK_COMMON_EFFECTIVE_PROMPT_PATH_MISMATCH"
            }
            if (-not (Test-Path -LiteralPath $commonEffectivePromptFile -PathType Leaf)) {
                throw "CODEX_GROK_COMMON_EFFECTIVE_PROMPT_MISSING: $commonEffectivePromptFile"
            }
            if (-not [string]::Equals(
                [string]$commonPrepareReceipt.original_prompt_sha256,
                $originalPromptSha256,
                [StringComparison]::Ordinal
            )) {
                throw "CODEX_GROK_COMMON_ORIGINAL_PROMPT_HASH_MISMATCH"
            }
            $commonEffectivePromptSha256 = (
                Get-FileHash -LiteralPath $commonEffectivePromptFile -Algorithm SHA256
            ).Hash.ToLowerInvariant()
            $commonEffectivePromptBytes = [int64](
                Get-Item -LiteralPath $commonEffectivePromptFile
            ).Length
            if (
                -not [string]::Equals(
                    [string]$commonPrepareReceipt.effective_prompt_sha256,
                    $commonEffectivePromptSha256,
                    [StringComparison]::Ordinal
                ) -or
                [int64]$commonPrepareReceipt.effective_prompt_bytes -ne $commonEffectivePromptBytes
            ) {
                throw "CODEX_GROK_COMMON_EFFECTIVE_PROMPT_RECEIPT_MISMATCH"
            }
            try {
                $commonPreparedContract = Get-Content -LiteralPath $CommonLogicalContractPath -Raw -Encoding UTF8 |
                    ConvertFrom-Json -ErrorAction Stop
            }
            catch {
                throw "CODEX_GROK_COMMON_PREPARED_CONTRACT_INVALID: $CommonLogicalContractPath"
            }
            if (-not [string]::Equals(
                [string]$commonPreparedContract.input_sha256,
                $commonEffectivePromptSha256,
                [StringComparison]::Ordinal
            )) {
                throw "CODEX_GROK_COMMON_EFFECTIVE_PROMPT_CONTRACT_HASH_MISMATCH"
            }
            $PromptFile = $commonEffectivePromptFile
            $commonContextEffectStatus = "verified_effective_prompt_bound_for_worker_pool"
        }
        if (
            -not [string]::Equals([string]$commonPrepareReceipt.rules_sha256, $CommonRulesSha256, [StringComparison]::Ordinal) -or
            -not [string]::Equals(
                [IO.Path]::GetFullPath([string]$commonPrepareReceipt.rules_file),
                $CommonRulesFile,
                [StringComparison]::OrdinalIgnoreCase
            )
        ) {
            throw "CODEX_GROK_COMMON_RULES_NOT_BOUND"
        }
        $CommonFrozenContextSha256 = $preparedContextSha256
    }
}
$sealedInputLease = $null
if (-not [string]::IsNullOrWhiteSpace($CommonSealedInputRoot)) {
    try { $CommonSealedInputRoot = [IO.Path]::GetFullPath($CommonSealedInputRoot) }
    catch { throw "CODEX_GROK_COMMON_SEALED_INPUT_ROOT_INVALID: $CommonSealedInputRoot" }
    if (-not (Test-Path -LiteralPath $CommonSealedInputRoot -PathType Container)) {
        throw "CODEX_GROK_COMMON_SEALED_INPUT_ROOT_MISSING: $CommonSealedInputRoot"
    }
    if ($CommonSealedInputRoot -match '[,\r\n]') {
        throw "CODEX_GROK_COMMON_SEALED_INPUT_ROOT_UNSAFE"
    }
    $sealedInputLease = Open-GrokDirectoryIdentityLease -Path $CommonSealedInputRoot
}
$dispatchCwdLease = Open-GrokDirectoryIdentityLease -Path $Cwd
try {
if (
    -not [string]::IsNullOrWhiteSpace($ExpectedSelectionDecisionSha256) -and
    -not [string]::Equals(
        $ExpectedSelectionDecisionSha256,
        [string]$selection.decision_sha256,
        [StringComparison]::Ordinal
    )
) {
    throw "CODEX_GROK_SELECTION_DECISION_CHANGED"
}

$metaDir = "D:\XINAO_RESEARCH_RUNTIME\state\codex_dispatch_grok_worker_pool"
New-Item -ItemType Directory -Force -Path $metaDir | Out-Null
$dispatchMetaPath = Join-Path $metaDir ($dispatchId + ".json")
$poolSummaryPath = Join-Path "D:\XINAO_RESEARCH_RUNTIME\state\grok_worker_pool" (
    $poolId + "\pool_summary.json"
)
if (Test-Path -LiteralPath $dispatchMetaPath) {
    throw "CODEX_GROK_DISPATCH_ID_ALREADY_EXISTS: $dispatchId"
}

$dispatchMeta = [ordered]@{
    schema_version = "xinao.codex_dispatch_grok_worker_pool.v1"
    sentinel = "SENTINEL:CODEX_DISPATCH_GROK_WORKER_POOL"
    generated_at = (Get-Date).ToString("o")
    dispatch_id = $dispatchId
    pool_id = $poolId
    pool_summary_path = $poolSummaryPath
    role_cn = "dynamic positive-benefit bounded Grok headless worker pool"
    route_role = "normal_leg_a_bounded_online_current_tui"
    route_selection = "selected_by_task_fit_or_existing_route_receipt"
    route_continuity = "continuous_or_resume_does_not_switch_leg"
    is_unconditional_default = $false
    leg_b_cn = "explicit durable handoff -> Temporal + Docker houtai-gongren + worker-internal LangGraph"
    prohibited_cn = @(
        "codex_to_grok visible typeahead inject",
        "Docker integrated_bus Desktop .lnk"
    )
    n = $N
    model = $Model
    selection_path = $SelectionPath
    selection_decision_sha256 = [string]$selection.decision_sha256
    selected_provider_id = [string]$selection.provider_id
    selected_profile_ref = [string]$selection.profile_ref
    selected_transport_id = [string]$selection.transport_id
    supervisor_root = [string]$supervisorCapability.resolved_root
    selector_source = [string]$supervisorCapability.selector_source
    selector_source_sha256 = [string]$supervisorCapability.selector_source_sha256
    selector_imported_module_source = [string]$supervisorCapability.imported_module_source
    selector_root_selected_from = [string]$supervisorCapability.selected_from
    selector_root_fallback_used = $supervisorCapability.fallback_used -eq $true
    selector_task_cwd_used = $supervisorCapability.task_cwd_used_for_selector -eq $true
    selector_release_binding = $supervisorCapability.release_binding
    dispatch_epoch_id = $DispatchEpochId
    dispatch_epoch_source = $DispatchEpochSource
    dispatch_epoch_max_age_sec = $DispatchEpochMaxAgeSec
    quota_snapshot_id = $QuotaSnapshotId
    quota_snapshot_ref = $QuotaSnapshotRef
    quota_snapshot_sha256 = $QuotaSnapshotSha256
    quota_resolution_status = $QuotaResolutionStatus
    quota_resolution_error = $QuotaResolutionError
    selector_probe_reports = @($supervisorCapability.candidate_reports)
    json_schema_path = $JsonSchemaPath
    common_contract_path = $CommonLogicalContractPath
    common_context_manifest_path = $CommonContextManifestPath
    common_rules_file = $CommonRulesFile
    common_rules_sha256 = $CommonRulesSha256
    common_sealed_input_root = $CommonSealedInputRoot
    common_sealed_input_read_only_required = -not [string]::IsNullOrWhiteSpace($CommonSealedInputRoot)
    common_candidate_output_root = $CommonCandidateOutputRoot
    common_context_binding_mode = if ($null -ne $commonPrepareReceipt) {
        [string]$commonPrepareReceipt.context_binding_mode
    } else { "" }
    common_context_manifest_sha256 = if ($null -ne $commonPrepareReceipt) {
        [string]$commonPrepareReceipt.context_manifest_sha256
    } else { "" }
    common_effective_prompt_file = $commonEffectivePromptFile
    common_effective_prompt_sha256 = $commonEffectivePromptSha256
    common_effective_prompt_bytes = $commonEffectivePromptBytes
    common_context_effect_status = $commonContextEffectStatus
    common_model_input_effect_verified = $commonModelInputEffectVerified
    common_pool_lane_prompt_file = $commonPoolLanePromptFile
    common_pool_lane_prompt_effect_verified = $commonPoolLanePromptEffectVerified
    common_phase = $CommonPhase
    common_adapter_root = $CommonAdapterRoot
    docker_exception_opt_in = [bool]$AllowExceptionalDocker
    docker_exception_justification = if ($AllowExceptionalDocker) { $DockerJustification.Trim() } else { "" }
    cwd = $Cwd
    cwd_final_path = [string]$dispatchCwdLease.final_path
    cwd_object_id = [string]$dispatchCwdLease.object_id
    pool_script = $pool
    latest_projection_mode = "best_effort_terminal_only"
    pre_pool_latest_published = $false
    completion_claim_allowed = $false
}
Write-GrokJsonAtomic -Path $dispatchMetaPath -Value $dispatchMeta -CreateNew

$args = @{
    N = $N
    Model = $Model
    SelectionPath = $SelectionPath
    ExpectedSelectionDecisionSha256 = [string]$selection.decision_sha256
    MaxTurns = $MaxTurns
    TimeoutSec = $TimeoutSec
    GrokHome = $GrokHome
    MinResultChars = $MinResultChars
    RequiredResultMarkers = @($RequiredResultMarkers)
    PoolId = $poolId
}
if ($RequireJsonObject) { $args.RequireJsonObject = $true }
if ($JsonSchemaPath) { $args.JsonSchemaPath = $JsonSchemaPath }
if ($CommonLogicalContractPath) {
    $args.CommonLogicalContractPath = $CommonLogicalContractPath
    $args.CommonSubjectManifestSha256 = $CommonSubjectManifestSha256
    $args.CommonFrozenContextSha256 = $CommonFrozenContextSha256
    $args.CommonRulesFile = $CommonRulesFile
    $args.CommonRulesSha256 = $CommonRulesSha256
    $args.CommonSealedInputRoot = $CommonSealedInputRoot
    $args.CommonCandidateOutputRoot = $CommonCandidateOutputRoot
    $args.CommonPhase = $CommonPhase
    $args.CommonWriteDomains = @($CommonWriteDomains)
    $args.CommonDependsOn = @($CommonDependsOn)
    $args.CommonAdapterRoot = $CommonAdapterRoot
    $args.CommonPythonExe = $CommonPythonExe
}
if ($AllowExceptionalDocker) {
    $args.AllowExceptionalDocker = $true
    $args.DockerJustification = $DockerJustification
}
elseif (-not [string]::IsNullOrWhiteSpace($DockerJustification)) {
    throw "CODEX_GROK_DOCKER_JUSTIFICATION_WITHOUT_OPT_IN"
}
if ($CommonPriorAttemptReceiptPath) {
    $args.CommonPriorAttemptReceiptPath = $CommonPriorAttemptReceiptPath
}
if ($Prompt) { $args.Prompt = $Prompt }
if ($PromptFile) { $args.PromptFile = $PromptFile }
$args.Cwd = $Cwd
if ($SkipPauseGate) { $args.SkipPauseGate = $true }
if ($Quiet) { $args.Quiet = $true }

if (-not [string]::IsNullOrWhiteSpace($CommonContextManifestPath)) {
    $preInvokeEffectivePromptSha256 = (
        Get-FileHash -LiteralPath $commonEffectivePromptFile -Algorithm SHA256
    ).Hash.ToLowerInvariant()
    if (-not [string]::Equals(
        $preInvokeEffectivePromptSha256,
        $commonEffectivePromptSha256,
        [StringComparison]::Ordinal
    )) {
        throw "CODEX_GROK_COMMON_EFFECTIVE_PROMPT_CHANGED_BEFORE_POOL"
    }
}

& $pool @args
$code = $LASTEXITCODE
if (-not [string]::IsNullOrWhiteSpace($CommonContextManifestPath)) {
    $dispatchMeta.common_context_effect_status = (
        "worker_pool_invoked_with_verified_effective_prompt_file"
    )
}

$dispatchMeta.finished_at = (Get-Date).ToString("o")
$dispatchMeta.pool_exit_code = $code
$dispatchMeta.pool_summary_path = $poolSummaryPath
$dispatchMeta.pool_summary_exists = Test-Path -LiteralPath $poolSummaryPath -PathType Leaf
if ($dispatchMeta.pool_summary_exists) {
    try {
        $poolSummary = Get-Content -LiteralPath $poolSummaryPath -Raw -Encoding UTF8 |
            ConvertFrom-Json -ErrorAction Stop
        if ([string]$poolSummary.pool_id -ne $poolId) {
            throw "CODEX_GROK_POOL_SUMMARY_ID_MISMATCH"
        }
        $poolCwdLease = Open-GrokDirectoryIdentityLease -Path ([string]$poolSummary.cwd)
        try {
        if (
            -not [string]::Equals(
                [string]$poolSummary.selection_decision_sha256,
                [string]$selection.decision_sha256,
                [StringComparison]::Ordinal
            ) -or
            -not [string]::Equals([string]$poolSummary.model, $Model, [StringComparison]::Ordinal) -or
            -not (Test-GrokDirectoryObjectIdentityEqual -Left $poolCwdLease -Right $dispatchCwdLease) -or
            -not [string]::Equals(
                [string]$poolSummary.selected_provider_id,
                [string]$selection.provider_id,
                [StringComparison]::Ordinal
            ) -or
            -not [string]::Equals(
                [string]$poolSummary.selected_profile_ref,
                [string]$selection.profile_ref,
                [StringComparison]::Ordinal
            ) -or
            -not [string]::Equals(
                [string]$poolSummary.selected_transport_id,
                [string]$selection.transport_id,
                [StringComparison]::Ordinal
            ) -or
            -not [string]::Equals(
                [string]$poolSummary.common_sealed_input_root,
                $CommonSealedInputRoot,
                [StringComparison]::OrdinalIgnoreCase
            ) -or
            (
                -not [string]::IsNullOrWhiteSpace($CommonSealedInputRoot) -and
                $poolSummary.common_sealed_input_read_only -ne $true
            )
        ) {
            throw "CODEX_GROK_POOL_SELECTION_RECEIPT_MISMATCH"
        }
        [void](Assert-GrokDirectoryIdentityLeaseStable -Lease $poolCwdLease)
        [void](Assert-GrokDirectoryIdentityLeaseStable -Lease $dispatchCwdLease)
        if ($null -ne $sealedInputLease) {
            [void](Assert-GrokDirectoryIdentityLeaseStable -Lease $sealedInputLease)
        }
        }
        finally {
            Close-GrokDirectoryIdentityLease -Lease $poolCwdLease
        }
        $dispatchMeta.pool_summary_sha256 = (
            Get-FileHash -LiteralPath $poolSummaryPath -Algorithm SHA256
        ).Hash.ToLowerInvariant()
        $dispatchMeta.pool_all_ok = $poolSummary.all_ok -eq $true
        $dispatchMeta.pool_reuse_skipped_execution =
            $poolSummary.reuse_skipped_execution -eq $true
        $dispatchMeta.pool_effective_ok = (
            $dispatchMeta.pool_all_ok -eq $true -or
            $dispatchMeta.pool_reuse_skipped_execution -eq $true
        )
        $dispatchMeta.pool_acceptance_contract_ok = $poolSummary.acceptance_contract_ok -eq $true
        if (-not [string]::IsNullOrWhiteSpace($CommonContextManifestPath)) {
            if ($dispatchMeta.pool_reuse_skipped_execution -eq $true) {
                $dispatchMeta.common_context_effect_status = (
                    "worker_pool_reused_prior_result_no_new_model_input"
                )
            }
            elseif (@($poolSummary.results).Count -gt 0) {
                $commonPoolLanePromptFile = Join-Path (
                    [string]$poolSummary.results[0].evidence_dir
                ) "prompt.md"
                if (-not (Test-Path -LiteralPath $commonPoolLanePromptFile -PathType Leaf)) {
                    throw "CODEX_GROK_COMMON_POOL_LANE_PROMPT_MISSING: $commonPoolLanePromptFile"
                }
                $effectivePromptAfterPoolSha256 = (
                    Get-FileHash -LiteralPath $commonEffectivePromptFile -Algorithm SHA256
                ).Hash.ToLowerInvariant()
                if (-not [string]::Equals(
                    $effectivePromptAfterPoolSha256,
                    $commonEffectivePromptSha256,
                    [StringComparison]::Ordinal
                )) {
                    throw "CODEX_GROK_COMMON_EFFECTIVE_PROMPT_CHANGED_DURING_POOL"
                }
                $effectivePromptBytes = [IO.File]::ReadAllBytes($commonEffectivePromptFile)
                $lanePromptBytes = [IO.File]::ReadAllBytes($commonPoolLanePromptFile)
                $commonPoolLanePromptEffectVerified = (
                    $lanePromptBytes.Length -ge $effectivePromptBytes.Length
                )
                if ($commonPoolLanePromptEffectVerified) {
                    $suffixOffset = $lanePromptBytes.Length - $effectivePromptBytes.Length
                    for ($i = 0; $i -lt $effectivePromptBytes.Length; $i++) {
                        if ($lanePromptBytes[$suffixOffset + $i] -ne $effectivePromptBytes[$i]) {
                            $commonPoolLanePromptEffectVerified = $false
                            break
                        }
                    }
                }
                if (-not $commonPoolLanePromptEffectVerified) {
                    throw "CODEX_GROK_COMMON_POOL_LANE_PROMPT_EFFECT_MISMATCH"
                }
                $commonModelInputEffectVerified = (
                    [int64]$poolSummary.usage.attempt_count -gt 0 -and
                    [int64]$poolSummary.usage.input_tokens -gt 0
                )
                $dispatchMeta.common_pool_lane_prompt_file = $commonPoolLanePromptFile
                $dispatchMeta.common_pool_lane_prompt_effect_verified = $true
                $dispatchMeta.common_model_input_effect_verified = $commonModelInputEffectVerified
                $dispatchMeta.common_context_effect_status = if (
                    $commonModelInputEffectVerified
                ) {
                    "model_attempt_consumed_lane_prompt_with_verified_effective_suffix"
                }
                else {
                    "worker_lane_prompt_materialized_but_model_input_unverified"
                }
            }
            if (
                $dispatchMeta.pool_reuse_skipped_execution -ne $true -and
                -not $commonModelInputEffectVerified
            ) {
                throw "CODEX_GROK_COMMON_MODEL_INPUT_EFFECT_UNVERIFIED"
            }
        }
    }
    catch {
        if ($code -eq 0) { $code = 4 }
        $dispatchMeta.pool_exit_code = $code
        $dispatchMeta.pool_summary_error = [string]$_.Exception.Message
    }
}
elseif ($code -eq 0) {
    $code = 4
    $dispatchMeta.pool_exit_code = $code
    $dispatchMeta.pool_summary_error = "CODEX_GROK_POOL_SUMMARY_MISSING"
}
$dispatchMeta.status = if (
    $code -eq 0 -and
    $dispatchMeta.pool_effective_ok -eq $true -and
    $dispatchMeta.pool_acceptance_contract_ok -eq $true
) { "accepted" } else { "rejected" }
Write-GrokJsonAtomic -Path $dispatchMetaPath -Value $dispatchMeta
$latestProjection = Publish-GrokAdvisoryLatest `
    -SourcePath $dispatchMetaPath `
    -DestinationPath (Join-Path $metaDir "latest.json")
if (-not $latestProjection.published -and -not $Quiet) {
    Write-Warning ("CODEX_GROK_LATEST_PROJECTION_SKIPPED: " + [string]$latestProjection.error)
}

}
finally {
    Close-GrokDirectoryIdentityLease -Lease $dispatchCwdLease
    if ($null -ne $sealedInputLease) {
        Close-GrokDirectoryIdentityLease -Lease $sealedInputLease
    }
}

exit $code
