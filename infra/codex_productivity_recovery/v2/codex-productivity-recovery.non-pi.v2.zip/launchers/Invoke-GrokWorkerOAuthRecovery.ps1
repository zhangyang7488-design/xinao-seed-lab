#Requires -Version 7.0
<#[
.SYNOPSIS
  Diagnose and, only after dual terminal proof, recover the dedicated Grok
  WorkerPool OAuth profile.
.DESCRIPTION
  SelectionOnly success is a hard OAuth veto. A browser login is admitted only
  when the same generic WorkerPool transport profile still reports the exact
  auth-required state
  and either auth.json is absent/empty or refresh-token terminal evidence is
  present. -StartOAuth performs a second SelectionOnly probe immediately before
  login so a concurrent successful refresh cancels the browser flow.
#>
[CmdletBinding()]
param(
    [string]$Cwd = "E:\XINAO_RESEARCH_WORKSPACES\S",
    [string]$Model = "grok-4.6",
    [string]$GrokHome = "C:\Users\xx363\.grok-bg-workers",
    [switch]$StartOAuth
)

$ErrorActionPreference = "Stop"
$expectedHome = [IO.Path]::GetFullPath("C:\Users\xx363\.grok-bg-workers").TrimEnd('\')
$resolvedHome = [IO.Path]::GetFullPath($GrokHome).TrimEnd('\')
if (-not [string]::Equals($resolvedHome, $expectedHome, [StringComparison]::OrdinalIgnoreCase)) {
    throw "GROK_WORKER_OAUTH_PROFILE_MISMATCH: expected=$expectedHome observed=$resolvedHome"
}

$selectionLauncher = "C:\Users\xx363\CodexLaunchers\Invoke-Codex-GrokWorkerPool.ps1"
$grokExe = "C:\Users\xx363\.grok\bin\grok.exe"
if (-not (Test-Path -LiteralPath $selectionLauncher -PathType Leaf)) {
    throw "GROK_WORKER_SELECTION_LAUNCHER_MISSING: $selectionLauncher"
}
if (-not (Test-Path -LiteralPath $resolvedHome -PathType Container)) {
    throw "GROK_WORKER_PROFILE_MISSING: $resolvedHome"
}

function Test-WorkerTransportAuthPresent {
    $authPath = Join-Path $resolvedHome "auth.json"
    return (
        (Test-Path -LiteralPath $authPath -PathType Leaf) -and
        (Get-Item -LiteralPath $authPath -Force -ErrorAction Stop).Length -gt 0
    )
}

function Invoke-SelectionProbe {
    $pwsh = Join-Path $PSHOME "pwsh.exe"
    $start = [Diagnostics.ProcessStartInfo]::new()
    $start.FileName = $pwsh
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    foreach ($argument in @(
        "-NoLogo", "-NoProfile", "-NonInteractive", "-File", $selectionLauncher,
        "-SelectionOnly", "-N", "1", "-Model", $Model, "-Cwd", $Cwd,
        "-GrokHome", $resolvedHome
    )) {
        $null = $start.ArgumentList.Add($argument)
    }
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $start
    try {
        if (-not $process.Start()) {
            throw "GROK_WORKER_SELECTION_PROBE_START_FAILED"
        }
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $stderrTask = $process.StandardError.ReadToEndAsync()
        $process.WaitForExit()
        return [pscustomobject][ordered]@{
            exit_code = $process.ExitCode
            stdout = $stdoutTask.GetAwaiter().GetResult()
            stderr = $stderrTask.GetAwaiter().GetResult()
        }
    }
    finally {
        $process.Dispose()
    }
}

function Get-OAuthAdmission([object]$Probe) {
    $diagnostic = ([string]$Probe.stdout) + "`n" + ([string]$Probe.stderr)
    $selectionSucceeded = [int]$Probe.exit_code -eq 0
    $exactAuthRequired = $diagnostic -match '(?m)GROK_AUTHENTICATED_PROFILE_AUTH_REQUIRED'
    $refreshTokenTerminal = $diagnostic -match '(?m)refresh_token_terminal'
    $authPresent = Test-WorkerTransportAuthPresent
    $oauthAllowed = (
        -not $selectionSucceeded -and
        $exactAuthRequired -and
        (-not $authPresent -or $refreshTokenTerminal)
    )
    $reason = if ($selectionSucceeded) {
        "selection_only_succeeded_oauth_forbidden"
    }
    elseif (-not $exactAuthRequired) {
        "selection_failed_without_exact_auth_required"
    }
    elseif ($authPresent -and -not $refreshTokenTerminal) {
        "single_signal_only_auth_present_without_terminal_refresh_evidence"
    }
    else {
        "dual_terminal_auth_evidence"
    }
    [pscustomobject][ordered]@{
        schema_version = "xinao.grok.oauth_recovery_admission.v1"
        profile_ref = $resolvedHome
        profile_identity = "generic_workerpool_transport"
        profile_role_authority = $false
        selection_exit_code = [int]$Probe.exit_code
        selection_succeeded = $selectionSucceeded
        exact_auth_required = $exactAuthRequired
        worker_transport_auth_present = $authPresent
        refresh_token_terminal = $refreshTokenTerminal
        oauth_allowed = $oauthAllowed
        oauth_started = $false
        reason = $reason
    }
}

$probe = Invoke-SelectionProbe
$admission = Get-OAuthAdmission -Probe $probe
if (-not $StartOAuth) {
    $admission | ConvertTo-Json -Compress
    exit 0
}
if (-not $admission.oauth_allowed) {
    $admission | ConvertTo-Json -Compress
    throw "GROK_WORKER_OAUTH_FORBIDDEN: $($admission.reason)"
}

# Recheck immediately before the only command that can open a browser. A
# concurrent silent refresh therefore revokes the previously admitted login.
$finalProbe = Invoke-SelectionProbe
$finalAdmission = Get-OAuthAdmission -Probe $finalProbe
if (-not $finalAdmission.oauth_allowed) {
    $finalAdmission | ConvertTo-Json -Compress
    throw "GROK_WORKER_OAUTH_FORBIDDEN_AFTER_RECHECK: $($finalAdmission.reason)"
}
if (-not (Test-Path -LiteralPath $grokExe -PathType Leaf)) {
    throw "GROK_WORKER_CLI_MISSING: $grokExe"
}

$priorGrokHome = $env:GROK_HOME
try {
    $env:GROK_HOME = $resolvedHome
    & $grokExe login --oauth
    if ($LASTEXITCODE -ne 0) {
        throw "GROK_WORKER_OAUTH_COMMAND_FAILED: exit=$LASTEXITCODE"
    }
}
finally {
    if ($null -eq $priorGrokHome) {
        Remove-Item Env:\GROK_HOME -ErrorAction SilentlyContinue
    }
    else {
        $env:GROK_HOME = $priorGrokHome
    }
}

$postProbe = Invoke-SelectionProbe
$postAdmission = Get-OAuthAdmission -Probe $postProbe
if (-not $postAdmission.selection_succeeded) {
    throw "GROK_WORKER_OAUTH_RECOVERY_READBACK_FAILED"
}
$postAdmission.oauth_started = $true
$postAdmission.reason = "oauth_recovered_and_selection_verified"
$postAdmission | ConvertTo-Json -Compress
