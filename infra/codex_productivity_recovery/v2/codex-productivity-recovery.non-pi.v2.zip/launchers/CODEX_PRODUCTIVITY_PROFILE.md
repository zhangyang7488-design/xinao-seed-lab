# Codex 本机生产力配置边界

状态：`current / reversible / one-shared-runtime / two-credential-slots / on-demand-overlay-verified`

用户仍只使用 A 与 B 两个认证入口，但它们只选择不同 ChatGPT credential，不代表两套 Codex。`config.toml`、`AGENTS.md`、Hooks、profiles、Skills、Rules、Plugins、S 工作树、共享 runtime 与行为回归均只有一个 live 语义源；B 以 NTFS link 直接消费同一对象，不再复制、同步、保留第二份 hook state 或充当反向恢复源。只有 `auth.json`、token refresh、sessions 与 Codex 强制依附 `CODEX_HOME` 的活动账户状态保持隔离。完整边界见 `E:\XINAO_RESEARCH_WORKSPACES\S\docs\tool_glue\CODEX_SHARED_RUNTIME_ACCOUNT_SLOTS_CURRENT.md`。

## 默认常开

- 当前人话与跨窗减负：`AGENTS.md`、受信任的 `UserPromptSubmit` 第一拍，以及 Memories 注入与生成。它们提供当前语义入口和可纠正的恢复证据，不替线程分配父活动或完成身份。
- 完整基础能力与角色分离的劳动器官：shell、unified exec、apply_patch，以及公共外部 Grok WorkerPool。当前人话与角色先绑定对象；随后在 S 自己的工程、实验控制、证据、恢复和 effect 锥内，普通 Grok 是可分离正收益劳动的默认入口、宽度动态。这个默认不进入 world-owning Sol 的 cognition，也不让 worker/supervisor 从能力存在反向生成任务。Codex 自身 `multi_agent` 持久默认关闭；其 agent 定义保留。命中下述不可替代原生价值时，当前 effect Owner 可在既有边界内用一次性覆盖启用并复验回冷，不需要用户逐次批准。
- 高频通用能力：web search、Browser/Chrome/Computer Use 插件、`node_repl`、图片工具。
- 高风险操作的成熟能力：Safe Cleanup 插件及其 MCP。
- 质量不降级：主模型和 reasoning 等级不因“减负”而下调。

## 默认冷置但保留完整定义

- `windows`：与现有 Computer Use/Chrome 能力重叠，常驻成本高。
- `chrome-devtools`：与 Browser/Chrome 插件重叠。
- `codebase-memory`、`serena`：日常代码定位已有 `rg`/AST/内置工具，且常驻进程重。
- `xinao-memory`、`xinao-coordination`：旧平台能力不能取得当前父任务；当前薄入口和 live 文件已承接连续性/研究事实。
- `opencode_workers`：这是冷置的插件/MCP 集成，不是公共 `Invoke-Codex-GrokWorkerPool.ps1`。公共普通 Grok 劳动入口保持可用，并在 S 职责锥内按上述关系取得默认可分离劳动力地位；无需为此热启该插件。
- `openaiDeveloperDocs` MCP：OpenAI Docs Skill 先用本地官方 manual helper，必要时再查官方网页。
- GitHub、OpenAI key-confirmation、Sites design-picker 的插件 MCP：插件/Skill 仍在，默认不启动其低频 MCP。
- 文档、PDF、表格、演示、模板、Sites、可视化与 LaTeX 插件：安装和定义完整保留，普通启动不注入其低频 Skill；需要时由 Owner 使用同账户覆盖恢复。
- Apps/connectors：当前令牌已失效且启动报 401，默认关闭；不影响 web、browser、shell 或本地插件。
- Goals：Codex 0.147.0 已把该 feature 标为 `stable`，S/B 当前共享配置保持 `goals=true`；这只表示官方能力可用，不产生 Goal 合同、父任务、continuous mode、研究议程或第二 Owner。只有当前人话与 live parent 已经绑定的消费者才能使用它。
- Codex 原生 `multi_agent`：与外部 Grok WorkerPool 不是同一能力面，也会消耗 Codex 自身额度，因此保持冷置；这不取消普通 Grok 在 S 职责锥内的默认可分离劳动力地位，也不强迫简单/无正收益工作 fan-out。若被测对象本身就是 Codex 原生协作面，或 inherited Codex context/native capability 产生外部路线不可替代、足以实质改变关键路径的价值，当前 effect Owner 可在既有任务/effect 边界内使用 `codex -p native-collaboration ...` 一次性启用；这是已授予的任务适配权，不是逐次用户审批点。覆盖只创建同一 root 下可寻址的 subagent tree，不把任意独立顶层 TUI 加入该树。用后退出即回到持久默认 `false`；普通探索、一般第二意见、并行方便、烧额度和主动 multi-agent 提示均不成立。

`enabled = false` 是冷置，不是删除；command、args、URL、env、插件安装与恢复覆盖均原地保留。Hook 与 Memories 没有因“可能昂贵”被猜测性关闭：Hook 无模型调用；一次 B-profile fresh 对照观察到关闭自动 Memory 后首拍未缓存 input 约少 3,586 tokens，但自动 Memory 的真实消费者是跨窗口恢复用户偏好、历史决策和纠偏、减少重复说明。用户已明确该减负能力必须保留，因此 A/B 继续 `memories/use/generate=true`。局部子任务之后是否以及如何继续，先由当前线程仍存活的父活动、当前整句话与 live facts 决定；Hook、Memory、ActiveTaskContinuation 等载体只能提供可纠正的来源证据或局部事实，不能自行生成、恢复或完成父任务，也不能把续接事故归因给 Memory。

## 需要时怎样恢复

Codex 先确认当前任务确实需要该能力且现有常开能力不能完成，再由 Codex 自己处理：

1. 优先用当前进程已有的等价能力，不改变配置。
2. 稀有插件能力统一保存在 canonical runtime 的 `cold-capabilities.config.toml`；A/B profile 路径指向同一文件。当前 effect Owner 在任务命中时自行使用 `codex -p cold-capabilities ...` 进入任务作用域执行面；覆盖只对该进程生效，退出即回到默认冷态。
3. 原生协作覆盖保存在 `native-collaboration.config.toml`，只在任务需要 Codex 树内直连通信时使用。root 先分配互斥写域和 canonical task name；兄弟间用 `send_message` 报接口/底座/live 变化，空闲续轮用 `followup_task`，只在真实汇流依赖时 `wait_agent`。独立顶层 TUI 不在 `list_agents` 结果中就按不可寻址 writer 处理，不建立文件 mailbox 冒充原生通信。
4. A 与 B 各使用自己的 credential-carrier `CODEX_HOME`，但共享配置、L0、Hooks 和能力 profiles 是同一文件/目录对象；只有认证、sessions 和活动账户状态隔离。B 启动器只选择 credential slot 并验证链接，不生成或同步第二套配置。
5. 只有真实消费者必须在交互主线程使用且任务作用域覆盖无法承接时，才暂时修改主配置；完成消费者复验后恢复 `false`。

不得复制账号凭据、另建入口、让用户选择配置档、把历史工具存在误当成启用理由，或因某个冷能力失效而关闭父意图/连续性/工人等替代核心。

## 父帧绑定后的能力索引

这张表只在当前对象已经绑定后帮助 Owner 找到能力，不从用户原话猜任务，也不把“定义在”写成“恢复了”。`overlay-verified` 才能走统一覆盖；`hot-equivalent` 优先走现有成熟面；`cold-defined` 只保留可逆定义，命中具名缺口后才做一次性恢复和消费者验收；`retired/blocked` 不自动复活。

| 能力族 | 当前状态 | 首选执行面或恢复配方 | 必须回读 |
| --- | --- | --- | --- |
| 文档、PDF、表格、演示、模板、Sites、可视化、LaTeX | `overlay-verified` | 同账户 `codex -p cold-capabilities ...`；退出即回冷 | 覆盖后的 prompt/Skill 可见性，加本次真实制品消费者 |
| 浏览、Chrome、Computer Use、图片 | `hot` | 直接使用当前插件或工具；不为“更全”启用 Windows/DevTools 重复面 | 当前页面、UI 或图片结果 |
| Windows MCP、Chrome DevTools MCP | `hot-equivalent / cold-defined` | 现有 Computer Use/Chrome 足够时不恢复；只有具名能力差额时才用一次性精确覆盖并 fresh 验证 | 差额能力实际调用，随后确认默认仍为 `false` |
| 代码定位与语义探索 | `hot-equivalent / cold-defined` | 默认 `rg`、AST 与原生工具；`codebase-memory`、`serena` 只有具名跨仓消费者时恢复 | 真实定位/编辑消费者，不以进程启动为成功 |
| 外部劳动 | `public Grok available / S-cone default; plugin cold` | S 职责锥内的可分离正收益劳动默认走公共普通 Grok、宽度动态；task-fit 事实可改走 Terra/Luna/native/direct，`opencode_workers` 插件保持冷置 | accepted terminal 仅证明候选运行；认识采用与正式 effect 按当前角色分别验收 |
| Codex 原生协作 | `overlay-verified / cold standing-delegation` | 命中原生协作对象或不可替代 native evidence 时用 `codex -p native-collaboration ...`；同一 root 树内按 canonical task name 直连，退出回冷 | fresh root 能 spawn/list/message/follow-up；写域碰撞被提前通知；独立 TUI 未被误认；基础配置仍为 `false` |
| OpenAI/GitHub/Temporal | `hot-skill / child-mcp-cold` | 优先现有官方 Skill、GitHub Skill/App 或 Temporal bridge；低频子 MCP 只有具名差额时单独恢复 | 实际 API/仓库/workflow 消费者；不能用父插件 enabled 冒充子 MCP 已恢复 |
| Codex Goals feature | `stable / enabled; no standing authority` | 保留官方 stable 能力；只有当前人话与 live parent 先绑定的具名消费者可以使用，feature 本身不得生成 Goal、连续模式或研究路线 | fresh feature list 仍为 stable/enabled，且行为没有把 Goal 提升为父任务、科学议程或第二 Owner |
| `xinao-memory`、`xinao-coordination` 与旧平台 | `retired-authority / cold-definition` | 当前人话、live 研究文件、Decision/研究 Skill 与通用工程面承接；仅按新具名消费者隔离恢复一个能力原子 | 必须证明没有恢复旧科学议程、continuous、Goal authority 或第二 Owner |
| Apps/connectors | `blocked-token` | 当前 401 时不自动热启；只在任务确需 connector 且凭据边界重新成立后恢复 | 新会话真实 connector 调用；web/browser 不受影响 |

能力发现、调用、回读和回冷是四个不同状态。任何一项未知时诚实标成 `partial`，不扩大成系统恢复结论。

## 事实与回滚

- 变更前原件：`D:\XINAO_RESEARCH_RUNTIME\state\codex\productivity-profile\20260805-pre-slim-v1`
- 稀有插件冷置前原件：`D:\XINAO_RESEARCH_RUNTIME\state\codex\productivity-profile\20260805-pre-plugin-cold-v2`
- 当前运行证据：`D:\XINAO_RESEARCH_RUNTIME\state\codex\productivity-profile\CURRENT.md`
- A/B 的 model-free `debug prompt-input` 已读回：默认均为 26,522 字符 / 34,526 UTF-8 bytes；覆盖均为 30,828 字符 / 38,832 bytes。覆盖会恢复文档、PDF、表格、演示、Sites 和 LaTeX 等 Skill，而默认仍保留 Browser 与 Safe Cleanup。
- 2026-08-06 第三次重塑后的再次读回：A/B 默认均为 29,710 字符 / 41,980 UTF-8 bytes，`cold-capabilities` 均为 34,016 / 46,286；四种形态都可见语义保真热条款，默认不见 documents/PDF，覆盖后才出现，而 Browser/Safe Cleanup 始终存在。相对上一条记录的增长跨越了多轮全局行为修复，不能全部归因于本次单一增量；当前最重要的可分离低频索引仍留在本文件按需读取，没有并入热 prompt。
- B fresh smoke 的历史默认首拍为 23,132 input tokens；同模型、同入口以一次性覆盖关闭 Memory 后为 21,338 input、其中 1,792 cached（19,546 未缓存），输出 10 tokens。该对照证明 Memory 有可见成本，不证明其父收益为负；配置未因此关闭。
- GitHub、OpenAI 开发者和 Temporal 没有被算进已证覆盖：前两者的低频 MCP 仍冷置，Temporal 的现用 Skill 来自独立 bridge；在没有同样的 prompt/消费者读回前，不声称 `cold-capabilities` 已恢复这三者。
- 这些文件只约束技术配置，不定义用户任务、科学路线或完成。
