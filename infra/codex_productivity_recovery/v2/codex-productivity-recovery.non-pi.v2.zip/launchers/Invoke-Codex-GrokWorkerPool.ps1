#Requires -Version 7.0
<#[
.SYNOPSIS
  Public bounded Grok entry with stable selector, dispatch epoch, and package mode.
#>
[CmdletBinding()]
param(
    [ValidateRange(1, 32)]
    [int]$N = 1,
    [string]$Prompt = "",
    [string]$PromptFile = "",
    [Alias("PackageManifestPath")]
    [string]$DispatchEnvelopePath = "",
    [string]$Cwd = "",
    [string]$SupervisorRoot = "",
    [string]$Model = "",
    [string]$SelectionPath = "",
    [switch]$SelectionOnly,
    [string]$SelectorReleasePointer = "",
    [string]$DispatchEpochId = "",
    [string]$DispatchEpisodeId = "",
    [ValidateRange(60, 86400)]
    [int]$DispatchEpochMaxAgeSec = 1800,
    [string]$InvalidateDispatchEpochReason = "",
    [switch]$ReplicaMode,
    [string]$MaxTurns = "auto",
    [int]$TimeoutSec = 600,
    [string]$GrokHome = "C:\Users\xx363\.grok-bg-workers",
    [ValidateRange(1, 200000)]
    [int]$MinResultChars = 256,
    [string[]]$RequiredResultMarkers = @(),
    [switch]$RequireJsonObject,
    [string]$JsonSchemaPath = "",
    [string]$CommonWorkKey = "",
    [string]$CommonOperationId = "",
    [string]$CommonTaskContractRef = "",
    [string]$CommonParentOperationId = "",
    [string]$CommonCorrelationId = "",
    [string]$CommonSubjectManifestSha256 = "",
    [string]$CommonFrozenContextSha256 = "",
    [string]$CommonContextManifestPath = "",
    [string]$CommonRulesFile = "",
    [string]$CommonRulesSha256 = "",
    [string]$CommonSealedInputRoot = "",
    [string]$CommonCandidateOutputRoot = "",
    [string]$CommonPhase = "",
    [string[]]$CommonWriteDomains = @(),
    [string[]]$CommonDependsOn = @(),
    [string]$CommonPriorAttemptReceiptPath = "",
    [string]$CommonAdapterRoot = "",
    [string]$CommonPythonExe = "",
    [switch]$AllowExceptionalDocker,
    [string]$DockerJustification = "",
    [string]$TaskRunRoot = "",
    [string]$TaskRunId = "",
    [string]$TaskRunCli = "C:\Users\xx363\.codex\skills\verified-agent-loop\scripts\task_run.py",
    [string]$CheckpointPath = "",
    [string]$RuntimeRoot = "D:\XINAO_RESEARCH_RUNTIME",
    [switch]$SkipPauseGate,
    [switch]$Quiet
)

$ErrorActionPreference = "Stop"
$bridgeRoot = "D:\XINAO_RESEARCH_RUNTIME\tools\grok-worker-pool\bridge"
$runtimeManifestPath = "D:\XINAO_RESEARCH_RUNTIME\tools\grok-worker-pool\runtime-manifest.v1.json"
$script:CodexGrokInvocationPhase = "launcher_preflight"
$script:CodexGrokRepairFirstFailureEmitted = $false

function Write-CodexGrokRepairFirstFailure {
    param(
        [Parameter(Mandatory = $true)][string]$FailureText,
        [string]$InvocationPhase = "launcher_preflight"
    )

    if ($script:CodexGrokRepairFirstFailureEmitted) { return }
    $script:CodexGrokRepairFirstFailureEmitted = $true

    $failureCodeMatch = [regex]::Match(
        $FailureText,
        '(?<![A-Z0-9_])(?:(?:CODEX_)?GROK_[A-Z0-9_]+|PAUSED_ALL)(?![A-Z0-9_])'
    )
    $failureCode = if ($failureCodeMatch.Success) {
        $failureCodeMatch.Value
    }
    else {
        "CODEX_GROK_UNCLASSIFIED_FAILURE"
    }

    $failureClass = "selected_grok_dependency"
    $requiredAction = "diagnose_and_repair_selected_grok_dependency_then_retry_same_public_entry"
    $repairRequired = $true
    $retrySameEntry = $true
    if ($failureCode -match 'PAUSED|STOP') {
        $failureClass = "pause_or_stop"
        $requiredAction = "honor_pause_or_stop"
        $repairRequired = $false
        $retrySameEntry = $false
    }
    elseif ($failureCode -match 'AUTH|OAUTH|TOKEN|CREDENTIAL') {
        $failureClass = "authenticated_profile_dependency"
        $requiredAction = "repair_same_authenticated_grok_profile_then_retry_same_public_entry"
    }
    elseif ($failureCode -match 'SELECTED_MODEL_UNHEALTHY|MODEL_IDENTITY|MODEL_POLICY|CATALOG') {
        $failureClass = "model_policy_catalog_dependency"
        $requiredAction = "resolve_model_from_fresh_authenticated_catalog_and_active_policy_then_retry_same_public_entry"
    }
    elseif ($failureCode -match 'RUNTIME|MANIFEST|FILE_HASH|ENTRY_MISSING') {
        $failureClass = "runtime_integrity_dependency"
        $requiredAction = "repair_sealed_grok_runtime_then_retry_same_public_entry"
    }
    elseif ($failureCode -match 'PREFLIGHT|REQUIRED|CONFLICT|INVALID|MISMATCH|EXACTLY_ONE|REPLICA|DOCKER') {
        $failureClass = "canonical_call_contract"
        $requiredAction = "correct_canonical_grok_call_then_retry_same_public_entry"
    }
    elseif ($failureCode -match 'TIMEOUT|POOL|PROCESS|CLI|OUTPUT|DISPATCH|WORKTREE') {
        $failureClass = "transport_execution_dependency"
        $requiredAction = "repair_grok_transport_or_execution_dependency_then_retry_same_public_entry"
    }

    $safeRequestedModel = $null
    if ($Model -match '^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$') {
        $safeRequestedModel = $Model
    }
    $receipt = [ordered]@{
        schema_version = "xinao.grok.repair_first_failure.v1"
        sentinel = "SENTINEL:GROK_REPAIR_BEFORE_PROVIDER_SUBSTITUTION_V1"
        provider_id = "grok_acpx_headless"
        profile_ref = "grok.com.cached_profile"
        transport_id = "direct-grok-worker-pool"
        invocation_phase = $InvocationPhase
        failure_class = $failureClass
        failure_code = $failureCode
        requested_model = $safeRequestedModel
        failure_is_provider_substitution_evidence = $false
        repair_required_before_provider_substitution = $repairRequired
        calling_ai_required_action = $requiredAction
        retry_same_public_entry = $retrySameEntry
        native_codex_subagent_substitution_allowed = $false
        release_conditions = @(
            "initial_task_fit_or_capability_mismatch_preceded_grok_selection",
            "explicit_pause_or_stop",
            "new_account_secret_or_major_external_effect_requires_user",
            "bounded_repair_proves_selected_grok_route_unavailable_and_current_contract_permits_reroute"
        )
        completion_claim_allowed = $false
    }
    [Console]::Error.WriteLine(
        "CODEX_GROK_REPAIR_FIRST_FAILURE: " + ($receipt | ConvertTo-Json -Depth 6 -Compress)
    )
}

trap {
    Write-CodexGrokRepairFirstFailure `
        -FailureText ([string]$_.Exception.Message) `
        -InvocationPhase $script:CodexGrokInvocationPhase
    throw $_
}

if ($AllowExceptionalDocker) {
    if ([string]::IsNullOrWhiteSpace($DockerJustification)) {
        throw "CODEX_GROK_DOCKER_EXCEPTION_OPT_IN_REQUIRES_JUSTIFICATION"
    }
    if ($DockerJustification.Trim().Length -lt 20) {
        throw "CODEX_GROK_DOCKER_EXCEPTION_JUSTIFICATION_TOO_SHORT"
    }
}
elseif (-not [string]::IsNullOrWhiteSpace($DockerJustification)) {
    throw "CODEX_GROK_DOCKER_JUSTIFICATION_WITHOUT_OPT_IN"
}

function New-CodexGrokTemporaryWorktree {
    param(
        [Parameter(Mandatory = $true)][string]$SourceCwd,
        [Parameter(Mandatory = $true)][string]$TargetPath,
        [Parameter(Mandatory = $true)][string]$AllowedRoot
    )
    $gitCommand = Get-Command git.exe -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $gitCommand) {
        $gitCommand = Get-Command git -ErrorAction SilentlyContinue | Select-Object -First 1
    }
    if ($null -eq $gitCommand) { throw "CODEX_GROK_HOST_WORKTREE_GIT_MISSING" }
    $sourceRootText = @(& $gitCommand.Source -C $SourceCwd rev-parse --show-toplevel 2>&1)
    if ($LASTEXITCODE -ne 0) {
        throw "CODEX_GROK_HOST_WORKTREE_SOURCE_NOT_GIT: $SourceCwd"
    }
    $sourceRoot = [IO.Path]::GetFullPath(($sourceRootText -join "").Trim())
    $sourceHeadText = @(& $gitCommand.Source -C $sourceRoot rev-parse HEAD 2>&1)
    if ($LASTEXITCODE -ne 0) { throw "CODEX_GROK_HOST_WORKTREE_HEAD_UNAVAILABLE" }
    $sourceHead = ($sourceHeadText -join "").Trim()
    $resolvedAllowedRoot = [IO.Path]::GetFullPath($AllowedRoot).TrimEnd('\')
    $resolvedTarget = [IO.Path]::GetFullPath($TargetPath)
    if (-not $resolvedTarget.StartsWith(
        $resolvedAllowedRoot + '\',
        [StringComparison]::OrdinalIgnoreCase
    )) {
        throw "CODEX_GROK_HOST_WORKTREE_TARGET_OUTSIDE_RUNTIME"
    }
    if (Test-Path -LiteralPath $resolvedTarget) {
        throw "CODEX_GROK_HOST_WORKTREE_TARGET_EXISTS: $resolvedTarget"
    }
    New-Item -ItemType Directory -Force -Path $resolvedAllowedRoot | Out-Null
    $addOutput = @(& $gitCommand.Source -C $sourceRoot worktree add --detach $resolvedTarget $sourceHead 2>&1)
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $resolvedTarget -PathType Container)) {
        throw "CODEX_GROK_HOST_WORKTREE_CREATE_FAILED: $($addOutput -join ' ')"
    }
    [pscustomobject]@{
        git_executable = $gitCommand.Source
        source_root = $sourceRoot
        source_head = $sourceHead
        worktree_path = $resolvedTarget
        allowed_root = $resolvedAllowedRoot
    }
}

function Remove-CodexGrokTemporaryWorktree {
    param([Parameter(Mandatory = $true)][object]$Lease)
    $statusOutput = @(& $Lease.git_executable -C $Lease.worktree_path status --short --untracked-files=all 2>&1)
    $statusExit = $LASTEXITCODE
    $removeOutput = @(
        & $Lease.git_executable -C $Lease.source_root worktree remove --force $Lease.worktree_path 2>&1
    )
    $removeExit = $LASTEXITCODE
    [pscustomobject]@{
        status_exit_code = $statusExit
        status_lines = @($statusOutput | ForEach-Object { [string]$_ } | Where-Object { $_ })
        remove_exit_code = $removeExit
        remove_output = ($removeOutput -join "`n")
        removed = ($removeExit -eq 0 -and -not (Test-Path -LiteralPath $Lease.worktree_path))
    }
}

function Assert-CodexGrokWorkerRuntime {
    param(
        [Parameter(Mandatory = $true)][string]$BridgeRoot,
        [Parameter(Mandatory = $true)][string]$ManifestPath
    )

    if (-not (Test-Path -LiteralPath $ManifestPath -PathType Leaf)) {
        throw "CODEX_GROK_RUNTIME_MANIFEST_MISSING: $ManifestPath"
    }
    try {
        $manifest = Get-Content -LiteralPath $ManifestPath -Raw -Encoding UTF8 |
            ConvertFrom-Json -ErrorAction Stop
    }
    catch {
        throw "CODEX_GROK_RUNTIME_MANIFEST_INVALID: $ManifestPath"
    }
    if ([string]$manifest.schema_version -cne "xinao.grok_worker_pool_runtime_manifest.v1") {
        throw "CODEX_GROK_RUNTIME_MANIFEST_SCHEMA_UNSUPPORTED"
    }

    $resolvedBridgeRoot = [IO.Path]::GetFullPath($BridgeRoot).TrimEnd('\')
    $declaredBridgeRoot = [IO.Path]::GetFullPath([string]$manifest.bridge_root).TrimEnd('\')
    if (-not [string]::Equals(
        $resolvedBridgeRoot,
        $declaredBridgeRoot,
        [StringComparison]::OrdinalIgnoreCase
    )) {
        throw "CODEX_GROK_RUNTIME_MANIFEST_ROOT_MISMATCH"
    }

    $requiredFiles = @(
        "GrokAuthenticatedCatalogTime.ps1",
        "GrokAuthenticatedCatalogRefresh.ps1",
        "Invoke-CodexDispatchGrokWorkerPool.ps1",
        "Invoke-GrokWorkerPool.ps1",
        "Invoke-GrokComposer25Worker.ps1",
        "GrokWindowsPathIdentity.ps1",
        "GrokWorkerPoolAccounting.ps1",
        "GrokWorkerProcessRuntime.ps1",
        "GrokWorkerSelectionReceipt.ps1",
        "resolve_grok_worker_selection_receipt.py",
        "GrokSupervisorRootCapability.ps1",
        "Test-GrokCliEffectiveOutput.ps1",
        "Invoke-CodexGrokPackageBatch.ps1",
        "Prepare-CodexGrokTaskLocalCheckpoint.ps1",
        "run_grok_package_batch.py"
    )
    $entries = @($manifest.files)
    if ($entries.Count -ne $requiredFiles.Count) {
        throw "CODEX_GROK_RUNTIME_MANIFEST_FILE_SET_MISMATCH"
    }

    $required = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($requiredFile in $requiredFiles) {
        $null = $required.Add($requiredFile)
    }
    $seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($entry in $entries) {
        $relativePath = [string]$entry.path
        $expectedSha256 = [string]$entry.sha256
        if (
            [string]::IsNullOrWhiteSpace($relativePath) -or
            [IO.Path]::IsPathRooted($relativePath) -or
            -not [string]::Equals(
                $relativePath,
                [IO.Path]::GetFileName($relativePath),
                [StringComparison]::Ordinal
            )
        ) {
            throw "CODEX_GROK_RUNTIME_MANIFEST_PATH_UNSAFE: $relativePath"
        }
        if (-not $required.Contains($relativePath) -or -not $seen.Add($relativePath)) {
            throw "CODEX_GROK_RUNTIME_MANIFEST_FILE_SET_MISMATCH: $relativePath"
        }
        if ($expectedSha256 -cnotmatch '^[0-9a-f]{64}$') {
            throw "CODEX_GROK_RUNTIME_MANIFEST_HASH_INVALID: $relativePath"
        }
        $runtimeFile = Join-Path $resolvedBridgeRoot $relativePath
        if (-not (Test-Path -LiteralPath $runtimeFile -PathType Leaf)) {
            throw "CODEX_GROK_RUNTIME_FILE_MISSING: $runtimeFile"
        }
        $observedSha256 = (Get-FileHash -LiteralPath $runtimeFile -Algorithm SHA256).Hash.ToLowerInvariant()
        if (-not [string]::Equals($observedSha256, $expectedSha256, [StringComparison]::Ordinal)) {
            throw "CODEX_GROK_RUNTIME_FILE_HASH_MISMATCH: $runtimeFile"
        }
    }
    foreach ($requiredFile in $requiredFiles) {
        if (-not $seen.Contains($requiredFile)) {
            throw "CODEX_GROK_RUNTIME_MANIFEST_FILE_SET_MISMATCH: $requiredFile"
        }
    }
}

$script:CodexGrokInvocationPhase = "runtime_integrity_preflight"
Assert-CodexGrokWorkerRuntime -BridgeRoot $bridgeRoot -ManifestPath $runtimeManifestPath
$script:CodexGrokInvocationPhase = "launcher_preflight"

function Get-CodexGrokUtf8Sha256([string]$Value) {
    $bytes = [Text.Encoding]::UTF8.GetBytes($Value)
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString($algorithm.ComputeHash($bytes))).Replace("-", "").ToLowerInvariant()
    }
    finally { $algorithm.Dispose() }
}

function Resolve-CodexGrokOrdinaryDispatchEpoch {
    $identityKind = ""
    $identityValue = $null
    if (-not [string]::IsNullOrWhiteSpace($DispatchEpisodeId)) {
        $identityKind = "dispatch_episode_id"
        $identityValue = $DispatchEpisodeId.Trim()
    }
    elseif (-not [string]::IsNullOrWhiteSpace($env:XINAO_DISPATCH_EPISODE_ID)) {
        $identityKind = "environment_dispatch_episode_id"
        $identityValue = $env:XINAO_DISPATCH_EPISODE_ID.Trim()
    }
    else {
        $stableContext = [ordered]@{}
        if (-not [string]::IsNullOrWhiteSpace($TaskRunId)) {
            $stableContext.task_run_id = $TaskRunId.Trim()
        }
        if (-not [string]::IsNullOrWhiteSpace($CommonParentOperationId)) {
            $stableContext.parent_operation_id = $CommonParentOperationId.Trim()
        }
        if (-not [string]::IsNullOrWhiteSpace($CommonCorrelationId)) {
            $stableContext.correlation_id = $CommonCorrelationId.Trim()
        }
        if ($stableContext.Count -eq 0) {
            throw "CODEX_GROK_DISPATCH_EPISODE_IDENTITY_REQUIRED: pass DispatchEpisodeId, TaskRunId, CommonParentOperationId, CommonCorrelationId, or XINAO_DISPATCH_EPISODE_ID"
        }
        $identityKind = if ($stableContext.Count -eq 1) {
            [string]@($stableContext.Keys)[0]
        } else { "stable_context_tuple" }
        $identityValue = $stableContext
    }
    $identity = [ordered]@{
        schema_version = "xinao.codex_grok_dispatch_epoch_identity.v1"
        identity_kind = $identityKind
        identity_value = $identityValue
    }
    $canonical = $identity | ConvertTo-Json -Compress
    [pscustomobject]@{
        epoch_id = "grok_epoch_v1_" + (Get-CodexGrokUtf8Sha256 $canonical)
        source = $identityKind
    }
}

function Invoke-CodexGrokQuotaEpochQuery(
    [string]$QuotaEntry,
    [string]$EpochId,
    [string]$Runtime,
    [string]$InvalidateReason
) {
    $queryArguments = @{
        Json = $true
        EpochId = $EpochId
        RuntimeRoot = $Runtime
    }
    if (-not [string]::IsNullOrWhiteSpace($InvalidateReason)) {
        $queryArguments.InvalidateReason = $InvalidateReason
    }
    $quotaLine = @(
        & $QuotaEntry @queryArguments 2>&1 | ForEach-Object { [string]$_ }
    ) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Last 1
    if ($LASTEXITCODE -ne 0 -or -not $quotaLine) {
        throw "quota query returned no valid resolution"
    }
    $quotaLine | ConvertFrom-Json -ErrorAction Stop
}

function Get-CodexGrokQuotaSnapshotAgeSec($Resolution) {
    $raw = [string]$Resolution.snapshot.queried_at
    $parsed = [DateTimeOffset]::MinValue
    if (
        [string]::IsNullOrWhiteSpace($raw) -or
        -not [DateTimeOffset]::TryParse(
            $raw,
            [Globalization.CultureInfo]::InvariantCulture,
            [Globalization.DateTimeStyles]::AssumeUniversal,
            [ref]$parsed
        )
    ) {
        throw "CODEX_GROK_QUOTA_SNAPSHOT_TIME_INVALID"
    }
    [Math]::Max(0.0, ([DateTimeOffset]::UtcNow - $parsed.ToUniversalTime()).TotalSeconds)
}

function Get-CodexGrokCommonPreflightIssues {
    $issues = [Collections.Generic.List[string]]::new()
    $allowedPhases = @("EXPLORE", "CONSTRUCT", "VERIFY", "LAND")
    $resolvedPromptText = $null

    if ($N -ne 1) {
        $issues.Add("N must be 1 for common-contract mode")
    }
    if ([string]::IsNullOrWhiteSpace($PromptFile)) {
        $issues.Add("PromptFile is required for common-contract mode")
    }
    else {
        try { $resolvedPromptFile = [IO.Path]::GetFullPath($PromptFile) }
        catch {
            $resolvedPromptFile = ""
            $issues.Add("PromptFile is not a valid path: $PromptFile")
        }
        if (
            -not [string]::IsNullOrWhiteSpace($resolvedPromptFile) -and
            -not (Test-Path -LiteralPath $resolvedPromptFile -PathType Leaf)
        ) {
            $issues.Add("PromptFile does not exist: $resolvedPromptFile")
        }
        elseif (-not [string]::IsNullOrWhiteSpace($resolvedPromptFile)) {
            try {
                $strictUtf8 = [Text.UTF8Encoding]::new($false, $true)
                $resolvedPromptText = [IO.File]::ReadAllText($resolvedPromptFile, $strictUtf8)
            }
            catch { $issues.Add("PromptFile must be valid UTF-8: $resolvedPromptFile") }
        }
    }
    foreach ($marker in @($RequiredResultMarkers)) {
        $markerText = [string]$marker
        if ([string]::IsNullOrWhiteSpace($markerText)) {
            $issues.Add("RequiredResultMarkers must not contain an empty value")
        }
        elseif (
            $null -ne $resolvedPromptText -and
            $resolvedPromptText.IndexOf($markerText, [StringComparison]::Ordinal) -lt 0
        ) {
            $issues.Add("PromptFile must explicitly require result marker: $markerText")
        }
    }
    if (-not [string]::IsNullOrWhiteSpace($Prompt)) {
        $issues.Add("inline Prompt is not accepted in common-contract mode; use PromptFile")
    }
    if ([string]::IsNullOrWhiteSpace($CommonWorkKey)) {
        $issues.Add("CommonWorkKey is required")
    }
    if ([string]::IsNullOrWhiteSpace($CommonOperationId)) {
        $issues.Add("CommonOperationId is required")
    }
    if ($CommonSubjectManifestSha256 -notmatch '^[0-9a-f]{64}$') {
        $issues.Add("CommonSubjectManifestSha256 must be 64 lowercase hexadecimal characters")
    }
    if ([string]::IsNullOrWhiteSpace($CommonPhase)) {
        $issues.Add("CommonPhase is required; choose EXPLORE, CONSTRUCT, VERIFY, or LAND")
    }
    elseif ($allowedPhases -cnotcontains $CommonPhase) {
        $issues.Add("CommonPhase must be one of EXPLORE, CONSTRUCT, VERIFY, LAND")
    }
    if (
        [string]::IsNullOrWhiteSpace($CommonFrozenContextSha256) -and
        [string]::IsNullOrWhiteSpace($CommonContextManifestPath)
    ) {
        $issues.Add("CommonFrozenContextSha256 or CommonContextManifestPath is required")
    }
    if (
        -not [string]::IsNullOrWhiteSpace($CommonFrozenContextSha256) -and
        $CommonFrozenContextSha256 -notmatch '^[0-9a-f]{64}$'
    ) {
        $issues.Add("CommonFrozenContextSha256 must be 64 lowercase hexadecimal characters")
    }
    if (-not [string]::IsNullOrWhiteSpace($CommonContextManifestPath)) {
        try { $resolvedContextManifest = [IO.Path]::GetFullPath($CommonContextManifestPath) }
        catch {
            $resolvedContextManifest = ""
            $issues.Add("CommonContextManifestPath is not a valid path: $CommonContextManifestPath")
        }
        if (
            -not [string]::IsNullOrWhiteSpace($resolvedContextManifest) -and
            -not (Test-Path -LiteralPath $resolvedContextManifest -PathType Leaf)
        ) {
            $issues.Add("CommonContextManifestPath does not exist: $resolvedContextManifest")
        }
    }
    if ([string]::IsNullOrWhiteSpace($CommonRulesFile)) {
        $issues.Add("CommonRulesFile is required")
    }
    else {
        try { $resolvedRulesFile = [IO.Path]::GetFullPath($CommonRulesFile) }
        catch {
            $resolvedRulesFile = ""
            $issues.Add("CommonRulesFile is not a valid path: $CommonRulesFile")
        }
        if (
            -not [string]::IsNullOrWhiteSpace($resolvedRulesFile) -and
            -not (Test-Path -LiteralPath $resolvedRulesFile -PathType Leaf)
        ) {
            $issues.Add("CommonRulesFile does not exist: $resolvedRulesFile")
        }
    }
    if ($CommonRulesSha256 -notmatch '^[0-9a-f]{64}$') {
        $issues.Add("CommonRulesSha256 must be 64 lowercase hexadecimal characters")
    }
    elseif (
        -not [string]::IsNullOrWhiteSpace($resolvedRulesFile) -and
        (Test-Path -LiteralPath $resolvedRulesFile -PathType Leaf)
    ) {
        $observedRulesSha256 = (
            Get-FileHash -LiteralPath $resolvedRulesFile -Algorithm SHA256
        ).Hash.ToLowerInvariant()
        if (-not [string]::Equals(
            $observedRulesSha256,
            $CommonRulesSha256,
            [StringComparison]::Ordinal
        )) {
            $issues.Add("CommonRulesSha256 does not match CommonRulesFile")
        }
    }
    if (-not [string]::IsNullOrWhiteSpace($CommonSealedInputRoot)) {
        try { $resolvedSealedInputRoot = [IO.Path]::GetFullPath($CommonSealedInputRoot) }
        catch {
            $resolvedSealedInputRoot = ""
            $issues.Add("CommonSealedInputRoot is not a valid path: $CommonSealedInputRoot")
        }
        if (
            -not [string]::IsNullOrWhiteSpace($resolvedSealedInputRoot) -and
            -not (Test-Path -LiteralPath $resolvedSealedInputRoot -PathType Container)
        ) {
            $issues.Add("CommonSealedInputRoot does not exist: $resolvedSealedInputRoot")
        }
        if ($CommonSealedInputRoot -match '[,\r\n]') {
            $issues.Add("CommonSealedInputRoot contains an unsafe delimiter")
        }
    }
    if (-not [string]::IsNullOrWhiteSpace($CommonCandidateOutputRoot)) {
        try { $resolvedCandidateOutputRoot = [IO.Path]::GetFullPath($CommonCandidateOutputRoot) }
        catch {
            $resolvedCandidateOutputRoot = ""
            $issues.Add("CommonCandidateOutputRoot is not a valid path: $CommonCandidateOutputRoot")
        }
        if (
            -not [string]::IsNullOrWhiteSpace($resolvedCandidateOutputRoot) -and
            -not (Test-Path -LiteralPath $resolvedCandidateOutputRoot -PathType Container)
        ) {
            $issues.Add("CommonCandidateOutputRoot does not exist: $resolvedCandidateOutputRoot")
        }
        if (-not [string]::IsNullOrWhiteSpace($resolvedCandidateOutputRoot)) {
            try { $resolvedCommonCwd = [IO.Path]::GetFullPath($Cwd) }
            catch { $resolvedCommonCwd = "" }
            if (
                -not [string]::IsNullOrWhiteSpace($resolvedCommonCwd) -and
                -not [string]::Equals(
                    $resolvedCandidateOutputRoot,
                    $resolvedCommonCwd,
                    [StringComparison]::OrdinalIgnoreCase
                )
            ) {
                $issues.Add("CommonCandidateOutputRoot must equal Cwd")
            }
            $expectedWriteDomain = "candidate_output_root:" + (
                $resolvedCandidateOutputRoot.Replace('\', '/').TrimEnd('/').ToLowerInvariant()
            )
            if (
                @($CommonWriteDomains).Count -ne 1 -or
                -not [string]::Equals(
                    [string]$CommonWriteDomains[0],
                    $expectedWriteDomain,
                    [StringComparison]::Ordinal
                )
            ) {
                $issues.Add("CommonWriteDomains must contain only $expectedWriteDomain")
            }
        }
    }
    elseif (@($CommonWriteDomains).Count -gt 0) {
        $issues.Add("CommonCandidateOutputRoot is required when CommonWriteDomains is supplied")
    }
    if (-not [string]::IsNullOrWhiteSpace($JsonSchemaPath)) {
        try { $resolvedJsonSchema = [IO.Path]::GetFullPath($JsonSchemaPath) }
        catch {
            $resolvedJsonSchema = ""
            $issues.Add("JsonSchemaPath is not a valid path: $JsonSchemaPath")
        }
        if (
            -not [string]::IsNullOrWhiteSpace($resolvedJsonSchema) -and
            -not (Test-Path -LiteralPath $resolvedJsonSchema -PathType Leaf)
        ) {
            $issues.Add("JsonSchemaPath does not exist: $resolvedJsonSchema")
        }
    }
    if (
        -not [string]::IsNullOrWhiteSpace($CommonPriorAttemptReceiptPath) -and
        -not (Test-Path -LiteralPath $CommonPriorAttemptReceiptPath -PathType Leaf)
    ) {
        $issues.Add("CommonPriorAttemptReceiptPath does not exist: $CommonPriorAttemptReceiptPath")
    }

    return @($issues)
}

if ($SelectionOnly) {
    $selectionOnlyConflicts = [Collections.Generic.List[string]]::new()
    if ($N -ne 1) { $selectionOnlyConflicts.Add("N must be 1") }
    if ($ReplicaMode) { $selectionOnlyConflicts.Add("ReplicaMode is not allowed") }
    if (-not [string]::IsNullOrWhiteSpace($Prompt)) { $selectionOnlyConflicts.Add("Prompt is not allowed") }
    if (-not [string]::IsNullOrWhiteSpace($PromptFile)) { $selectionOnlyConflicts.Add("PromptFile is not allowed") }
    if (-not [string]::IsNullOrWhiteSpace($DispatchEnvelopePath)) { $selectionOnlyConflicts.Add("DispatchEnvelopePath is not allowed") }
    if (-not [string]::IsNullOrWhiteSpace($SelectionPath)) { $selectionOnlyConflicts.Add("SelectionPath is output-owned and must be omitted") }
    if (-not [string]::IsNullOrWhiteSpace($DispatchEpochId)) { $selectionOnlyConflicts.Add("DispatchEpochId is not allowed") }
    if (-not [string]::IsNullOrWhiteSpace($DispatchEpisodeId)) { $selectionOnlyConflicts.Add("DispatchEpisodeId is not allowed") }
    if (-not [string]::IsNullOrWhiteSpace($TaskRunRoot)) { $selectionOnlyConflicts.Add("TaskRunRoot is not allowed") }
    if (-not [string]::IsNullOrWhiteSpace($TaskRunId)) { $selectionOnlyConflicts.Add("TaskRunId is not allowed") }
    if (-not [string]::IsNullOrWhiteSpace($CheckpointPath)) { $selectionOnlyConflicts.Add("CheckpointPath is not allowed") }
    foreach ($value in @(
        $CommonWorkKey, $CommonOperationId, $CommonTaskContractRef,
        $CommonParentOperationId, $CommonCorrelationId,
        $CommonSubjectManifestSha256, $CommonFrozenContextSha256,
        $CommonContextManifestPath, $CommonRulesFile, $CommonRulesSha256,
        $CommonSealedInputRoot, $CommonCandidateOutputRoot, $CommonPhase, $CommonPriorAttemptReceiptPath,
        $CommonAdapterRoot
    )) {
        if (-not [string]::IsNullOrWhiteSpace([string]$value)) {
            $selectionOnlyConflicts.Add("Common contract fields are not allowed")
            break
        }
    }
    if (@($CommonWriteDomains).Count -gt 0 -or @($CommonDependsOn).Count -gt 0) {
        $selectionOnlyConflicts.Add("Common contract arrays are not allowed")
    }
    if ($AllowExceptionalDocker -or -not [string]::IsNullOrWhiteSpace($DockerJustification)) {
        $selectionOnlyConflicts.Add("Docker exception fields are not allowed")
    }
    if ([string]::IsNullOrWhiteSpace($Model)) { $selectionOnlyConflicts.Add("Model is required") }
    if ([string]::IsNullOrWhiteSpace($Cwd)) { $selectionOnlyConflicts.Add("Cwd is required") }
    if ($selectionOnlyConflicts.Count -gt 0) {
        throw (
            "CODEX_GROK_SELECTION_ONLY_PREFLIGHT_FAILED: " +
            [string]::Join("; ", $selectionOnlyConflicts.ToArray())
        )
    }

    $entry = Join-Path $bridgeRoot "Invoke-CodexDispatchGrokWorkerPool.ps1"
    if (-not (Test-Path -LiteralPath $entry -PathType Leaf)) {
        throw "CODEX_GROK_WORKER_POOL_ENTRY_MISSING: $entry"
    }
    $selectionOnlyArguments = @{
        N = 1
        Model = $Model
        Cwd = $Cwd
        SelectionOnly = $true
        SupervisorRoot = $SupervisorRoot
        SelectorReleasePointer = $SelectorReleasePointer
        RuntimeRoot = $RuntimeRoot
        GrokHome = $GrokHome
    }
    $script:CodexGrokInvocationPhase = "selection_only"
    & $entry @selectionOnlyArguments
    $selectionOnlyExitCode = if ($null -eq $LASTEXITCODE) { 0 } else { [int]$LASTEXITCODE }
    if ($selectionOnlyExitCode -ne 0) {
        Write-CodexGrokRepairFirstFailure `
            -FailureText "CODEX_GROK_SELECTION_ONLY_EXIT_NONZERO" `
            -InvocationPhase $script:CodexGrokInvocationPhase
    }
    exit $selectionOnlyExitCode
}

$packageMode = -not [string]::IsNullOrWhiteSpace($DispatchEnvelopePath)
$commonRequested = $false
$dispatchEpochSource = ""
if ($packageMode) {
    if ($N -ne 1 -or $ReplicaMode -or -not [string]::IsNullOrWhiteSpace($Prompt) -or -not [string]::IsNullOrWhiteSpace($PromptFile)) {
        throw "CODEX_GROK_PACKAGE_MODE_PARAMETER_CONFLICT"
    }
    try {
        $dispatchEnvelope = Get-Content -LiteralPath $DispatchEnvelopePath -Raw -Encoding UTF8 |
            ConvertFrom-Json -ErrorAction Stop
    } catch {
        throw "CODEX_GROK_DISPATCH_ENVELOPE_INVALID: $DispatchEnvelopePath"
    }
    $manifestModel = [string]$dispatchEnvelope.selection.model_id
    if ([string]::IsNullOrWhiteSpace($manifestModel)) {
        throw "CODEX_GROK_PACKAGE_MODEL_REQUIRED"
    }
    if ([string]::IsNullOrWhiteSpace($Model)) {
        $Model = $manifestModel
    }
    elseif (-not [string]::Equals($Model, $manifestModel, [StringComparison]::Ordinal)) {
        throw "CODEX_GROK_PACKAGE_MODEL_MISMATCH"
    }
    $manifestEpochId = [string]$dispatchEnvelope.dispatch_epoch.epoch_id
    if ([string]::IsNullOrWhiteSpace($manifestEpochId)) {
        throw "CODEX_GROK_PACKAGE_EPOCH_REQUIRED"
    }
    if ([string]::IsNullOrWhiteSpace($DispatchEpochId)) {
        $DispatchEpochId = $manifestEpochId
    }
    elseif (-not [string]::Equals($DispatchEpochId, $manifestEpochId, [StringComparison]::Ordinal)) {
        throw "CODEX_GROK_PACKAGE_EPOCH_MISMATCH"
    }
    $dispatchEpochSource = "neutral_package_manifest"
    if (-not [string]::IsNullOrWhiteSpace($InvalidateDispatchEpochReason)) {
        throw "CODEX_GROK_PACKAGE_EPOCH_INVALIDATE_RESEAL_REQUIRED"
    }
    if ([string]::IsNullOrWhiteSpace($TaskRunRoot)) {
        throw "CODEX_GROK_PACKAGE_TASK_RUN_ROOT_REQUIRED"
    }
    if ([string]::IsNullOrWhiteSpace($TaskRunId)) {
        throw "CODEX_GROK_PACKAGE_TASK_RUN_ID_REQUIRED"
    }
    try { $TaskRunCli = [IO.Path]::GetFullPath($TaskRunCli) }
    catch { throw "CODEX_GROK_TASK_RUN_CLI_PATH_INVALID: $TaskRunCli" }
    if (-not (Test-Path -LiteralPath $TaskRunCli -PathType Leaf)) {
        throw "CODEX_GROK_TASK_RUN_CLI_MISSING: $TaskRunCli"
    }
}
else {
    if ([string]::IsNullOrWhiteSpace($Model)) {
        throw "CODEX_GROK_MODEL_REQUIRED"
    }
    if ([string]::IsNullOrWhiteSpace($Cwd)) { throw "CODEX_GROK_CWD_REQUIRED" }
    if ([string]::IsNullOrWhiteSpace($Prompt) -eq [string]::IsNullOrWhiteSpace($PromptFile)) {
        throw "CODEX_GROK_EXACTLY_ONE_PROMPT_SOURCE_REQUIRED"
    }
    if ($N -gt 1 -and -not $ReplicaMode) {
        throw "CODEX_GROK_MULTI_LANE_REQUIRES_EXPLICIT_REPLICA_MODE"
    }
    $commonRequested = (
        -not [string]::IsNullOrWhiteSpace($CommonWorkKey) -or
        -not [string]::IsNullOrWhiteSpace($CommonOperationId) -or
        -not [string]::IsNullOrWhiteSpace($CommonSubjectManifestSha256) -or
        -not [string]::IsNullOrWhiteSpace($CommonFrozenContextSha256) -or
        -not [string]::IsNullOrWhiteSpace($CommonContextManifestPath) -or
        -not [string]::IsNullOrWhiteSpace($CommonRulesFile) -or
        -not [string]::IsNullOrWhiteSpace($CommonRulesSha256) -or
        -not [string]::IsNullOrWhiteSpace($CommonSealedInputRoot) -or
        -not [string]::IsNullOrWhiteSpace($CommonCandidateOutputRoot) -or
        -not [string]::IsNullOrWhiteSpace($CommonPhase) -or
        -not [string]::IsNullOrWhiteSpace($CommonPriorAttemptReceiptPath) -or
        @($CommonWriteDomains).Count -gt 0
    )
    if ($commonRequested) {
        $commonPreflightIssues = @(Get-CodexGrokCommonPreflightIssues)
        if ($commonPreflightIssues.Count -gt 0) {
            throw (
                "CODEX_GROK_COMMON_PREFLIGHT_FAILED:`n - " +
                ($commonPreflightIssues -join "`n - ")
            )
        }
    }
    if ($AllowExceptionalDocker -and -not $commonRequested) {
        throw "CODEX_GROK_DOCKER_EXCEPTION_REQUIRES_COMMON_CONTRACT"
    }
    if ([string]::IsNullOrWhiteSpace($DispatchEpochId)) {
        $resolvedEpoch = Resolve-CodexGrokOrdinaryDispatchEpoch
        $DispatchEpochId = [string]$resolvedEpoch.epoch_id
        $dispatchEpochSource = [string]$resolvedEpoch.source
    }
    else {
        $dispatchEpochSource = "explicit_dispatch_epoch_id"
    }
}

if ($packageMode) {
    $checkpointPreparer = Join-Path $bridgeRoot "Prepare-CodexGrokTaskLocalCheckpoint.ps1"
    if (-not (Test-Path -LiteralPath $checkpointPreparer -PathType Leaf)) {
        throw "CODEX_GROK_CHECKPOINT_PREPARER_MISSING: $checkpointPreparer"
    }
    $checkpointReport = & $checkpointPreparer `
        -RuntimeRoot $RuntimeRoot `
        -SelectorReleasePointer $SelectorReleasePointer `
        -TaskRunRoot $TaskRunRoot `
        -TaskRunId $TaskRunId `
        -DispatchEnvelopePath $DispatchEnvelopePath `
        -TaskRunCli $TaskRunCli `
        -CheckpointPath $CheckpointPath
    $CheckpointPath = [string]$checkpointReport.checkpoint_path
    if ([string]::IsNullOrWhiteSpace($CheckpointPath)) {
        throw "CODEX_GROK_CHECKPOINT_PREFLIGHT_OUTPUT_INVALID"
    }
}

$DispatchId = "cdx_" + (Get-Date -Format "yyyyMMddTHHmmss") + "_" + ([guid]::NewGuid().ToString("N").Substring(0, 8))
$PoolId = "gwp_" + (Get-Date -Format "yyyyMMddTHHmmss") + "_" + ([guid]::NewGuid().ToString("N").Substring(0, 8))

# One advisory query per epoch. Failure is recorded but never blocks positive-benefit work.
$quotaEntry = Join-Path $RuntimeRoot "state\quota_query\Get-AIQuota.ps1"
$quotaResolution = $null
$quotaError = ""
if (Test-Path -LiteralPath $quotaEntry -PathType Leaf) {
    try {
        $quotaResolution = Invoke-CodexGrokQuotaEpochQuery `
            -QuotaEntry $quotaEntry `
            -EpochId $DispatchEpochId `
            -Runtime $RuntimeRoot `
            -InvalidateReason $InvalidateDispatchEpochReason
    }
    catch { $quotaError = "$_" }
}
else { $quotaError = "quota entry missing: $quotaEntry" }

if ($null -ne $quotaResolution) {
    try {
        $quotaAgeSec = Get-CodexGrokQuotaSnapshotAgeSec $quotaResolution
        if ($quotaAgeSec -ge $DispatchEpochMaxAgeSec) {
            if ($packageMode) {
                throw "CODEX_GROK_PACKAGE_EPOCH_EXPIRED_RESEAL_REQUIRED"
            }
            $quotaResolution = Invoke-CodexGrokQuotaEpochQuery `
                -QuotaEntry $quotaEntry `
                -EpochId $DispatchEpochId `
                -Runtime $RuntimeRoot `
                -InvalidateReason ("dispatch_epoch_expired_after_{0}_seconds" -f [int][Math]::Floor($quotaAgeSec))
        }
    }
    catch {
        if ([string]$_.Exception.Message -match '^CODEX_GROK_PACKAGE_EPOCH_') { throw }
        $quotaError = "$_"
        $quotaResolution = $null
    }
}

if ($packageMode) {
    if (
        $null -ne $quotaResolution -and
        (
            [string]$quotaResolution.snapshot.snapshot_id -ne [string]$dispatchEnvelope.dispatch_epoch.quota_snapshot_id -or
            -not [string]::Equals(
                [IO.Path]::GetFullPath([string]$quotaResolution.snapshot.snapshot_ref),
                [IO.Path]::GetFullPath([string]$dispatchEnvelope.dispatch_epoch.quota_snapshot_ref),
                [StringComparison]::OrdinalIgnoreCase
            ) -or
            [string]$quotaResolution.snapshot.snapshot_sha256 -ne [string]$dispatchEnvelope.dispatch_epoch.quota_snapshot_sha256
        )
    ) {
        throw "CODEX_GROK_PACKAGE_QUOTA_SNAPSHOT_MISMATCH"
    }
    $packageEntry = Join-Path $bridgeRoot "Invoke-CodexGrokPackageBatch.ps1"
    if (-not (Test-Path -LiteralPath $packageEntry -PathType Leaf)) {
        throw "CODEX_GROK_PACKAGE_ENTRY_MISSING: $packageEntry"
    }
    $packageArgs = @{
        DispatchEnvelopePath = $DispatchEnvelopePath
        Model = $Model
        RuntimeRoot = $RuntimeRoot
        SelectorReleasePointer = $SelectorReleasePointer
        TimeoutSec = $TimeoutSec
        TaskRunRoot = $TaskRunRoot
        TaskRunId = $TaskRunId
        TaskRunCli = $TaskRunCli
        CheckpointPath = $CheckpointPath
    }
    if ($Quiet) { $packageArgs.Quiet = $true }
    $script:CodexGrokInvocationPhase = "package_dispatch"
    & $packageEntry @packageArgs
    $packageExitCode = if ($null -eq $LASTEXITCODE) { 0 } else { [int]$LASTEXITCODE }
    if ($packageExitCode -ne 0) {
        Write-CodexGrokRepairFirstFailure `
            -FailureText "CODEX_GROK_PACKAGE_DISPATCH_EXIT_NONZERO" `
            -InvocationPhase $script:CodexGrokInvocationPhase
    }
    exit $packageExitCode
}

$entry = Join-Path $bridgeRoot "Invoke-CodexDispatchGrokWorkerPool.ps1"
if (-not (Test-Path -LiteralPath $entry -PathType Leaf)) {
    throw "CODEX_GROK_WORKER_POOL_ENTRY_MISSING: $entry"
}
$effectiveCwd = $Cwd
$hostWorktreeLease = $null
if (
    $commonRequested -and
    -not $AllowExceptionalDocker -and
    @($CommonWriteDomains).Count -eq 0
) {
    if (-not [string]::IsNullOrWhiteSpace($SelectionPath)) {
        throw "CODEX_GROK_HOST_WORKTREE_REQUIRES_FRESH_SELECTION"
    }
    if (-not [string]::IsNullOrWhiteSpace($CommonSealedInputRoot)) {
        throw "CODEX_GROK_HOST_SEALED_INPUT_REQUIRES_NONCONTAINER_SNAPSHOT_CONTRACT"
    }
    $hostWorktreeRoot = Join-Path $RuntimeRoot "state\grok_host_worktrees"
    $hostWorktreePath = Join-Path $hostWorktreeRoot $PoolId
    $hostWorktreeLease = New-CodexGrokTemporaryWorktree `
        -SourceCwd $Cwd `
        -TargetPath $hostWorktreePath `
        -AllowedRoot $hostWorktreeRoot
    $effectiveCwd = [string]$hostWorktreeLease.worktree_path
}
$arguments = @{
    N = $N
    Model = $Model
    SelectionPath = $SelectionPath
    SupervisorRoot = $SupervisorRoot
    SelectorReleasePointer = $SelectorReleasePointer
    RuntimeRoot = $RuntimeRoot
    MaxTurns = $MaxTurns
    TimeoutSec = $TimeoutSec
    GrokHome = $GrokHome
    MinResultChars = $MinResultChars
    RequiredResultMarkers = @($RequiredResultMarkers)
    DispatchId = $DispatchId
    PoolId = $PoolId
    Cwd = $effectiveCwd
    CommonPythonExe = $CommonPythonExe
    DispatchEpochId = $DispatchEpochId
    DispatchEpochSource = $dispatchEpochSource
    DispatchEpochMaxAgeSec = $DispatchEpochMaxAgeSec
    QuotaResolutionError = $quotaError
}
if ($AllowExceptionalDocker) {
    $arguments.AllowExceptionalDocker = $true
    $arguments.DockerJustification = $DockerJustification
}
if ($null -ne $quotaResolution) {
    $arguments.QuotaSnapshotId = [string]$quotaResolution.snapshot.snapshot_id
    $arguments.QuotaSnapshotRef = [string]$quotaResolution.snapshot.snapshot_ref
    $arguments.QuotaSnapshotSha256 = [string]$quotaResolution.snapshot.snapshot_sha256
    $arguments.QuotaResolutionStatus = [string]$quotaResolution.status
}
if ($Prompt) { $arguments.Prompt = $Prompt }
if ($PromptFile) { $arguments.PromptFile = $PromptFile }
if ($RequireJsonObject) { $arguments.RequireJsonObject = $true }
if ($JsonSchemaPath) { $arguments.JsonSchemaPath = $JsonSchemaPath }
if ($CommonWorkKey) { $arguments.CommonWorkKey = $CommonWorkKey }
if ($CommonOperationId) { $arguments.CommonOperationId = $CommonOperationId }
if ($CommonTaskContractRef) { $arguments.CommonTaskContractRef = $CommonTaskContractRef }
if ($CommonParentOperationId) { $arguments.CommonParentOperationId = $CommonParentOperationId }
if ($CommonCorrelationId) { $arguments.CommonCorrelationId = $CommonCorrelationId }
if ($CommonSubjectManifestSha256) { $arguments.CommonSubjectManifestSha256 = $CommonSubjectManifestSha256 }
if ($CommonFrozenContextSha256) { $arguments.CommonFrozenContextSha256 = $CommonFrozenContextSha256 }
if ($CommonContextManifestPath) { $arguments.CommonContextManifestPath = $CommonContextManifestPath }
if ($CommonRulesFile) { $arguments.CommonRulesFile = $CommonRulesFile }
if ($CommonRulesSha256) { $arguments.CommonRulesSha256 = $CommonRulesSha256 }
if ($CommonSealedInputRoot) { $arguments.CommonSealedInputRoot = $CommonSealedInputRoot }
if ($CommonCandidateOutputRoot) { $arguments.CommonCandidateOutputRoot = $CommonCandidateOutputRoot }
if ($CommonPhase) { $arguments.CommonPhase = $CommonPhase }
if ($CommonPriorAttemptReceiptPath) { $arguments.CommonPriorAttemptReceiptPath = $CommonPriorAttemptReceiptPath }
if ($CommonAdapterRoot) { $arguments.CommonAdapterRoot = $CommonAdapterRoot }
if (@($CommonWriteDomains).Count -gt 0) { $arguments.CommonWriteDomains = @($CommonWriteDomains) }
if (@($CommonDependsOn).Count -gt 0) { $arguments.CommonDependsOn = @($CommonDependsOn) }
if ($SkipPauseGate) { $arguments.SkipPauseGate = $true }
if ($Quiet) { $arguments.Quiet = $true }

$dispatchExitCode = 1
$hostIsolationCleanup = $null
$script:CodexGrokInvocationPhase = "worker_dispatch"
try {
    & $entry @arguments
    $dispatchExitCode = if ($null -eq $LASTEXITCODE) { 0 } else { [int]$LASTEXITCODE }
}
finally {
    if ($null -ne $hostWorktreeLease) {
        $hostIsolationCleanup = Remove-CodexGrokTemporaryWorktree -Lease $hostWorktreeLease
        $hostIsolationEvidenceDir = Join-Path $RuntimeRoot ("state\grok_worker_pool\" + $PoolId)
        New-Item -ItemType Directory -Force -Path $hostIsolationEvidenceDir | Out-Null
        $hostIsolationReceipt = [ordered]@{
            schema_version = "xinao.grok_host_isolation_receipt.v1"
            generated_at = (Get-Date).ToString("o")
            pool_id = $PoolId
            mode = "temporary-git-worktree"
            container_used = $false
            original_cwd = $Cwd
            isolated_cwd = [string]$hostWorktreeLease.worktree_path
            source_git_root = [string]$hostWorktreeLease.source_root
            source_head = [string]$hostWorktreeLease.source_head
            worker_changes_detected = @($hostIsolationCleanup.status_lines).Count -gt 0
            worker_status_lines = @($hostIsolationCleanup.status_lines)
            cleanup_removed = $hostIsolationCleanup.removed -eq $true
            cleanup_exit_code = [int]$hostIsolationCleanup.remove_exit_code
            cleanup_output = [string]$hostIsolationCleanup.remove_output
            completion_claim_allowed = $false
        }
        $receiptPath = Join-Path $hostIsolationEvidenceDir "host_isolation_receipt.json"
        [IO.File]::WriteAllText(
            $receiptPath,
            ($hostIsolationReceipt | ConvertTo-Json -Depth 8),
            [Text.UTF8Encoding]::new($false)
        )
        if (
            $dispatchExitCode -eq 0 -and
            (
                $hostIsolationReceipt.worker_changes_detected -eq $true -or
                $hostIsolationReceipt.cleanup_removed -ne $true
            )
        ) {
            $dispatchExitCode = 6
        }
    }
}
if ($null -ne $hostWorktreeLease -and $hostIsolationCleanup.removed -ne $true) {
    $script:CodexGrokInvocationPhase = "host_isolation_cleanup"
    throw "CODEX_GROK_HOST_WORKTREE_CLEANUP_FAILED: $($hostWorktreeLease.worktree_path)"
}
if ($dispatchExitCode -ne 0) {
    Write-CodexGrokRepairFirstFailure `
        -FailureText "CODEX_GROK_WORKER_DISPATCH_EXIT_NONZERO" `
        -InvocationPhase $script:CodexGrokInvocationPhase
}
exit $dispatchExitCode
