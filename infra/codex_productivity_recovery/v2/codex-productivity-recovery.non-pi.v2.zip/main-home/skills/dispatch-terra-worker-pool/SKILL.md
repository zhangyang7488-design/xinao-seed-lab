---
name: dispatch-terra-worker-pool
description: >
  Dispatch GPT-5.6 Terra workers for long, complex, independent research, diagnosis, synthesis,
  implementation, or verification through the normal public Terra WorkerPool. Terra may form or
  reframe a local XINAO question and carry it through reasoning, code, experiment, attack, and
  learning when the shared Codex quota cost is worthwhile. The task and scientific route must
  already be selected outside this Skill; Terra returns a candidate, the designated cognition
  consumer decides epistemic use, and the current effect Owner retains formal shared writing.
---

# Dispatch Terra Worker Pool（普通工人 · 与 Grok 普通劳动同构）

Terra is an additional thinking and research subject, not merely a fallback executor. A clear
bounded question or parent cone selected by the current cognition consumer or engineering effect
Owner inside its own role is enough for the ordinary route.
Neither this Skill nor its receipt selects a scientific parent, mode, or next question.

Terra may also occupy one long branch of the provider-neutral XINAO free-research tree. A bounded
`N=1` Terra subject can choose or reframe a local question, reason across long context, build, test,
attack, and return a plan-changing candidate. A world-owning Sol or fresh fusion subject retains the
domain synthesis; S may supervise runtime and shared effects without running a parallel answer.
Shared Codex quota affects whether that Terra branch repays its cost; it is not a mechanical
prohibition and does not redefine the research topology.

## 这是什么

- **公开唯一入口：** `C:\Users\xx363\CodexLaunchers\Invoke-Codex-TerraWorkerPool.ps1`
- **后端：** `codex exec -m gpt-5.6-terra`（默认 medium reasoning）
- **形态：** 通用有界 one-shot pool · candidate-only · exact pool/lane 回执
- **同构对象：** Grok **普通工人劳动**（`Invoke-Codex-GrokWorkerPool` 省略 SelectionPath 的日常路径）
- **不是：** OpenCode/API MCP 半生不熟栈；不是 formal science package 批；不是第二 Owner

## 何时用

优先 Terra（相对 Grok）当：

- Grok 证据互斥 / 两次跑偏 / 失败后需要独立第二意见
- 超长上下文、复杂仓库调试、跨模块根因
- 一个值得长期独立思考、可能改变当前 cognition subject 问题框架的自由研究分支
- 正式采用前的重要独立复核
- 用户明确点名 Terra

在 S 自己的工程、实验控制、证据和 effect 职责锥内，普通 Grok 是可分离正收益劳动的
默认入口；当长上下文、复杂调试、独立第二意见、共享 Codex 额度的可接受性或其他当前
任务适配明确胜过该默认时，才优先 Terra。这个相对默认不进入 world-owning Sol 的领域
cognition；该主体仍按自己的现实计算选择器官。

不要用本 Skill：

- 让 Terra 或 transport 选择科学父意图、替 world-owning Sol 决定研究路线、或宣称完成
- 大量有界搜索/复算/测试/筛选且 **Luna Max** 的当前净收益更高
- 需要正式 effect 终验本身（由当前 effect Owner 做）

## 硬边界

- world-owning cognition subject 负责认识与综合；当前 effect Owner 只负责正式共享 effect、写入与消费者终验
- Terra 只产候选；`worker_terminal` ≠ 认识采用 ≠ legacy `owner_adopted` effect state ≠ `effect_verified` ≠ `parent_complete`
- 不创建 resident pool / daemon / scheduler / 第二路由器
- Pause/Stop 立即停止范围内新派工与 mutation
- 不打印密钥；用本机已登录 Codex 认证
- `completion_claim_allowed=false`：pool 连通 ≠ 父任务完成

## 公开调用（必须 pwsh 7+）

### 0) Selection-only（只铸 receipt，不烧模型）

```powershell
$SelectionOnlyResult = & 'C:\Users\xx363\CodexLaunchers\Invoke-Codex-TerraWorkerPool.ps1' `
  -SelectionOnly -N 1 -Model 'gpt-5.6-terra' -Cwd $TaskCwd |
  ConvertFrom-Json -ErrorAction Stop

$SelectionReceipt = [string]$SelectionOnlyResult.selection_path
# schema: xinao.codex_terra_selection_only_result.v1
# model_invocation_count must be 0
```

### 1) 已选 Terra 后的普通有界劳动（能力族内默认；自选并绑 receipt）

```powershell
& 'C:\Users\xx363\CodexLaunchers\Invoke-Codex-TerraWorkerPool.ps1' `
  -N $N `
  -PromptFile $PromptFile `
  -Cwd $TaskCwd `
  -Model 'gpt-5.6-terra' `
  -ReasoningEffort medium `
  -Sandbox workspace-write `
  -MinResultChars 256 `
  -TimeoutSec 900
```

- 省略 `-SelectionPath`：launcher 自己写 selection receipt 再执行
- `$N` 由互补工包数、cognition synthesis 与 effect fan-in 成本共同决定，不为省 token 默认 N=1，除非 frontier 真是 singleton
- 多 lane 时同一 prompt 仅用于 intentional replicas；异构工包应不同 PromptFile（v1 可多次调用或 N 次不同 Prompt 分批）

### 2) 验收

读返回 JSON 与 `pool_summary_path`（**不要**把 mutable `latest.json` 当唯一身份）：

必须看到：

- `schema_version=xinao.codex_terra_public_dispatch_result.v1`
- `all_ok=true` 且 `acceptance_contract_ok=true`（全部 lane accepted 时）
- 每个 lane：`worker_status/outcome=accepted`、`effective_output_accepted=true`、`exit_code=0`、`result_text_chars >= MinResultChars`
- `completion_claim_allowed=false`、`candidate_only=true`

然后：

1. 读各 lane `result.txt` / `latest.json`
2. 当前 cognition consumer 按硬证据综合（不多数票）
3. 需要正式 shared effect 时由当前 effect Owner 写入；Terra 不写主权威

失败分型：

| 症状 | 处理 |
|------|------|
| `CODEX_TERRA_REQUIRES_PWSH7` | 用 pwsh7 调 public launcher |
| `CODEX_TERRA_PROMPT_REQUIRED` | 补 Prompt/PromptFile |
| `CODEX_TERRA_CWD_MISSING` | 显式存在的 Cwd |
| lane `timeout` | 升 TimeoutSec 或拆工包；保留 evidence |
| lane `incomplete`（chars 不足） | 加强 prompt 完成尺 / MinResultChars |
| exit≠0 | 读 lane err log；修输入封印后重派 |

## 与 Grok 普通工人对照（同构，不复刻实现）

| 能力 | Grok 普通 | Terra 普通 |
|------|-----------|------------|
| 公开 launcher | Invoke-Codex-GrokWorkerPool | Invoke-Codex-TerraWorkerPool |
| Skill | dispatch-grok-worker-pool | dispatch-terra-worker-pool |
| Selection receipt | 有 | 有（terra schema） |
| N lane 并行 | 有 | 有 |
| pool_summary + lane latest | 有 | 有 |
| candidate-only | 有 | 有 |
| 证据在 D: | grok_worker_pool | codex_terra_worker_pool |
| 后端 | grok headless | codex exec terra |
| 正式 package 批 | Grok 可按真实消费者需要选用 | **本 Skill v1 不做** |

## 额度

Terra 烧 **Codex 订阅额度池**（与 Sol/Luna 同池）。Grok 烧 Grok 池。  
按当前净收益选后端：外部额度、Codex 原生长上下文、工具适配、独立性、延迟和 fan-in
成本共同决定；Grok 额度宽裕本身不取得默认路线权。

## 禁止

- 直接调 core 脚本绕过 public launcher（测试除外）
- 把 inner_terra_explorer 子代理输出冒充本 WorkerPool（那是只读锥内 agent，另一路径）
- 用 Terra 结果宣称父完成或科学父状态已经改变
- 第二 Owner / resident pool

## 同构兄弟：Luna Max

- Launcher：`C:\Users\xx363\CodexLaunchers\Invoke-Codex-LunaWorkerPool.ps1`
- Skill：`dispatch-luna-worker-pool`
- 默认：`gpt-5.6-luna` + `model_reasoning_effort=max`（露娜最大模式）
- 证据：`D:\XINAO_RESEARCH_RUNTIME\state\codex_luna_worker_pool\`

## 调用合同

本 Skill 是 Terra 的能力入口；`amplify-supervisor-worker` 只在当前角色确实需要监督时协同使用。
旧 C 盘工人说明副本已退出活动架构，不得作为新窗口前置或恢复真源。
