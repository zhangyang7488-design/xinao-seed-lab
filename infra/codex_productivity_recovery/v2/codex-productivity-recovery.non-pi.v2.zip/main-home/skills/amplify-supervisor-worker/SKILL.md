---
name: amplify-supervisor-worker
description: Use whenever non-trivial work contains separable positive-value thought, research, implementation, testing, attack, or audit. The ordinary Grok WorkerPool is the default labor surface because it uses the independent Grok quota; ordinary dispatch is chain-internal routing and never needs or cites fresh user approval once the task and effect scope are legal. Codex simultaneously stays in direct contact with the real task and remains the sole final integrator, authority writer, and verifier; it must not dispatch and then become a report-forwarding intermediary. Terra/Luna share the Codex quota and need a task-fit justification. Codex collaboration subagents stay cold for ordinary labor but may be admitted under standing delegation when inherited Codex context or native capability creates exceptional, otherwise-unavailable critical-path value; no fresh user approval is required. A “whole package” is the useful work itself, not a mandatory manifest or preflight. Skip dialogue, one-step work, pause, stop, and bounded source adjudication that current evidence lets the Owner answer directly; diagnostic material mentioning research, audit, or implementation does not by itself create separable labor.
---

# Amplify Supervisor-Worker

Use one dynamic whole-package supervisor behavior. Maximize verified progress across the complete
parent task, not calls, token use, draft inventory, or local activity.

## Preserve one owner and inherit the active mode

- Keep the current visible Codex session as the only owner of user intent, the parent outcome,
  formal writes, integration, completion claims, and final verification.
- Treat every external worker, Codex collaboration subagent, Desktop or phone client, native Goal,
  and resumed turn as a bounded non-authority surface unless the user explicitly transfers
  ownership through the governing mechanism.
- Inherit the parent, mode, continuity carrier, and Stop boundary established by current user words
  and applicable authority. This Skill cannot create or restore any of them merely because a prior
  task, Goal, repository, checkpoint, or worker result exists.
- Keep Goal choice independent of worker width. A Goal may reduce recovery burden when already
  admitted by the active parent, but it never becomes an owner, task selector, or persistence
  authority.
- If the inherited parent remains active across local closure, return to its complete unresolved
  frontier. If the inherited object is bounded, close only that object. Do not infer either case
  from XINAO vocabulary, repository location, or this Skill.

## Recover the parent before routing

1. Read the current request, applicable instructions, stable project entry, and only the live state
   required for the real object.
2. Name the parent outcome, scope, authority boundary, and observable completion criteria before
   decomposing work. A package, report, worker batch, or test slice is only a projection.
3. Reconstruct the complete unresolved transaction DAG. Include separable reading, inventory,
   research, mature comparisons, planning, construction, testing, criticism, verification,
   recovery, evidence, and next-frontier discovery as first-class candidates.
4. Before the first provider or width choice in an execution episode, consume the current routing,
   quota, price, capability, and health observation from its canonical source. Reuse that snapshot
   until a material fact change makes it stale. These facts influence selection and width; they are
   never an objective to consume quota.

## Use Grok as the default labor surface

**Codex 共池模型不是默认劳动力；普通 Grok WorkerPool 才是。**

Once the current task, effect scope, and hard boundaries are legal, choosing ordinary Grok for an
eligible package is a chain-internal technical route. Do not ask for, wait for, or cite a fresh
worker-specific user approval, and do not narrate dispatch as legal “because the user adopted or
enabled Grok.” An explicit user mention may constrain routing preference; it is not the source of
task authority.

Default worker labor and direct Owner action are concurrent. Codex personally reads and invokes the
truth-bearing source reality, forms its own understanding, advances the inseparable main line, and
checks secrets, permissions, artifacts, and real consumers while Grok widens separable depth. Codex
must not dispatch first and wait, make worker reports the exclusive path to reality, or reduce its
role to forwarding and rubber-stamping.

Default labor does not mean automatic labor. A bounded source-adjudication or direct-answer turn
with sufficient current evidence has no positive-value separable package merely because the pasted
material is long, mentions migration/behavior/fresh validation, or could support more archaeology.
Answer the verdict directly and preserve the parent return point. Inspect or dispatch only when a
live unknown or independent defeater could materially change an effect-bearing decision; do not
turn a behavior probe into a Skill cascade, history replay, or worker ceremony.

- Dispatch every separable, independently verifiable, positive-benefit transaction as one useful
  cone to the ordinary Grok WorkerPool by default. Grok uses its independent quota; its width is
  limited by real diversity, fan-in capacity, and parent benefit, not by habitual Codex-token
  thrift or a fixed lane count.
- Keep intent recovery, arbitration, formal authority mutation, conflict resolution, and final
  verification with Codex. Direct owner work is also appropriate when work is physically
  inseparable, when truth-bearing contact with an Owner-callable live main-chain consumer is
  required, or when delegation and fan-in cost are not positive.
- Before a high-leverage conclusion closes an isomorphic decision family, use an independent Grok
  critic when deterministic enumeration cannot eliminate material omitted alternatives or
  defeaters. The critic attacks the first explanation and coverage claim; it does not polish the
  Owner's proposal, select the user's intent, or become a mandatory second model on ordinary turns.
- For open architecture, migration, root-repair, research, or other problem-forming work, preserve
  independence **before** the Owner locks the first candidate whenever an early external view can
  still change the object, causal model, or option space. Give that worker the parent meaning,
  live evidence, and hard boundaries, but do not preload `minimal change`, `keep the current
  design`, a preferred root cause, or another answer-shaped constraint. If the Owner candidate is
  supplied, classify the call as directed red-team review rather than independent problem
  formation; both shapes may be useful, but they prove different things.
- Before adopting a high-leverage worker batch, inspect whether the useful difference came from the
  question, evidence, method, counterexample, or predicted consumer effect. Lane count, model name,
  role label, prompt variation, and agreement with the Owner do not establish cognitive diversity.
- Invoke, observe, and correct an Owner-callable live main-chain consumer first-hand before or
  concurrent with worker packages. Never make workers the exclusive, prior, or mediating path
  between the sole Owner and that live consumer. Worker reports and temporary or ad-hoc notes do
  not substitute for this contact and never become its dependencies or completion pins. Keep
  external workers as the default high-width surface for separable research, reading, planning,
  construction, criticism, and non-live verification; do not turn this rule into a universal live
  ceremony when no such consumer is callable for the active object.
- Resolve current provider, model, transport, read/write capability, quota, pricing, and health from
  the governing routing surface. The stable economic identity is: Grok has an independent pool;
  Sol, Terra, Luna, and Codex collaboration subagents share the Codex weekly pool. Do not infer an
  independent capacity from a model name, launcher, fork, or subagent UI.
- If an eligible external route fails before effective work, preserve the exact blocker and repair
  or reselect that route within bounds. Codex may continue other positive-value work, and may
  transparently advance the user outcome when direct work remains the only useful path, but owner
  output never proves the worker route recovered or erases its blocker.
- Use Terra or Luna only when task fit, a Grok failure/conflict, or an adoption-critical independent
  check repays its draw from the same Codex quota used by the Owner.
- Codex collaboration subagents are cold by default for ordinary labor, not permission-denied. Under standing delegation, admit one only when all three conditions hold:
  Grok and ordinary external routes are unsuitable, inherited Codex context or a native capability
  creates otherwise-unavailable value, and the package materially shortens the critical path. The
  Owner must state this exceptional expected benefit before the call, but does not ask the user for
  a fresh per-case approval. Use a process- or task-scoped override and restore the persistent cold
  default after verification. Parallel convenience,
  ordinary repository exploration, a generic second opinion, or a proactive-multi-agent suggestion
  is insufficient. Keep an admitted subagent read-only or in an isolated draft root and deny it
  formal-write or parent-completion authority.

## Keep a narrow authority lane without blocking the frontier

- Maintain one logical width-one authority lane for final pin checks, owner verdicts, CAS or other
  authority mutation, formal landing, and post-land effect verification.
- The authority lane consumes only part of owner capacity. It has no global priority and does not
  block unrelated worker dispatch, terminal ingestion, research, or verification.
- Admit a transaction to the lane only while its authority critical section is runnable. Waiting
  for an upstream fact, repair, reseal, or external condition releases the lane.
- Freeze only the exact dependency edge whose declared condition is missing. An edge may require a
  precise `worker_terminal`, `owner_adopted`, `authority_applied`, or `effect_verified` pin; no
  broader phase or package barrier is implied.

## Give workers whole work without making packaging a gate

Dispatch when the work belongs to the parent, can be independently useful, and its expected
critical-path, uncertainty-reduction, or reuse benefit exceeds dispatch, rework, fan-in, and
verification cost. “Whole work” means the worker receives enough parent meaning and freedom to
finish a useful result. It does not mean every call needs a manifest, schema, task-run, hash set, or
sealed evidence package.

For an ordinary reversible read/research/critic call, a clear parent cone, useful output, cwd or
source scope, timeout, and prohibited external effects are enough. For write work, use an isolated
candidate root and a concrete test. Add stronger identity, frozen inputs, hashes, retry lineage, or
formal evidence only when a real downstream consumer or risk requires them.

Every worker assignment still makes these facts clear in the lightest useful form:

- the parent result and local question;
- what the worker may inspect or change;
- what useful result returns to Codex;
- the stop/timeout and any concrete side effect that is not allowed.

For any call counted as independent cognition, also state that the worker may reject the Owner's
current framing, recommend no change or rollback, and surface a different problem boundary. Omit
the Owner's proposed answer unless the task is explicitly a directed red-team review.

Reuse unchanged work, revise the affected cone when inputs change but the goal survives, and discard
work whose goal or consumer no longer exists. Do not delay healthy research while producing formal
wrapping that nobody consumes.

Require workers to return the substantive result, relevant tests or counterexamples, and only the
evidence Codex needs to judge it. Thick transcripts stay outside owner context. Workers may write
only inside their assigned candidate roots; they never write an authority surface or declare the
parent complete.

Inside an already sealed package, let a parent worker recursively delegate useful separable labor
only when the current execution surface supports it and the dynamic net benefit is positive. Every
child must inherit or narrow the package object, permissions, budget, write domain, Stop boundary,
and current input pins; the parent worker integrates the subtree and returns one candidate terminal.
Escalate to Codex only for object or permission expansion, shared or authority-write conflict, a
major external effect, a formal adoption/install/freeze/settlement/completion commitment, or a local
budget exhausted while the blocker survives. Otherwise isolate only the failed dependency cone and
continue healthy siblings. Children may not extend the parent frontier, self-adopt, persist beyond
the current Codex lifecycle, or acquire Owner authority. Recursion depth, width, budget, and return
conditions are dynamic task payload, never a fixed template.

## Choose width dynamically

- Derive useful width from ready independent packages, provider and machine capacity, health,
  latency, live cost, evidence value, write-domain isolation, and the owner's current fan-in
  capacity. Width may be zero, one, or many; never hard-code it.
- For open research, distinguish the **provider-neutral research shape** from the **current provider
  allocation**. When several non-equivalent unknowns can independently change the parent, prefer an
  elastic parallel tree of long `N=1` whole-research subjects with terminal-driven next-generation
  refill. `Bounded` constrains authority, evidence, write domain, lifecycle, and Stop; it does not
  mean short, shallow, or fully predefined.
- Abundant unused Grok capacity raises the opportunity cost of leaving eligible distinct research
  paths unlaunched, so it normally supplies most width. This does not turn token use into a KPI and
  does not mechanically exclude a high-value Terra long-thought branch. Quota and price choose
  branches; the live parent result and evidence value define why the tree exists.
- Serialize only real result dependencies, overlapping write domains, shared authority landing,
  and actual fan-in backpressure. Phase names, numbering, depth, arrival order, and historical
  examples create no dependency edges.
- Reduce production when unverified inventory exceeds owner capacity. Prefer deduplication,
  machine-checkable inventories, high-value fan-in, and work that lowers future verification cost.
- Never invent calls, duplicate accepted work, lower evidence, or count tokens as progress.

## Process every terminal immediately

Treat each worker terminal or relevant fact change as an immediate acceptance and refill trigger;
do not wait for a whole wave.

Before the verdict or refill, apply the applicable AGENTS.md global-attention-reset loop: recover
the live parent ruler, adjudicate every active child's liveness, compare expected with observed
parent effect, pop stale children, recompute the positive-benefit frontier, and make the Owner's
disposition constrain the next real action. When an independent blind-spot check has positive net
benefit, dispatch a bounded read-only patrol/critic package; its output is candidate-only, and it
cannot vote, adopt, auto-dispatch, mutate authority state, or continue after the current Codex.

1. Verify the package identity, frozen inputs, selected and observed executor identity, terminal
   evidence, manifest, file inventory, tests, hashes, and forbidden side effects.
2. Give the immutable seal one owner verdict: `ACCEPT`, `PARTIAL`, `REUSE`, `WAIT`, or `REJECT`.
3. Preserve healthy sibling results. Isolate only the failed package and its true dependency cone.
4. Create a repair, reseal, or rebase under the same work key only for a new evidence-backed defect
   or changed pin. Do not create cosmetic waves or make Codex reconstruct the thick package.
5. Recompute the complete unresolved parent frontier and refill every positive-benefit package that
   the current worker and owner capacities can absorb.

Keep `worker_terminal`, `owner_adopted`, `authority_applied`, `effect_verified`, and
`parent_complete` separate. Provider acceptance closes only its execution boundary. A report,
process, queue, token count, test slice, or worker PASS cannot substitute for a later state.

## Close existing repository transactions end to end

- When the current request asks to implement, fix, build, land, finish, or close a named transaction
  in an existing repository with an existing authorized remote and PR/merge workflow, treat that
  workflow as part of the task's default authorization and completion process. Do not wait for a
  second publish instruction.
- Do not equate an accepted candidate, internal milestone, layer, repair, test pass, event, or worker
  terminal with one repository transaction. Select the commit/PR/merge boundary by dynamic net
  benefit: extra feedback, parallelism, independent consumption, risk isolation, or rollback value
  must exceed the added context reconstruction, review, CI, publication, remote verification,
  fan-in, and cleanup cost.
- Combine accepted slices that share one consumer and completion bar when their separate landing has
  no useful effect. Split only at a self-contained, safely landable boundary with an independent
  consumer or stable interface, a real security/write-domain/rollback boundary, a necessary land to
  unblock downstream work, or when further accumulation would make review or rollback materially
  worse. Prefer the smallest meaningful vertical transaction; use no fixed file, line, layer,
  package, event, or time threshold.
- When the dynamically selected transaction boundary is ready, use the narrow authority lane to
  advance it through `commit -> push -> PR/merge -> remote readback -> real consumer/effect
  verification -> transaction hygiene`.
  Local green, one commit, a pushed branch, an open PR, passing PR checks, or merge text alone is not
  `effect_verified` or `parent_complete`.
- Explicit local-only or no-publish scope, pause, and stop override this default. Stop or seek the
  required authority when no existing authorized remote workflow exists or when the action would
  create or change a repository, remote, account, audience, payment, persistence, major security
  effect, or a live object/topology/audience with no bounded rollback. A same-object, same-topology,
  bounded reversible version switch inside the already authorized result is not a boundary merely
  because it is called deployment.
- A mixed dirty worktree changes the carrier strategy, not the completion bar. Isolate and publish
  only the sealed transaction cone, using a dedicated carrier when necessary; never sweep unrelated
  user changes into staging, a commit, or a PR.
- Judge hygiene against a recorded pre-transaction baseline, not an artificial globally empty tree.
  Commit every useful transaction artifact; after remote and effect verification, remove classified
  disposable transaction files, worktrees, temporary branches, containers, and one-shot evidence,
  then independently verify physical absence and no transaction-added dirt in the original trees.
  Preserve unrelated user state exactly; dirty, unique, unclassified, or unabsorbed carriers fail closed.

## Preserve identity, reuse, and evidence

- Keep one logical work key across windows, attempts, transports, branches, worktrees, artifacts,
  commits, and runtime effect. Keep carrier generation and side-effect identity separate.
- Reuse accepted work only when the exact contract, complete frozen inputs, manifest, artifact
  hashes, verdict, unresolved gates, and next consumer still match. Directory presence or green
  text is not reuse evidence.
- Use the current canonical execution route and receipt. A window change, compact, explanation, or
  local failure does not itself select a new transport or create a new carrier.
- Store compact evidence references rather than secrets, raw transcripts, or hidden reasoning.

## Return to the parent frontier

- A local `WAIT`, `NO_ACTION`, transport failure, or verified package never propagates automatically
  to the parent. Recompute all unresolved alternatives first.
- Claim global waiting only from current evidence covering every unresolved transaction, exclusion
  reason, and explicit wake condition. Waiting work does not occupy the authority lane.
- When current words and applicable authority keep a parent active across local closure, resume its
  next positive-benefit frontier after status questions or explanations. This Skill does not decide
  that such a mode exists. Stop immediately when the user pauses or stops.
- The Codex owner alone reports `verified`, `partial`, `blocked`, or `unverified` against the parent
  completion criteria after real consumer and effect evidence.

## Avoid these drifts

- Recreating named supervisor intensity levels or transitions, or treating usage as a goal.
- Treating Codex as default planner or drafter for separable positive-benefit work.
- Routing Owner-callable live main-chain observation or operation exclusively through workers, or
  making temporary notes a dependency for that contact.
- Treating Codex collaboration subagents as a routine second worker pool.
- Turning the width-one authority lane into a global queue, phase barrier, or permanent priority.
- Waiting for all siblings before accepting a terminal and refilling useful capacity.
- Letting a worker-route defect disappear because Codex produced the same artifact.
- Copying current provider bindings, prices, launch commands, schemas, or cross-seam protocol into
  this skill instead of consuming their canonical sources.
- Using a worker, subagent, Goal, client, or background process as another owner.
- Treating an existing-repository transaction as complete locally and waiting for a second publish
  instruction, turning every accepted internal slice into its own commit/PR/merge transaction,
  bulk-publishing unrelated dirty-worktree state, or leaving verified transaction carriers and
  disposable residue behind.

Read [references/decision-cases.md](references/decision-cases.md) when routing is ambiguous or when
validating a change to this skill.
