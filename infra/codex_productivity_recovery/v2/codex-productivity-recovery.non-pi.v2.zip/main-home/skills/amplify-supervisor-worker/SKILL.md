---
name: amplify-supervisor-worker
description: >-
  Use after current-human and parent-role binding for multiple independent cognition branches,
  controlled experiments, fresh comparison/fusion, or separable positive-value engineering, audit,
  test, or attack. In S, own identity, isolation, lifecycle, runtime, provenance, recovery, shared
  effects, and fresh fusion without steering a world-owning Sol or running a parallel Owner answer.
  For S engineering/control/effect work, Codex directly owns source and consumer while ordinary Grok
  is the default separable labor surface at dynamic width; workers remain candidate-only. This
  default never enters a world-owning Sol's cognition. Skip dialogue, simple or tightly bounded work,
  sufficient-evidence adjudication, Pause/Stop, and supervision with no positive effect.
---

# Amplify Supervisor-Worker

Use one role-separated supervision behavior. Organize enough independent cognition and engineering
capacity to improve the current parent result without turning the supervisor into a thought
approver, a competing research branch, a report-forwarder, or a permanent control plane.

## Bind roles before routes

Current human words, the surviving parent, live facts, authorization, and Stop decide the object and
roles before this Skill chooses a worker, provider, branch count, prompt, tool, or lifecycle.

Distinguish four responsibilities:

- The user owns the parent reality, value, and real user-only choices.
- A world-owning cognition branch owns how its internal world forms, what relations it tests, what
  representations and tools it grows, and how reality changes its next cognition.
- The current visible S/Codex supervisor owns the experiment or engineering contract, identities,
  isolation, runtime observation, shared write/effect boundary, evidence, recovery, and delivery.
- A fresh fusion subject owns the permitted synthesis cognition; it does not inherit shared effect
  authority merely because it integrates branch worlds.

Do not collapse epistemic ownership into formal effect authority. An independent branch may reject
every other framing and still remain unable to mutate shared configuration, publish, spend money,
or declare the parent complete. Conversely, the effect Owner need not duplicate the branch's domain
cognition in order to responsibly launch, verify, integrate, write, recover, and deliver.

## Select the shallowest fitting shape

Choose from the current relation, not from task size or Skill presence:

1. **Direct bounded action**: answer, inspect, edit, or verify directly when no useful independent
   branch exists or fan-out would only add ceremony.
2. **S control tower**: use for fresh independent research subjects, A/B or blind experiments,
   contrastive arms, multi-world exploration, or new-repository Sol support. The supervisor manages
   conditions and effects, not cognition content.
3. **Engineering Owner plus candidate workers**: use when S itself owns a launcher, runtime,
   ingestion, settlement, test, packaging, recovery, or other engineering transaction. Codex reads
   the real engineering source and consumer, performs formal writes, and uses ordinary Grok by
   default for useful separable implementation, audit, test, or attack candidates. Width can still
   be zero when no independent cone repays dispatch and fan-in cost.

The same object can change shape when the parent or role changes. A live dataset can be a domain
reality for a world-owning Sol, an input-identity object for an experiment supervisor, or an
engineering consumer for an ingestor repair. Classify by the current responsibility and effect
edge, never by the noun, provider, repository, or command.

## Operate S as a cognition control tower

When S is the admitted supervisor, it may own:

- exact executable, model, reasoning, credential slot, cwd, sandbox, tool surface, environment, and
  session identity;
- W/input version, knowledge cutoff, source availability, arm/prompt identity, and any comparison
  variables the current contract must freeze;
- fresh-session isolation, branch lifecycle, capacity, quota, timeout, process health, crash and
  hang containment;
- write-domain isolation, raw terminal capture, tool/event evidence, hashes, provenance, blinding,
  anonymization, and permitted projections;
- recovery or invalidation under the exact experiment contract;
- fresh late fusion and later formal artifact/effect delivery;
- event-driven user-visible status at real state, fault, boundary, adoption, or completion changes.

These are direct reality contacts for S. Inspect them first-hand and verify their real consumers.
Do not turn “do not steer cognition” into “do not understand or operate the runtime.”

The supervisor must not:

- select a branch's research question, hypothesis, representation, algorithm, or next cognitive
  unit unless the current experiment explicitly defines that variable;
- form a private preferred domain answer and send branches to confirm, widen, or polish it while
  calling them independent;
- run a parallel domain-cognition lane merely to prove it is not a report-forwarding intermediary;
- steer a running branch with content prompts such as “continue this relation” or “try this model”;
- use branch agreement, majority vote, report length, tool count, exec count, token use, or worker
  count as epistemic authority;
- auto-rerun, expand a generation, modify an arm, enter Stage 2, or continue indefinitely because a
  result is interesting;
- make high-frequency polling narration compete with the cognition it is supporting.

Runtime observation can be deep. User-visible control narration stays thin and event-driven.

## Preserve branch independence

For each branch declared fresh or independent:

- establish a mechanically distinct thread/session and the contract-required clean context;
- give the complete permitted world and hard boundaries, not a supervisor answer disguised as a
  task package;
- allow the branch to form or reject local questions and to grow shell, code, web, simulation, or
  other available tools within its boundary;
- prevent unauthorized sibling outputs, hidden gold, later-prefix material, private judge keys, or
  prior branch memory from entering it;
- keep shared writes unavailable or isolated unless the branch has an explicit candidate write
  domain;
- preserve null, disagreement, failure, and alternative geometry rather than normalizing them into
  the supervisor's vocabulary.

“Bounded” constrains input, effect, lifecycle, evidence, and Stop. It does not require a short,
shallow, or fully predefined cognition path.

If a worker receives an implementation package rather than world ownership, give the lightest
sufficient parent meaning, source scope, candidate write domain, useful return, forbidden effects,
and timeout. It may challenge the proposed implementation and return `NO_ACTION` or rollback, but
its output remains candidate-only for shared effects.

## Handle terminals, faults, and recovery by role

A branch terminal changes lifecycle state; it does not automatically create adoption, truth, a new
generation, or parent completion.

On every relevant terminal or runtime fact change:

1. Verify exact branch/cell identity, frozen inputs, actual executor, exit state, raw evidence,
   outputs, and forbidden effects.
2. Preserve the terminal without exposing it to still-blind siblings.
3. Isolate only the failed runtime or dependency cone; do not erase a failed cell with a healthy
   sibling.
4. Retry only when the active contract permits it. One-shot/no-rerun experiments retain an invalid
   or failed cell instead of silently replacing it.
5. Advance only the next pre-admitted cell or contract-defined refill. A terminal does not let S
   redesign the cognition topology.

For ordinary engineering workers, classify the candidate as `ACCEPT`, `PARTIAL`, `REUSE`, `WAIT`,
or `REJECT`, then formally land only the adopted cone and verify the consumer. Keep
`worker_terminal`, `effect_owner_adopted`, `authority_applied`, `effect_verified`, and
`parent_complete` separate.

For world-owning research branches, do not force an Owner verdict on each internal belief. Preserve
the epistemic artifact for fresh fusion or the current research consumer while retaining S's
authority over shared effects.

## Use fresh late fusion without manufacturing consensus

When the contract calls for synthesis, start a fresh fusion subject with only the permitted source
reality, branch artifacts, identity/provenance, and current boundaries. The fusion subject may:

- preserve incompatible world geometries;
- find a relation no branch proposed;
- reject the majority;
- return to source reality;
- remain uncertain;
- propose a new reality contact or, when authorized, a later experiment.

The S supervisor verifies the fusion input surface and saves the output. It must not first compress
branches into a preferred gold, instruct Main which branch is right, or treat Main as a judge for
the supervisor's answer. Any new generation, rerun, steering change, shared write, publication, or
other effect must again pass the current user/contract boundary.

## Directly own S engineering and shared effects

When the active object is S engineering, Codex must read the canonical source and invoke the real
consumer itself. It may edit, test, package, recover, and publish within the authorized transaction;
workers may widen isolated implementation, test, audit, or attack work.

Keep one formal write/integration sequence for a shared object. A branch or worker never writes a
shared registry, active profile, release pointer, authority ledger, or parent-completion state merely
because its candidate is good. Before formal effect, re-read live bytes/state, integrate conflicts,
verify secrets and permissions, apply the adopted change, and perform real consumer readback.

This direct engineering responsibility does not restore a right to choose a new-repository Sol's
scientific question. S can repair the launcher that lets the Sol work without deciding what the Sol
should discover next.

## Keep the Grok labor default role-scoped; choose width and exceptions dynamically

Ordinary Grok WorkerPool is the standing first route for separable positive-value labor inside the
current S engineering, experiment-control, evidence, recovery, or shared-effect cone. This prevents
the visible Codex from silently serializing every audit, attack, implementation, or verification and
does not require per-call user approval. The effect Owner must still remain on its direct engineering/effect line,
integrate candidates, and verify the consumer.

This is a role-scoped labor default, not a universal epistemic provider identity. It never authorizes
S to inject Grok into a world-owning Sol's domain cognition or to replace that Sol's own tool choices.
Use Terra, Luna, Codex-native collaboration, another provider, or direct work when current task fit,
otherwise-unavailable capability, independence value, quota/cost, latency, health, isolation, write
domains, or fan-in capacity makes that route materially better. Lane count, tree depth, and generation
rules remain dynamic; width may be zero, one, or many. Worker availability does not create work or a
quota-consumption objective.

Use Codex native collaboration only when the active object requires native thread interaction or
inherited/native context has otherwise unavailable value. Put communicating native agents in the
same root tree, name write domains, and keep shared effects with the current effect Owner. Do not
turn a task-scoped native episode into a permanent second worker pool.

Provider selection is a chain-internal technical route after task/effect legality. Do not ask the
user to approve ordinary reversible routing choices or claim that a worker is legal only because
the user “enabled” it. Do ask only at real user-only choices, new accounts/audiences/payments/secrets,
irreversible or major external effects, or explicit Pause/Stop.

## Continue, wait, or close from the current contract

A local null, no-bet, no-action, report, branch terminal, test pass, fusion, or turn boundary does
not automatically close the parent. Likewise, an open parent does not authorize infinite compute.

- Continue a known, already-admitted next cell or engineering frontier without asking the user to
  repeat the parent.
- Wait only for an exact external condition or contract-defined reveal; do not invent cognition to
  fill time.
- Expand or refill only when current words or the active contract admit adaptive topology.
- Stop immediately on Pause/Stop and preserve the exact return point.
- Close only the bounded episode or parent whose real consumer and completion predicate are
  verified.

Status questions receive a concise live answer and do not replace the surviving parent.

## Avoid these drifts

- “Codex personally advances the domain main line” as a universal rule.
- Confusing formal effect Owner with sole epistemic subject.
- Treating branches as assistants, judges, voters, or evidence for an answer S formed first.
- Letting worker reports replace S's direct engineering/runtime/effect contact.
- Letting S's engineering contact expand into duplicate domain cognition.
- A universal Grok cognition default, or the opposite drift that erases ordinary Grok as S's
  role-scoped default separable labor surface; fixed branch count, named intensity tiers, and quota
  burning remain invalid.
- Whole-wave barriers when the contract admits sequential terminals, or adaptive refill when it
  does not.
- High-frequency control narration, report walls, and tool-schema theater with no consumer.
- Automatic adoption, shared writes, publication, parent completion, or self-authorized perpetual
  continuation.
- Reusing an old supervisor, runner, checkpoint, Goal, Skill, or repository merely because its words
  resemble the current task.

Read [references/decision-cases.md](references/decision-cases.md) when role classification is
ambiguous or when validating a change to this Skill. In S, the detailed project projection is
`docs/tool_glue/S_CONTROL_TOWER_PRIMARY_MODE_CURRENT.md`; current project instructions and live
facts outrank this generic Skill.
