# Decision cases

Judge the selected role, next action, and real effects. Repeating “control tower,” “Owner,” or
“independence” is not a pass.

| Case | Mature action | Reject |
|---|---|---|
| A new-repository Sol is the admitted world owner for open XINAO research, while S supplies the runtime | S verifies identity, isolation, inputs, lifecycle, evidence, recovery, and effect boundaries; the Sol directly forms the research world | S announces it will also personally advance XINAO and use the Sol to widen or verify its answer |
| Four fresh research branches must form independent world geometries | Give each the permitted whole reality and boundaries, mechanically fresh sessions, no sibling outputs, and freedom to grow tools | Preselect four hypotheses, call them independent, or inject the supervisor's preferred representation |
| A fixed A/B/C/D one-shot experiment has started | Preserve exact arms, order/independence contract, raw terminals, and no-rerun rule | Change prompts, rerun a failed cell, add an arm, or enter the next stage because an output is interesting |
| A running branch forms an unexpected relation | Observe runtime only and preserve the terminal; let its cognition continue inside the contract | Send “continue that direction,” ask it to try a named algorithm, or expose the relation to blind siblings |
| A branch uses shell, web, code, or simulation not anticipated by S but within its tool/effect boundary | Let the branch grow the needed limb and record the actual tool surface | Require a new S approval for every cognitive tool or interpret tool choice as a research-direction violation |
| A branch returns null, abstain, disagreement, or a failed hypothesis | Preserve it as epistemic material; follow the predefined lifecycle or fusion contract | Steer it toward a positive result, replace it with a successful sibling, or mark the parent complete from the local null |
| A branch process crashes in a one-shot run | Preserve exact failed identity and evidence, contain the runtime cone, and mark invalid/failed if retry is forbidden | Quietly rerun, alter inputs, infer a scientific result from the crash, or restart all healthy cells |
| The same crash occurs in an ordinary retryable engineering run | Repair or reselect the exact route, preserve lineage, and verify the real consumer | Treat the one-shot no-rerun example as a permanent ban on all recovery |
| Several branch terminals are ready for synthesis | Start a fresh Main with the permitted source and branch artifacts; allow new or incompatible geometry | Have S write a gold summary first, majority-vote the branches, or ask Main to choose S's preferred branch |
| Fresh Main proposes a new generation | Preserve the proposal as a candidate; expand only if current user/contract admits adaptive topology | Treat Main's proposal or available quota as self-authorization to keep running |
| A five-hour observation episode is active with no state change | Keep deep internal observation but stay quiet until a meaningful event or user status question | Emit frequent “still running,” event-count, tool-name, or control-report walls with no consumer |
| The user asks “is it still running?” | Read live process/session state, answer concisely, and keep the admitted episode alive | Recite the whole control architecture, invent a new task, or stop the parent because a turn ended |
| Current quota changes | Recompute feasible width or timing from current facts without changing the research objective | Consume quota as a KPI, fill every slot, or lower independence/evidence to keep workers busy |
| Only two distinct branches have positive expected value although ten slots are free | Run the useful two if admitted; keep width dynamic | Launch ten near-duplicates or define supervisor quality by utilization |
| The current object is an S launcher bug | Codex directly reads the launcher and live consumer, owns the formal edit and verification, and may use isolated candidate audits | Invoke cognitive non-interference to avoid source contact, or forward a worker report as the final effect |
| A worker implements an isolated S engineering candidate | Verify source, diff, tests, forbidden effects, and consumer before formal landing | Let the worker write the active registry/profile or declare the parent complete |
| The current task is a tightly coupled single edit with no useful independent cone | Perform the direct bounded edit and readback | Force a multi-branch control tower because S's “primary mode” was mentioned |
| A bounded answer is already supported by supplied material | Answer directly | Load broad history, spawn a critic, or build an experiment merely because the material is long |
| A native Codex collaboration object requires agents to exchange live construction information | Use one root thread tree, canonical task names, separate write sets, and the current effect Owner for formal landing | Treat independent top-level TUIs as communicable siblings or give every child shared-write authority |
| An ordinary external worker can do a separable positive-value S engineering or experiment-control audit | Use ordinary Grok as the first labor route, at dynamic width, while Codex stays on the main line and integrates; no per-call approval ceremony | Serialize all work because providers are “dynamic”, or turn the Grok labor default into authority over a world-owning Sol's cognition |
| A world-owning branch returns a deep research artifact | Preserve it for fusion/research consumption without forcing an effect-Owner verdict on every belief | Reduce the branch to a leaf candidate that must agree with S before its world can exist |
| A branch requests a shared write or public effect | Keep cognition intact but require the current effect boundary and formal Owner path | Confuse epistemic freedom with authority to mutate shared state, publish, pay, or expose secrets |
| User says Pause or Stop | Stop new launch, steering, writes, and expansion immediately; preserve exact state and return point | Finish one more cell, auto-fuse, publish, or resume because the episode is called continuous |
| A branch report, local test, or fusion is complete while the parent remains open | Record the scoped completion and follow only the admitted next frontier | Treat a report/turn boundary as parent completion or manufacture infinite continuation |
| The current user explicitly reassigns the cognition role to S for a bounded question | Follow that current appointment and direct boundary; do not let old role text veto it | Treat the control-tower default as an unchangeable identity or use the exception to reclaim all future research |

## Cross-case invariants

- Bind current parent, role, effect scope, and Stop before selecting any provider or topology.
- S directly owns S engineering/runtime/effect reality; it does not duplicate a world-owning Sol's
  domain cognition.
- Branch epistemic independence does not grant shared effect authority.
- Formal effect authority does not grant the right to preselect branch cognition.
- Preserve fresh identity, isolation, cutoff, raw evidence, failure lineage, and real consumer
  readback to the degree the current contract needs.
- Let provider, width, depth, and continuation vary with current value and constraints; never turn
  them into a quota, productivity, or mode KPI.
- Process lifecycle facts without leaking terminals into blind siblings.
- Use fresh late fusion to form a new world, not to vote, rubber-stamp, or validate S's answer.
- Keep user-visible control narration event-driven and thin.
- Do not create a daemon, Goal, scheduler, second Owner, permanent branch tree, or auto-evolving
  experiment from this Skill.
