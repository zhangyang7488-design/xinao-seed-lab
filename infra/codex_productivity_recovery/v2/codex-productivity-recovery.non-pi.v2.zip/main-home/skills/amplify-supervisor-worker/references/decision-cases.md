# Decision cases

Use these as behavioral probes. Judge actions and evidence, not whether an agent repeats the right
vocabulary.

| Case | Mature action | Reject |
|---|---|---|
| An Owner-callable live main-chain consumer and separable frozen-material packages are both ready | Owner invokes and observes the live consumer first-hand before or concurrent with dispatch; workers widen the frozen research, construction, and criticism packages | Wait for worker reports before touching the live consumer, let reports substitute for live contact, or serialize useful worker width behind the Owner call |
| The task and effect scope are already legal, useful separable Grok packages exist, and no current sentence says “adopt/enable workers” | Codex directly advances the main line and dispatches the eligible packages as ordinary chain-internal routing | Ask or wait for worker-specific permission, or say dispatch is legal because the user explicitly adopted or enabled Grok |
| A packaging or repair task needs first-hand source reading, secret-boundary checks, artifact/ZIP verification, plus independent omission attacks | Codex personally reads, builds, checks, and decides while Grok performs the separable audits in parallel | Give all reality contact to workers, wait for their reports, and leave Codex as a forwarding or rubber-stamping intermediary |
| One compact authority fix and one separable audit are ready | Send the audit to the current external-worker surface; let the owner perform only the tight authority fix when delegation is not beneficial | Treat workers as opt-in, delegate with negative benefit, or make Codex do both by habit |
| No Owner-callable live main-chain consumer belongs to the active object, but separable packages are ready | Dispatch every positive-benefit package normally and let the Owner retain only its actual authority or inseparable slice | Invent a universal live-first ceremony or use the new rule to make Codex the default labor surface |
| The same tool call is a truth-bearing live consumer in one parent and frozen-artifact analysis in another | Classify by the active parent, object, consumer, and effect: Owner contacts the former first-hand; workers may perform the latter | Classify by command name, provider, or a permanent owner/worker tool roster |
| A callable action would create an unauthorized major external effect rather than observe or operate the authorized main-chain object | Preserve the authority boundary and dispatch only in-scope side work | Treat "Owner-callable" as new authorization or force execution merely to satisfy a live-first slogan |
| Independent reading, planning, construction, criticism, and later-depth packages exist across the unresolved parent | Evaluate all as first-class whole-package candidates and dispatch every positive-benefit ready or pin-bound package within real worker and owner capacity | Look only one step ahead, wait for a stage or number, or dismiss cognitive labor as non-dispatchable |
| Four packages are useful but a fifth would exceed owner fan-in capacity | Run the useful four and leave the fifth pending until a terminal or fact change frees capacity | Fill every slot, use fixed width, or serialize all work because width is uncertain |
| One package is in final CAS while unrelated packages are ready | Keep the CAS in the width-one authority lane and continue unrelated dispatch and terminal ingestion | Give the authority lane global priority or freeze the whole frontier |
| An authority transaction is waiting for a changed upstream pin | Release the authority lane, keep the exact edge conditionally ready, and continue unrelated work | Let waiting monopolize the lane or block a broader stage |
| A provider terminal exists but a dependent edge requires an owner-adopted artifact pin | Hold only that edge until the exact verdict and artifact hash arrive; continue unrelated packages | Let provider acceptance release an owner or effect dependency |
| A worker terminal arrives while siblings still run and a replacement package is ready | Verify and classify that terminal immediately, then refill useful capacity without waiting for siblings | Whole-wave fan-in, idle gaps, or broad owner replanning before the terminal verdict |
| A sealed package returns with no new defect and unchanged pins | Give one owner verdict and reuse or reject deterministically | Cosmetic repair waves, a new work key, or owner reconstruction of the thick package |
| A worker report says PASS but identity, manifest, output, or filesystem evidence mismatches | Give zero acceptance credit, preserve healthy siblings, and issue a bounded same-key repair or reseal only for the evidenced defect | Accept green text or tokens, rerun healthy work, or have Codex silently rewrite the package |
| The selected external route fails before model or tool work starts | Preserve the route blocker, reselect or repair within bounds, and continue unaffected work; if owner work advances the user outcome, keep it separate from route recovery | Claim the worker ran, erase the blocker with owner output, or freeze the parent |
| The object under test is the Codex native collaboration surface, or otherwise-unavailable inherited/native evidence would materially shorten the critical path | Under standing delegation, state the task-fit benefit, use one process- or task-scoped read-only/isolated Codex subagent without asking for fresh user approval, verify its output as a candidate, then return to the persistent cold default | Refuse until the user re-approves, treat subagents as routine capacity, leave `multi_agent=true`, or grant formal-write authority |
| A normal separable package could go to either an external worker or a Codex subagent | Use the current admitted external-worker surface, normally Grok | Prefer a Codex subagent for convenience, spare Codex quota, generic second opinion, proactive multi-agent advice, or inherited context with no otherwise-unavailable benefit |
| A bounded native exception has finished and the next package is ordinary separable work | Read back persistent `multi_agent=false`, route the next package to Grok, and retain only the candidate evidence from the exception | Keep the native surface warm for convenience, inherit the exception across tasks, or turn one successful canary into a second default worker pool |
| Current quota, price, or health changes materially | Refresh the canonical routing observation and let it affect provider choice or useful width | Turn quota consumption into an objective, encode a fixed time table, or lower evidence |
| No positive-benefit separable work exists | Let the owner perform only the necessary inseparable or authority slice and recompute when facts change | Invent worker work, treat width one as failure, or make owner-default labor permanent |
| The user pastes a complete diagnosis and asks whether it is right; current evidence already separates supported claims from overreaching prescriptions | The Owner adjudicates the material directly, keeps it candidate-only, and returns to the surviving parent without dispatch | Reload broad history or multiple overlapping Skills, dispatch a critic because the text says behavior/migration/fresh, or implement the pasted architecture before adoption |
| One endpoint fails while sibling worker routes remain healthy | Isolate the failed route and dependency cone, preserve healthy results, and continue other frontiers | Rerun the whole batch or declare all workers unavailable |
| Draft inventory exceeds owner verification capacity | Reduce new production and prioritize deduplication, machine checks, high-value fan-in, or work that lowers future verification cost | Grow unverified inventory or stop the entire parent |
| A local package is verified while the parent remains open | Record the scoped result and recompute the complete parent frontier | Declare parent completion from the local report |
| The user asks to implement or finish a named transaction in an existing repository with an existing authorized remote and PR workflow | After acceptance, continue the exact sealed cone through commit, push, PR/merge, remote readback, and real-consumer verification without asking for a second publish instruction | Stop at local green, commit, pushed branch, open PR, or merge text and ask whether to publish |
| Several accepted internal slices share one consumer and have no useful effect when landed separately | Keep internal checkpoints and evidence, combine them into the smallest meaningful vertical repository transaction, and pay the commit/PR/merge hygiene cost once | Open one transaction per layer, adapter, schema, test, repair, worker terminal, or event because each is independently nameable |
| A candidate can be consumed independently, must land to unlock downstream work, or accumulating more would materially worsen review or rollback risk | Close that self-contained repository transaction now and continue downstream under the same parent | Batch it merely to reduce PR count, or apply a fixed minimum package size |
| The existing repository worktree mixes the named transaction with unrelated dirty or untracked work | Isolate the exact transaction cone or use a dedicated carrier, publish only that cone, and preserve unrelated state | Use `git add -A`, bind unrelated work to the transaction, or lower the remote completion bar because the tree is mixed |
| Remote main and the real consumer verify, while transaction-scoped worktrees, branches, containers, generated residue, or original-tree deltas remain | Commit useful scoped artifacts, classify and retire only disposable transaction carriers, compare every tree with its recorded baseline, and verify physical absence | Leave a carrier forest, call local green clean, or delete unrelated user state to manufacture a globally empty tree |
| The user asks a status question while current words and applicable authority keep the parent active | Answer concisely, preserve the breakpoint, and resume that parent frontier | Let this Skill infer a mode from repository or history, replace the parent, or restart an old investigation |
| The user says pause or stop | Cancel new dispatch and mutation immediately, preserve existing results, and report the stop boundary | Finish one last package, publish, or auto-resume |
| A completed work key reappears across windows | Reuse only when the exact contract, frozen inputs, manifest, artifact hashes, current verdict, unresolved gates, and next consumer still match | Re-dispatch under a cosmetic ID or trust directory presence, PASS text, or token use |

## Cross-case invariants

- Use one dynamic whole-package supervisor behavior; do not create named intensity levels or
  transitions.
- Maximize verified parent progress, not raw calls, tokens, draft count, or visible activity.
- Make the current external-worker surface the default labor destination for separable,
  independently verifiable, positive-benefit packages.
- Treat ordinary Grok selection as chain-internal routing after task/effect legality; never ask for or
  cite fresh worker-specific user approval.
- Keep truth-bearing contact with an Owner-callable live main-chain consumer non-mediated while
  workers widen separable labor before or concurrently; never turn this into a universal gate.
- Keep Codex singular as parent owner, authority writer, integrator, and final verifier.
- Keep the width-one authority lane narrow, runnable-only, and non-blocking to unrelated frontiers.
- Process terminals individually and refill useful capacity without a whole-wave barrier.
- Keep Codex collaboration subagents persistently cold for ordinary labor. Standing delegation admits
  them without fresh user approval only when external workers are non-isomorphic or unsuitable,
  inherited/native value is otherwise unavailable, and critical-path reduction is material; use a
  process- or task-scoped override and return to `multi_agent=false` after verification.
- Let live task fit, health, latency, price, quota, load, and fan-in affect routing and width through
  their canonical sources; never turn usage into an objective or copy bindings here.
- Keep package, batch, parent, carrier, route, and authority/effect identities separate.
- Select commit/PR/merge granularity by dynamic net benefit; candidate and milestone boundaries do
  not automatically become repository transactions.
- Preserve local blockers and healthy sibling evidence; a local failure never defines the parent.
