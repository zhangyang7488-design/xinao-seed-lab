---
name: dispatch-grok-worker-pool
description: >-
  Dispatch real Grok workers through the ordinary Windows WorkerPool for an
  already-selected bounded task: independent thought, research, search, diagnosis,
  code, experiments, attacks, implementation, or verification. A worker may form or
  reframe a local question inside its inherited cone and may carry a long complete
  research behavior rather than a short predefined package. Use abundant independent
  Grok capacity when task benefit exceeds dispatch and fan-in cost. The launcher and
  receipts prove execution only; they do not select a scientific parent, enable a mode,
  restore history, adopt results, or declare completion. Do not load or dispatch this Skill
  for bounded source adjudication when current evidence is already sufficient for a verdict.
  Codex remains the sole Owner.
---

# Dispatch Grok Worker Pool

Use the ordinary public Windows launcher as a generic candidate-execution surface. Start only after
the caller has selected a positive-value task. Do not let this Skill, the launcher, a receipt, quota
state, or a worker choose the user's parent result or a scientific route.

## Bind the execution cone

Before dispatch, bind:

- the parent result and user burden the selected work serves;
- the local subject, real object, and means-versus-endpoint distinction;
- the exact question or the bounded freedom to form one;
- known and unknown state, evidence cutoff, and allowed inputs;
- real consumer and observable acceptance evidence;
- candidate-only authority, read/write domains, external effects, budget, and Stop;
- a stable episode or correlation identity;
- how the result may change Codex's next action.

The zero beat and scientific selection belong to the caller. WorkerPool only receives their bounded
output. Current user words and live facts override any remembered task, checkpoint, or prior receipt.

## Choose the worker shape

Use one of these shapes deliberately:

- **Directed labor:** Grok implements, searches, recomputes, tests, or attacks a selected object.
- **Independent cognition:** Grok may choose or reframe a local question, expose blind spots, search
  adjacent mature fields, and propose a different path.
- **Bounded whole research:** Grok may inspect allowed evidence, select a local question, search,
  build, experiment, interpret, attack, learn, and return one candidate terminal or honest
  `NO_ACTION`.

For independent or whole research, transmit parent meaning and hard boundaries without an answer
menu. `Bounded` limits object, evidence, authority, write domain, budget, lifecycle, and Stop; it does
not mean short, shallow, or fully predefined.

Independence is also a timing and prompt-provenance claim. When a worker is meant to help form a
high-leverage architecture, migration, root repair, research question, or general closure claim,
dispatch it before the Owner freezes the first answer when practical. Do not seed `minimal delta`,
`preserve the current approach`, a preferred cause, or a desired verdict. Explicitly allow the
worker to reject the framing, recommend rollback/removal/no-action, and identify a different live
object or consumer inside the inherited cone. A worker shown the Owner proposal is a directed
critic; report it that way and do not count it as independent candidate generation.

Use several concurrent differentiated `N=1` calls for genuinely different research paths. Use
`N>1` with one prompt only for intentional replicas or same-task probes. Provider, prompt, model,
algorithm, and file-name differences do not by themselves establish epistemic difference; Codex
judges that before and after execution.

## Prepare a direct dispatch

The ordinary direct path is the default, including long research subjects. Prepare:

- an exact prompt or prompt file;
- an explicit existing task/source `Cwd`;
- the current authenticated model identity;
- a finite timeout and `-MaxTurns auto` unless evidence supports another bound;
- a stable `-DispatchEpisodeId` or equivalent task-run identity;
- task-specific result markers or a compatible JSON schema when machine structure is genuinely
  consumed;
- one exact candidate output root for any writes.

Prompt requirements should state:

- inherited parent effect and local research cone;
- evidence and write boundaries;
- degrees of freedom to reason, reframe, search, code, experiment, and self-criticize;
- concrete return obligations: chosen object, actions actually taken, real evidence, disconfirmers,
  unresolved items, local disposition, and expected parent effect;
- `candidate-only`, `completion_claim_allowed=false`, and the current Stop.

When independence matters, the Owner must be able to answer from the saved prompt and terminal:
what conclusion-shaping assumptions were withheld, what alternative or defeater the worker was free
to form, and whether the result changed the candidate space. Agreement, worker count, token use, or
an execution receipt alone is not an epistemic result.

Do not add schemas merely to make open research look structured. Do not require a long chat report
when code, experiment artifacts, or consumer evidence carry the substance.

## Invoke the canonical launcher

Run from PowerShell 7 or newer. Invoke only:

```powershell
& 'C:\Users\xx363\CodexLaunchers\Invoke-Codex-GrokWorkerPool.ps1' `
  -N 1 `
  -PromptFile $PromptFile `
  -Cwd $TaskCwd `
  -Model $SelectedModel `
  -MaxTurns auto `
  -TimeoutSec $TimeoutSec `
  -DispatchEpisodeId $EpisodeId `
  -MinResultChars 256 `
  -RequiredResultMarkers $RequiredMarkers
```

Let the public launcher own dispatch and pool identities, provider selection, selection receipt,
authentication/catalog refresh, and the final `pool_summary.json`. Do not hand-author identities,
reuse a mutable `latest` pointer as evidence, call an inner bridge directly, or build a second
scheduler.

For read-only work, use a disposable host Git worktree at the exact source HEAD; the public
common-contract path creates and removes one automatically and rejects a dirty read-only result.
For ordinary mode, the caller creates the disposable worktree before dispatch. For writes, create
one isolated candidate root, set it as the authorized output domain, and keep source materials
hash-bound or read-only. Workers never write formal authority surfaces.

Docker, Docker Compose, and Docker containers are forbidden as the default local isolation route.
Their presence, convenience, an old container receipt, or a stopped daemon never authorizes startup.
Only a named exceptional high-value need with no equally effective host alternative may use the
public launcher's explicit `-AllowExceptionalDocker -DockerJustification <reason>` branch; state the
reason and exit condition before invocation, and verify Docker is stopped afterward.

Package, common-contract, retry, or durable modes are optional engineering shapes. Use one only when
a real downstream consumer requires sealed reusable provenance, typed dependency accounting,
idempotent retry, or durability strongly enough to repay its preparation and fan-in cost. Long work,
XINAO vocabulary, scientific content, several questions, or abundant quota do not select those
modes. Read the public launcher's current help and the active generic engineering contract before
using an optional mode; do not copy a historical package recipe.

## Handle recursion without inventing a controller

The public launcher does not prove that an individual worker has a child-dispatch tool. Permit
worker-internal recursion only when the observed surface supports it and the cone explicitly grants
it. Child object, evidence, authority, write domain, budget, lifecycle, and Stop may only narrow.

Otherwise Codex supplies recursion between generations: ingest each useful terminal immediately,
verify and deduplicate it, disposition it, then launch the next narrower or reframed branch. Do not
wait for unrelated branches before absorbing a plan-changing result. The WorkerPool is a one-shot
execution surface, not a daemon or autonomous supervisor.

## Verify the real execution

Read the immutable selection receipt and exact `pool_summary_path`, then the referenced lane output
and artifacts. For a fresh successful lane verify at least:

- expected pool identity and lane count;
- `all_ok=true`, `acceptance_contract_ok=true`, exit code zero, and accepted worker status;
- requested and observed model identity;
- positive usage accounting and a normal terminal reason;
- task-specific result markers or schema validity;
- `completion_claim_allowed=false`;
- route metadata identifies explicit bounded candidate execution, external task selection, and no
  implicit resume;
- for writes, exact artifact inventory, hashes, tests, and absence of writes outside the candidate
  root.

A green pool summary proves transport and bounded execution, not scientific value, Owner adoption,
consumer effect, or parent completion. Codex must inspect substantive evidence and make one explicit
disposition.

## Treat repeats idempotently

Identify exact execution repeats by contract, inputs, cutoff, consumer, intended effect, and current
generation. Do not merely rerun because an acknowledgement was lost. Reattach, return an existing
result, recover a missing receipt, retry safely, or report conflict according to the observed state.

Do not convert scientific similarity into an execution ban. Independent replication or a different
theory on the same data may be valuable. Engineering deduplication prevents duplicate effects; Codex
decides research value.

## Authentication boundary

Let the launcher use the generic WorkerPool transport profile and refresh its authenticated catalog. Do not run a
separate model-list ritual before every call and do not treat a cache file as proof of authentication.
Access-token age, an idle/cold worker, a bare HTTP 401, a stale summary, or another profile's state
never authorizes browser OAuth.

The `.grok-bg-workers` profile is only the generic WorkerPool transport and credential
identity. It is not a scientific worker role, a XINAO research mode, a task source, or a route
selector. Always name the transport/profile separately from the worker's current bounded role so a
generic code, audit, operations, or counterexample task cannot be misreported as scientific work.

If a new provider dispatch reports `GROK_AUTHENTICATED_PROFILE_AUTH_REQUIRED`, do not start login
from that report alone and never hand-write `grok login --oauth`. Use the only recovery admission
consumer:

```powershell
# No browser; returns a typed oauth_allowed decision after same-profile SelectionOnly.
C:\Users\xx363\CodexLaunchers\Invoke-GrokWorkerOAuthRecovery.ps1
```

SelectionOnly success, a valid authenticated catalog, or a silent refresh is a machine-enforced
OAuth veto. The wrapper admits recovery only after the exact auth-required state plus either an
absent/empty dedicated `auth.json` or explicit refresh-token-terminal evidence. If and only if its
receipt says `oauth_allowed=true`, invoke the same wrapper with `-StartOAuth`; it performs a second
SelectionOnly immediately before browser launch, so any concurrent successful refresh cancels the
login:

```powershell
C:\Users\xx363\CodexLaunchers\Invoke-GrokWorkerOAuthRecovery.ps1 -StartOAuth
```

Then retry the same canonical invocation once. Never copy credentials, fall back to another profile,
record secret bytes, or create a login daemon. A later `auth: scope removed` emitted by the login
command is a recovery side effect, not evidence that the earlier silent refresh failed.

## Stop and completion boundaries

- Pause/Stop freezes new dispatch, mutation, repair, and refill in scope while preserving evidence.
- A local timeout or failure freezes only its dependency cone; healthy siblings may continue when
  the active parent and Stop permit it.
- A worker terminal does not authorize automatic continuation beyond the current Codex lifecycle.
- Codex alone integrates, formally writes, adopts, verifies the real consumer, and judges parent
  completion.
