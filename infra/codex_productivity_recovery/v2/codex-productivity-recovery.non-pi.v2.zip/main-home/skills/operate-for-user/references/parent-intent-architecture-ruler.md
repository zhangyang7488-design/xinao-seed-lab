# Parent-intent architecture ruler

## Purpose and authority

Use this reference when a local capability ecology has accumulated multiple Skills, contracts, launchers, adapters, manifests, receipts, recovery notes, evaluations, or archived proposals and the question is no longer whether one component works, but whether the whole shape still serves the user.

The ruler is a non-authoritative audit and compilation procedure. It does not replace the current request, Decision Skill lineage, hard authorization and Stop boundaries, the product's unique truth, or live machine facts. It must not become a second router, architecture manual, ledger, control plane, or checklist that the user has to operate.

Its central question is:

> What user pain and parent result justified this function, and is its current shape still the lowest-cost reliable way to protect that result?

## Decision-frame admission

The recurring upstream failure is not merely that a rule is missing. It is that a latest sentence, local keyword, remembered rule, Skill trigger, or tool association can take control before the current request has become one coherent decision. The same failure can therefore appear as an immediate answer, an immediate record, an immediate action, an unwarranted refusal, or a local terminal state promoted to the parent.

Before replying, capturing, planning, asking, dispatching, or mutating, recover the smallest sufficient decision frame:

- the user's parent result and burden;
- the active subject and exact target object;
- the means being discussed versus the endpoint being protected;
- caller, child, Owner, candidate, consumer, and lifecycle roles that must remain distinct;
- the authorized change scope and the unmentioned objects or state that must remain unchanged;
- the proven dependency edges along which a local state may propagate;
- the real consumer and parent completion ruler;
- current authority, privacy, reversibility, and Stop or Pause boundary.

This is a reasoning step, not a form, stored profile, new control plane, or demand for a long explanation. A frame may be implicit when the facts admit one dominant reversible reading, but it must be recoverable from the chosen response or action. If two materially different valid frames remain, ask only for that real fork.

### Current intent-realization object graph

Represent that frame internally as one small current projection of a typed graph. It may be rendered as a tree for one task, but the durable concept is a graph because a capability, carrier, consumer, or constraint can support several branches.

Use these relational levels:

1. `human_practice`: the person, real situation, pressure, harm, and sustainable ability to act;
2. `parent_result`: the result to obtain and the burden the AI/product seam must absorb;
3. `current_frame`: the active subject, exact object, problem or decision, and completion ruler now in force;
4. `approach_or_capability`: admissible courses of action, domain work, and capabilities that may serve the frame;
5. `responsibility`: Owner/worker/consumer duties, requirements, contracts, and engineering functions needed to realize an approach;
6. `runtime_carrier`: repositories, files, configs, launchers, processes, credentials, providers, tools, artifacts, and state;
7. `consumer_effect`: observed real-world or real-consumer behavior and readback.

These are roles in the current relation, not noun classes. A configuration file may be a direct requested result in one turn and a replaceable leaf carrier in another. `current` is temporal activation, not a permanent hierarchy. Actor/Owner/candidate/adopter/consumer roles, authority/Stop/privacy/reversibility, live evidence and confidence, dependencies, and lifecycle/recovery are cross-cutting properties rather than extra levels.

Use only typed edges: `frames`, `refines`, `serves`, `realizes`, `operates_on`, `depends_on`, `constrains`, `owned_by`, `consumed_by`, `evidenced_by`, `conflicts_with`, and `supersedes`. An admitted action needs an upward path showing which current parent result it serves and a downward path ending in the consumer effect that can verify it. A missing upward path is a proxy-goal risk; a missing downward effect/readback path is a false-closure risk. No report, Skill, rule, metric, worker terminal, test, file, or runtime carrier may promote itself upward by name, proximity, or technical completeness.

Do not serialize this graph in ordinary turns. Keep a minimal internal slice and materialize a structured frame only for changed-context evaluation, cross-window handoff, a consequential or irreversible effect, or a real ambiguity whose alternatives change the parent result. Current words and live facts may rebind or supersede any node; Decision Skill supplies sourced candidate nodes and level-shift evidence, never the active graph by authority.

Admit a candidate only after all three checks pass:

1. **Object and frame conservation:** the change is bound to the intended object and lifecycle; callers, Owners, siblings, and other unmentioned state remain unchanged unless the current scope or a proven dependency requires otherwise.
2. **Dependency-directed propagation:** `WAIT`, failure, hidden, cleanup, `NO_ACTION`, and other local states travel only across explicit real dependencies; they do not become parent or global state by proximity, wording, or containment alone.
3. **Parent-result counterfactual:** compare the world after the candidate with the closest world in which it was not taken. Reject a locally literal success that worsens the parent result, violates a hard boundary, changes an object's role, or returns a known burden to the user.

Only then use recursive dynamic net benefit to choose answering, recording as a sidecar, asking, direct work, worker shape, waiting, or no action. Examples such as a caller window being minimized by a child-process rule, one Ticket's `WAIT` stopping a Campaign, or evaluation data becoming development input belong in the incident ledger and changed-context regression; they must not become a permanent symptom blacklist.

## Parent-intent invariants

Recover and test the following invariants before judging individual components:

1. **Parent result and burden:** the user's actual result and the burden the AI must absorb are the completion identity. A repair target, file, field, Skill, or tool is only a means.
2. **Technical-user mirror:** discoverable, derivable, generatable, and safely encapsulatable technical complexity belongs to the AI and product seam, not to the user.
3. **Authority and ownership:** Separate epistemic ownership from formal effect ownership. A designated world-owning cognition subject owns its questions, representations, and synthesis. The current technical effect Owner alone adopts into shared state, formally writes or merges, and verifies the effect it was entrusted to deliver. Workers remain candidate-only for shared effects. Current authorization, object scope, Stop, privacy, and material-choice boundaries remain intact.
4. **Recursive dynamic net benefit:** at every problem and implementation level, compare staying at the current level, moving up or down, acting, asking, delegating, and doing nothing. Do not freeze a provider, worker count, topology, tool order, or numerical score.
5. **Two token-economy axes:**
   - context and return containment: sealed bounded inputs, progressive disclosure, artifact-primary work, and short index or evidence envelopes;
   - quota opportunity cost: allocate eligible cognitive work across Codex and external workers without lowering reasoning, evidence, or parent completion.
   Never use either axis to remove necessary parent-intent reasoning.
6. **Mature-first and one real production identity:** prefer mature native capability and the thinnest local binding. Probes, fixtures, and simulations may coexist, but only the named real consumer may prove production effect.
7. **Compile known prerequisites:** stable hidden requirements must be discovered, derived, generated, and aggregate-preflighted before the first effect-bearing call. Unavoidable missing facts are reported once and completely.
8. **Constraint symmetry:** every hard gate must name the real harm it prevents and must reject the symmetric unsafe counterfactual. Advisory projections, presentation fields, and convenience metadata must never block formal execution.
9. **Single success definition:** prompt, package contract, acceptance, receipt, adoption, and real-consumer verification may have distinct roles, but cannot independently redefine success or contradict one another.
10. **Honest closure and recovery:** worker terminal, epistemic adoption, effect-owner adoption, authority application, effect verification, and parent completion stay separate. Recovery, storage, rollback, and cross-session ownership protect real objects without creating a second control plane.

## Pain-to-function lineage row

Inventory every material function, not only every file. One file may contain several functions and one function may span several carriers. For each function record:

- `function_id`: stable descriptive identity, independent of its current filename;
- `current_carriers`: exact active files, scripts, entry points, schemas, tests, or runtime consumers;
- `origin_pain`: the observed incident, recurring burden, unsafe counterfactual, or capability gap that caused the function to be introduced;
- `parent_intent`: the human result or harm boundary it was meant to protect;
- `minimal_responsibility`: the smallest job the function needs to own;
- `why_current_shape`: the evidence-backed reason for its present layer and mechanism;
- `real_consumer`: the process, model, user operation, or downstream effect that consumes it;
- `live_evidence`: current positive and negative evidence, including failure frequency and fresh-window behavior;
- `deletion_counterfactual`: the concrete failure expected if it disappears;
- `current_cost`: context tokens, return volume, latency, deterministic collisions, maintenance, coordination, fan-in, storage, drift, and recovery cost;
- `duplication_or_conflict`: repeated truth, conflicting success definitions, misplaced authority, or invisible routing;
- `automation_class`: model judgment, deterministic discovery, derivation, generation, encapsulation, or residual human choice;
- `disposition`: `keep`, `clarify`, `merge`, `split`, `move`, `automate`, `replace`, `retire`, or `no_action`;
- `smallest_change`: the narrowest existing shared consumer that can land the decision;
- `verification_and_rollback`: changed-context consumer, real effect, negative boundary, and exact recovery path;
- `confidence_and_unknowns`: what is proven, inferred, stale, or still missing.

Do not invent origin stories. If the historical pain cannot be recovered, label it unknown and use current counterfactual evidence. A plausible story is not lineage.

## First-principles tests for every structure

Apply these tests in order:

### 1. Parent-fit test

- Does the structure materially advance a parent result, protect an authorization or integrity boundary, reduce a recurring user burden, or create necessary evidence?
- Has its implementation object become the de facto parent goal?
- Would a technically correct implementation still leave the user with the original burden?

If parent fit is absent, prefer retirement or archival over clarification prose.

### 2. Necessity and symmetry test

- Name the exact unsafe or false-green trajectory prevented by the constraint.
- Remove the constraint in a thought experiment and state the observable harm.
- Keep the safe symmetric case admissible. A gate that rejects both the harmful and safe counterfactual is overbroad.

### 3. Layer and automation test

- Human or material choices remain explicit.
- Model judgment handles semantic interpretation and genuinely open tradeoffs.
- Deterministic code handles enumeration, hashing, path resolution, prerequisite discovery, generation, aggregate validation, and projection.
- Product-specific facts stay in the product truth; cross-product burden and completion rules stay here; judgment lineage stays in Decision Skill; live facts stay live.

If every fresh caller must understand an internal field, the layer is wrong even when the field is necessary.

### 4. Token and information-flow test

- Is thick source material kept out of prompts until selected?
- Can a hash-bound slice or index preserve exact identity without copying the whole source?
- Does the worker leave substantive work in artifacts and return only the decision-relevant envelope?
- Does Codex reread only what adoption and effect verification require?
- Are multiple summaries, manifests, receipts, or reports copying the same prose instead of referencing one source?
- Do deterministic call failures cause repeated retransmission of unchanged thick context?

Metadata that costs more than the bounded content it protects must be simplified or generated, not defended by its original intention.

### 5. Production and success-definition test

- Which single real path proves the capability for this invocation class?
- Are alternate transports explicit mutually exclusive routes rather than simultaneously authoritative truths?
- Can fixtures, probes, and health reports be mistaken for production effect?
- Do prompt instructions, markers, schema, worker receipt, role-scoped adoption, and consumer readback agree on one success object?

### 6. Recovery and lifecycle test

- Can the normal caller retry or reseal after every documented terminal state?
- Does an error message name an entry that actually exists and is tested?
- Are active, terminal, superseded, retired, and advisory artifacts distinguishable?
- Can an advisory or stale projection block the formal identity path?
- Does another session or TUI remain protected without forcing a new control plane?

An invariant whose valid recovery path is impossible is internally contradictory, not safely fail-closed.

### 7. Dynamic-net-benefit disposition

Compare the smallest viable options rather than only keep versus delete:

- keep unchanged;
- clarify the unique source or discovery description;
- merge duplicate definitions while preserving one consumer;
- split genuinely different jobs;
- move a function to its correct layer;
- automate a stable manual prerequisite;
- replace a local mechanism with a mature native component;
- retire a stale carrier after consumer and rollback checks;
- take no action when change cost exceeds the evidenced benefit.

The decision must include fan-in and verification capacity. A broad rewrite is not superior merely because the audit is global.

## Whole-machine audit sequence

1. Freeze the current parent intent, authority boundary, other-session ownership, and observable completion ruler.
2. Inventory active consumers first: hot rules, Skills and plugins, product truths, launchers and scripts, runtime services, recovery carriers, evaluations, and real entry points.
3. Recover origin pain and lineage from current comments, task-run evidence, Decision Skill events, PRs, and archives. Archives are evidence, never an automatic live source.
4. Group rows by function before judging files. Separate policy, procedure, deterministic mechanism, live fact, evidence, and recovery projection.
5. Apply every first-principles test and record a candidate disposition.
6. Use independent research or criticism only for separable questions with positive net benefit; worker output remains candidate-only.
7. Land positive-benefit changes in the smallest existing source and generated consumers. Do not create a new global wrapper merely to make the matrix look complete.
8. Verify with changed-context cases in which a fresh AI receives only the ordinary human goal and material constraints. It must recover the right support, avoid hidden-field trial and error, preserve boundaries, and reach the real consumer.
9. Read back repositories, installed releases, pointers, and runtime effects; retire only exact classified temporary objects.

## Required output views

Produce three linked views rather than one long prose report:

1. **Parent-intent map:** the small invariant set and supported user burdens.
2. **Pain-to-function matrix:** one row per material function with evidence and disposition.
3. **Change ledger:** exact landed changes, real-consumer verification, remaining unknowns, rollback, and `verified / partial / blocked / unverified` status.

The views are task evidence, not permanent duplicate truths. Permanent carriers receive only their unique resulting rule, procedure, mechanism, pointer, or regression.

## Completion bar

The audit is not complete because every file has a row or the prose is elegant. It closes only when:

- active functions have evidence-backed parent and pain lineage or are honestly marked unknown;
- unnecessary or misplaced structures have an explicit disposition;
- every adopted positive-benefit decision reaches its unique live carrier and generated consumers;
- token containment is measured in both directions without suppressing necessary reasoning;
- a fresh consumer applies the ruler before selecting or constructing a technical shape;
- real product calls demonstrate that known prerequisites no longer return as repeated user-visible collisions;
- other sessions, authorization, Stop, product truths, and rollback remain intact.
