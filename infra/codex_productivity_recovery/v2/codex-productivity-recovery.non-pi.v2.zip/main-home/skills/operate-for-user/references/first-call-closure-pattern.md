# First-call closure pattern

## Anchor incident: repeated Grok pre-model walls

The user asked for several independently useful cognitive worker packages. The desired business
result was candidate research and criticism that the current cognition consumer could assess, while
the current technical effect Owner verified any formal shared effect.

The failing trajectory was:

1. The complete ready frontier was split into three singleton common-contract calls.
2. The calls were launched before a frozen context identity or validated context manifest existed.
3. All three failed before any provider model invocation.
4. The retry used the colloquial phase `AUDIT`, although the product contract accepted only `EXPLORE`, `CONSTRUCT`, `VERIFY`, or `LAND`.
5. The second wave again failed before the model, forcing the user to watch fresh windows rediscover stable internal rules.

Nothing here proves that identity or phase checks were wrong. Two counterfactuals separate the protected boundary from removable burden:

- If identity and context checks are removed, concurrent windows, releases, or inputs can be mixed. The private machine does not eliminate that harm.
- If the checks remain but the sender prepares context, rules, supported phases, episode identity, and package shape before launch, the repeated collision disappears.

The dominant repair is therefore: retain the integrity boundary and build a private happy path that closes known sender inputs before the first call.

## Correct placement

The cross-product **outcome-owner completion posture** belongs in `operate-for-user`: the user should not debug hidden stable product contracts through repeated failure. The Skill instantiates it as a technical-user mirror—standing on the user's result, burden, authorization, and satisfaction side while being fluent in the product's technical language.

Decision Skill remains the evidence home for how the user judges and why this burden matters. `operate-for-user` consumes that evidence and turns it into a task-local responsibility and completion frame. It does not copy the personal model, invent a new user, or gain authority.

The exact phase vocabulary, package/common decision, manifest construction, retry identity, and invocation remain in the Grok product Skill and canonical launcher. The launcher aggregates deterministic common-contract defects before quota lookup, selection, dispatch identity, or model execution. The behavior regression requires a fresh Codex consumer to choose one heterogeneous package batch for differing responsibilities and reject repeated singleton calls.

This separation prevents two opposite mistakes:

- putting every Grok parameter into a personal profile, which creates a stale second manual;
- fixing only today's launcher while leaving future products free to return the same operational burden.
- treating the mirror as a user impersonator or permission source instead of an execution-side translation of existing intent.

## General transfer procedure

For another product, replace Grok-specific nouns but preserve the questions:

1. What is the user's ordinary human-level request?
2. What exact downstream effect proves it worked?
3. Which stable requirements are already knowable before execution?
4. Which can be discovered, derived, generated, or encapsulated?
5. Which remaining fact is a true material user choice?
6. Can deterministic invalidity be reported completely before side effects?
7. Can a fresh AI execute the normal path without hidden chat context?

Examples:

- **Install or upgrade:** detect platform, existing version, storage policy, dependency conflicts, rollback, and fresh-process health automatically. Ask only for license, payment, account, or materially different topology.
- **API or connector:** discover the configured credential handle and endpoint without printing secrets; validate scopes, schema, version, and health together before the real mutation.
- **Worker or model:** recover complete frontier and provider facts, prepare context and acceptance, select one valid execution shape, then invoke; never spend real calls learning stable enums.
- **Long-running service:** first determine whether persistence is actually requested. If not, keep it bounded; if yes, bind owner, health, restart, state, Stop, and rollback before installation.
- **Recovery:** classify the failed dependency cone, preserve healthy siblings, use the exact known-good/re-entry path, and prove the original consumer works again.

## Positive acceptance cases

- A fresh window receives only the user's normal goal and current object. It selects the applicable product Skill, prepares every deterministic hidden input, and the first real invocation reaches the intended consumer.
- A deliberately invalid request contains several independent caller defects. One local preflight returns all of them and produces no avoidable provider, quota, dispatch, mutation, or model artifact.
- One prerequisite genuinely depends on a user-owned material choice. The AI asks one plain-language question describing effect, risk, rollback, and non-effects; it does not expose unrelated engineering fields.
- One external alias or dependency drifts unpredictably. The system records a bounded runtime failure and performs the documented recovery; it does not misclassify this as a preventable caller-preparation success.
- A fresh window can explain the user's actual completion bar and burden allocation in plain language, then derive the technical checks from the product source without copying its procedure into the user layer.

## Negative acceptance cases

- The AI adds more prose but still calls repeatedly to discover missing fields.
- The AI removes an integrity check to make the happy path appear smoother.
- The AI asks the user for paths, hashes, versions, enums, or order that live state and product sources can determine.
- The AI builds a global wrapper, daemon, database, or second router instead of repairing the existing product entry.
- A static test or configuration is green, but no fresh consumer reaches the real endpoint.
- The Grok incident is memorized literally, yet a different product reproduces the same hidden-prerequisite burden.
- The mirror claims that a remembered preference authorizes a new account, audience, payment, persistent process, write, or other material effect.

## Completion report

Report separately:

- pre-report user-side gate applied before composing the claim, not after a user correction;
- user background captured;
- product-specific consumer updated;
- deterministic preflight verified;
- valid real first call verified;
- invalid aggregate failure verified before effects;
- fresh-window transfer verified;
- remaining manual choice or external uncertainty;
- rollback and recovery entry.

Only the closed predicates may be called verified. The skill itself is not the product result.
