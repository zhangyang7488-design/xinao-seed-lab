# 行为修复维护合同

## 控制层路由

| 观察到的失败 | 首选唯一消费者 | 不应落到 |
|---|---|---|
| 单对象有充分局因 | 对象、adapter、入口或局部测试 | 全局行为 Skill |
| 产品安装、恢复、跨窗字段反复退给用户 | 产品 Skill + `operate-for-user` + 真实入口 | 个人偏好模型 |
| 工包形状、worker terminal、认识采用与 effect adoption 混同 | `amplify-supervisor-worker` 与正式执行面 | 本 Skill 的通用检查表 |
| 人的现实活动被平台、报告、规则或局部绿替代 | `human-agency-grounding` 或其最薄通用原则 | 领域事实伪造 |
| 父价值、子结果、手段、证据、减负或完成层级被混型 | 本 Skill 的 `value-semantics.md` + held-out/metamorphic 回归 | 再加对象词表或固定评分器 |
| Decision Skill、人的实践帧、代运维和工程事实分别存在却未在行动前汇合 | 全局薄位阶对象图 + 当前 role-bound cognition/effect subject 的事件驱动重锚 + 既有 Skill 的按需候选输入 | 新总管 Skill、每轮全量 PDM 或第二模型调用 |
| 已知价值仍不能自行推出行动降级，必须等用户点破 | 本 Skill 的生成性迁移消费者与 fresh-context 轨迹 | 把用户原话复制成更多结论规则 |
| 局部完成真实但无父效果边 | 保留 `child_complete`，在父消费者上验证 effect edge | 抹掉子完成或直接写 `parent_complete` |
| 局部完成或阶段报告把已知未闭父序列变成隐含停止 | 全局热核的 turn-finalization 准入 + 当前责任角色重展完整未闭前沿 + changed-context continuation 回归 | 依赖用户再次说“继续”、常驻自动续跑或把所有任务改成 continuous |
| 窗口或工程阶段把已建立的父任务重新降成“默认无授权”，要求用户逐阶段批准 | 全局用户侧技术 effect Owner 连续姿态 + SessionStart/UserPromptSubmit 消费 + phase-boundary changed-context 回归 | 把每个阶段做成审批门、由包内 receipt 创造授权、或让记忆自行生成任务；也不得借连续委托接管 world-owning Sol 的认识 |
| 首个局部解释可辩护后立即收敛，未覆盖动作/非动作同构族或残余反例 | 现有第零拍与 Planner 的事件驱动有界闭包 + 确定性对称枚举 + 高杠杆时的独立反证 + 覆盖账 | 每轮第二模型、无限分析、再造总管 Skill 或用一条绿测声称通用闭包 |
| 自动化减负与科学认识互相冒充 | 过程负担账 + 领域科学结算 | 用单一“生产力”分数合并 |
| 同类 agent 错位需要事故到行为改动的闭环 | `repair-agent-behavior` | 新控制面/daemon |
| 稳定个人判断、负担或授权姿态 | Decision Skill 事件/候选 | 把记录当授权 |
| 关键纠偏应跨窗强烈塑形、但尚未成为正式规则 | Decision Skill 的纠偏情节 + 非权威 shaping card + predecision hotspot consumer | 复制进 L0、普通低权重历史或另建控制面 |
| 身份、完整性、Stop、不可逆风险必须 fail closed | 确定性消费者/代码/invariant | 仅靠提示词 |
| Skill 源码新但正式安装/投影/入口旧 | 发布、安装、projection、fresh discovery | 再写一份同义 Skill |
| 模型能力在 held-out 上持续不足 | 模型/产品升级、脚手架缓解、评测与诚实范围 | 声称本地 Skill 已治愈模型 |
| 临时运行进度或恢复位置 | task-run/checkpoint/live object | 永久 Skill 规则 |
| 临时痛点材料被做成运行、发布或恢复依赖 | 当前分析期最薄来源区分，随后只留抽象事故事件与合成/脱敏回归 | Skill、manifest、checkpoint 或发布包中的原路径、hash、内容副本 |
| 混合载体同时含陈旧领域路由与仍需保留的通用能力 | 先按职责拆分，给保留能力建立薄的 live consumer 与回归，再退役陈旧部分 | 整包删除后只留静态说明，或因局部污染保留整套旧权威 |

若两个控制层都看似合格，选最靠近实际失败点且能被真实消费者回读的那一层。跨层只保留一个正定义，其他层引用或机械执行。

## 最大链内责任的精确定义

当前用户已明确授权 Codex 完整负责本 Skill 的落地、生效、元自指、更新与自维护，并要求共同约束内不再索要授权。该姿态意味着：

- 用户拥有结果；Codex 拥有当前行为修复与其工程/effect scope 内可推导的技术决定与执行责任，不拥有被测 world-owning Sol 的领域认识；
- 当前行为投诉或显式调用给出活动对象，本 Skill 自动吸收其可回滚实现、研究、派工、安装、测试和维护细节；
- 不把“选择哪条内部实现”“是否跑回归”“是否安装/刷新投影”问回用户；
- 没有真实用户选择时，当前相应责任席执行后告知，不举行批准仪式；认识采用与正式 effect 分别归位。

它不意味着 Skill 文件本身可产生权限。system/developer、当前更具体的用户语句、Stop、对象与重大外部效果边界始终优先。重大外部效果的例子包括新账户/受众/付款、公开发布到未授权对象、秘密处理扩张、常驻控制面、不可逆迁移或破坏性删除。

## 版本与发布

- 当前版本：`2.6.0`。保留 `2.5.1` 的来源裁决行动经济，同时把用户侧技术 Owner 严格限定为当前行为修复/工程/effect scope；world-owning cognition subject 保留领域问题、表示、计算与综合，worker terminal、认识采用、正式共享 effect 和父完成不再被一个“Codex Owner”统摄，故按 MINOR 发布。
- PATCH：措辞澄清、链接或不改变选路的例子修正。
- MINOR：兼容地增加事故族、路由或回归能力。
- MAJOR：改变激活范围、最大链内责任边界、唯一工作身份或与其他 Skills 的职责分界。

每次行为变更必须同时留下：来源事件/事故、竞争假说、受影响案例、近邻负例、唯一写域、安装投影身份、fresh-process 证据和回滚点。改变价值语义时还必须包含无事故关键词的 held-out 同构和同一对象换父任务后的分类反转。不要维护第二状态库；使用现有 Decision Skill、D 盘 behavior-regression evidence、仓库历史和产品发布 receipt。

“来源事件/事故”保存行为事实与抽象 delta，不等于保存用户临时原件。临时桌面文件、粘贴文本和一次性派工切片默认只活到本轮行为抽取完成；除非用户明确要求留档或存在已适用的保留义务，发布 receipt 不记录其路径、文件名、hash 或内容副本，且不得要求用户为 Skill 保留、搬迁或重建这些材料。

安装完成至少验证：

1. `SKILL.md` 与 `agents/openai.yaml` 结构有效；
2. 标准 Skills 目录中的实际字节和 hash；
3. 新进程发现显示名、description 与默认 prompt；
4. 显式调用和语义隐式触发；
5. 相邻负例不触发完整行为修复；
6. 回滚到上一版本可行。

发布的完整文件集必须包括 `SKILL.md`、`agents/openai.yaml`、`references/maintenance-contract.md`、`references/evaluation-cases.md` 和 `references/value-semantics.md`。安装前用上一 release 的完整 hash 做 CAS，安装后核 live 与候选完整文件集；不得只比对入口文件。

## 自维护决策

新事故进入时按此顺序：

1. **consumer gap**：规则/Skill 已有，但加载、投影、正式入口或效果消费断裂；修接缝。
2. **coverage gap**：现有生成原则不能覆盖新表面；最小扩展现有原则与回归。
3. **wrong abstraction**：共同生成器被误判；撤回、拆分或降回局部。
4. **base capability gap**：提示和脚手架不足以稳定改变模型；保留评测、升级模型或限制声明。
5. **no defect**：当前系统在父结果和边界上已正确；不改。

禁止用“再加一条规则”作为默认第一步。若事故与已有回归完全同构却仍发生，重复写规则应被视为可疑操作。

## 成熟依据

- [Google DeepMind: Specification gaming](https://deepmind.google/blog/specification-gaming-the-flip-side-of-ai-ingenuity/)：字面目标可被满足而人的预期结果未发生，穷举角落并不能根治。
- [Google DeepMind: Goal misgeneralisation](https://deepmind.google/blog/how-undesired-goals-can-arise-with-correct-rewards/)：能力可泛化而目标不按预期泛化，因此训练内正确不等于换情境正确。
- [NIST AI RMF Core](https://airc.nist.gov/airmf-resources/airmf/5-sec-core/)：从意图与部署语境出发，连续 map/measure/manage，并把用户反馈接回评估；它明确不是有序检查表。
- [Anthropic: Demystifying evals for AI agents](https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents)：把真实失败变成评测，并与生产监测、用户反馈、转录复核和人工校准结合。
- [Anthropic: Building effective agents](https://www.anthropic.com/engineering/building-effective-agents)：先用最简单充分的组合方式，只在真实需要时增加 agent 复杂度。

这些来源提供方法族，不产生本地授权，也不替代本机真实消费者。
