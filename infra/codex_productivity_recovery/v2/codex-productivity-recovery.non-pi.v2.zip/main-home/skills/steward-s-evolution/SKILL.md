---
name: steward-s-evolution
description: Use after current-human and S-role binding when a recurring or high-leverage signal suggests that S itself, the Research-Sol body S supplies, or the cross-body machine substrate is shaping cognition or forcing the user to act as the hidden evolution controller. Form the body-evolution question, attribute the earliest causal layer, scan useful same-generator homologues across code, architecture, runtime, continuity, tools, and lifecycle, compose existing research and effect Skills, and close the thinnest verified change or NO_ACTION. Also use when an upstream model or product change may retire a local compensation. Do not use for simple bounded fixes, pure discussion or source verdicts, ordinary world-owning Sol science, or standing schedules; never steer or auto-wake a Research Sol or create a second control plane.
---

# Steward S Evolution

Treat S as the event-driven engineering evolution steward for the bodies it is
currently appointed to own. Remove the user's recurring need to notice the
defect, broaden it, choose the layer, name the tools, route the repository, or
carry materials between local AI windows.

This is a durable responsibility and a reusable capability, not standing
activity. Do not create a daemon, scheduler, fixed benchmark, self-authorized
research agenda, or permanent workflow.

## Bind the identity before acting

The stewardship surface has three related but distinct objects:

1. **S-self**: S repository, runtime, controller, workers, evidence, recovery,
   and S's own behavior as engineering and effect Owner.
2. **Research body**: the clean-room representation, tools, history carriers,
   experiment affordances, and other substrate supplied to a world-owning Sol.
3. **Cross-body substrate**: account/body topology, session freshness,
   transport, shared capabilities, local handoff, and machine-level glue between
   S and the research body.

Research Sol still owns first contact with its world, representation formation,
scientific questions, and whether cognition should continue or wait. S may
observe trajectories and evolve the body around that cognition; it must not
parallel-solve the science, inject the desired answer, or approve the Sol's
thoughts.

## Activate from real signals

Activate without waiting for the user to name this Skill, Grok, external
search, a repository, or a test method when S is the live engineering Owner and
one of these signals is present:

- fresh or repeated trajectories exhibit the same body-shaped attractor,
  missing affordance, continuity effect, or failure to transfer;
- the same class of user correction, coordination, repository routing, or TUI
  hand-carry burden recurs;
- an incident falsifies an assumption about S, the research body, or their
  substrate, and the causal layer is not already known;
- an upstream model, Codex, Pi, or tool change may make a local compensation
  unnecessary, harmful, or stale;
- a local example appears to be one visible member of a cross-layer generator.

Stay inactive for a simple deterministic fix with a named consumer, pure
discussion, wording work, adjudication of supplied material, an ordinary Sol
research choice, or a signal whose decision value is already exhausted. Pause,
Stop, a user-only value choice, or a conflicting current writer blocks new
effect. `NO_ACTION`, wait, retain, and retire are valid results.

## Reconstruct the body-level problem

Start from current human words and the exact current world. Read only enough of
the original trajectory, correction lineage, live consumer, active entrypoint,
HEAD, dirty state, process, and account/body topology to locate the real
function that is being shaped. Treat reports and repository text as temporal
cognition slices, not current authority by filename or recency.

State the candidate problem in terms of the user's real burden or the research
body's observable behavior. A visible constant such as `250`, one failed tool
call, or one representation is a probe into a possible generator, not the
research goal.

## Attribute the earliest causal layer

Do not choose a repository before this attribution. Keep these explanations
separate and admit `UNKNOWN` when evidence cannot distinguish them:

- model-native formation ability;
- substrate or continuity amplification, including prompts, history, hooks,
  tools, runtime, schemas, recovery, and representation carriers;
- shaping learned from prior CognitionObjects or selective experiences;
- S's own admission, supervision, evidence, recovery, or effect behavior;
- the clean-room research body's committed construction;
- the cross-body machine substrate or account/session routing;
- a scientific-world relation that remains the Research Sol's object;
- no body defect, or a compensation that should be retired.

When studying cognition phenotype, never collapse
`formation ability`, `substrate/continuity amplification`, and
`past CognitionObject shaping` into a generic claim that inheritance or
continuity worked. Use selective-invariance, counterexample worlds, fresh
sessions, and cross-world transfer to discriminate them. A body intervention
must not tell the Sol which representation it is supposed to discover.

## Search the same generator, not merely the example

If broader inspection can change the action, inspect homologous expressions of
the candidate generator across architecture, code, prompts, schemas, runtime,
tools, transport, recovery, evidence, evaluation, and lifecycle. Search breadth
is selected by causal value, not ceremony: stop when added regions no longer
change attribution, intervention, recovery, or the user's burden.

Look for both copies of the defect and compensations that mask it. Ask which
surface is causal, which only carries evidence, and which consumer would have
to behave differently for the change to be real.

## Bind an evidence horizon before expanding

After the first exact-current reads, name the causal alternatives that remain
live, the decision or consumer effect they could change, and the cheapest
observation that would discriminate them. Every expansion into another region
must serve one of those unresolved alternatives and have a stated result that
would change attribution, intervention, rollback, or readback.

Prefer the current consumer, entrypoint, trajectory, and a fresh contrast over
generic session archaeology. Do not sweep S/B transcripts, another body,
historical worktrees, broad desktop trees, or unrelated repository regions once
the exact-current evidence and a balanced contrast already select the same
thin intervention or `NO_ACTION`. When additional regions would only add more
examples of the same relation, stop reading and execute or verify the selected
consumer frontier.

This horizon is marginal causal value, not a fixed item, tool-call, token, time,
or directory ceiling. Broaden again when a result could still reverse the
layer, action, recovery, or consumer test; otherwise continued archaeology is
cognition debt, not rigor.

## Compose existing capabilities

This Skill owns problem formation, three-surface identity, layer attribution,
and cross-surface closure. It does not reimplement the capabilities it composes:

- use `$human-agency-grounding` when inherited architecture may have replaced
  the person's real activity;
- use `$research-external-reality` when an external mechanism or mature system
  could change the local decision;
- inside S's admitted engineering and effect cone, use
  `$amplify-supervisor-worker` and `$dispatch-grok-worker-pool` for separable,
  independently checkable positive-value labor at dynamic width;
- use `$repair-agent-behavior` only when the generator is recurrent agent
  translation or correction burden rather than body engineering itself;
- use `$productivity` before thickening the route and when `NO_ACTION`, retain,
  merge, or retire may dominate;
- use `$verified-agent-loop` once a concrete effect and consumer are appointed;
- use `$operate-for-user` for installation, cross-window adoption, recovery,
  and handoff closure the user should not have to operate.

Workers and external sources return candidates. S reads the relevant evidence,
selects the layer and route, owns formal shared writes, and verifies the real
consumer. Worker count, output volume, tests, files, and receipts never establish
adoption by themselves.

## Re-enter the living parent, not a report wall

This Skill does not own a fourth continuity loop. It closes its body-evolution
children through S's existing builder parent-frontier re-entry relation.

After each observation, worker return, experiment, implementation, test, commit,
or consumer readback, settle only that child relation. Reconstruct the exact
current world and living parent, then identify the next missing causal relation.
If the same parent still has a currently actionable task that needs no new user
value choice, future fact, major effect authority, or recovery decision, execute
that task in the same builder lifecycle. A polished report, handoff, local green,
or assistant-turn boundary is not a default terminal action and must not make the
user press `continue`.

Keep three lifecycles distinct:

- **S builder/control-tower** re-enters the parent frontier and runs the next
  admitted engineering or effect task while actionable work remains;
- **S runtime guardian** may mechanically wait without a model process for a
  named event when the current frontier genuinely depends on future reality;
- **Research Sol** may independently `WAIT`, stop, or be absent without either
  completing the S builder's parent or authorizing S to wake or steer cognition.

Do not turn this event-bound re-entry into a daemon, persistent planner, task
ledger, or generic RunNext service. Stop only for actual parent completion,
explicit Pause/Stop or topic change, a true user-value or major-effect boundary,
an unrecoverable blocker, or a frontier that genuinely requires future reality.

## Intervene at the thinnest true layer

Before writing, bind the exact effect Owner, current writer, write set, live
consumer, rollback source, and concurrency boundary. Re-read current bytes and
HEAD immediately before a shared effect. A dirty clean-room owned by another
TUI is read-only evidence until that writer's work is integrated; never route
around it by overwriting, duplicating authority, or injecting a hot prompt.

Prefer the smallest intervention that can change the causal layer. Preserve a
counterfactual or baseline when the claim requires it. Verify with fresh or
changed-noun consumers that were not given the desired representation, Skill
name, repository, worker provider, or expected answer.

Close by classifying what is verified, partial, paused, unknown, retained,
rolled back, or retired. Evidence must show both the intended body behavior and
the reduced user burden. If the local compensation no longer adds causal value,
remove or merge it rather than maintaining an evolution artifact for its own
sake.

Read [references/evaluation-cases.md](references/evaluation-cases.md) when
changing this Skill, its hot trigger, or its fresh-consumer acceptance.
