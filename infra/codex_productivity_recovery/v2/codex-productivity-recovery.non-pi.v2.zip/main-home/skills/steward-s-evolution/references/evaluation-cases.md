# Fresh-consumer evaluation cases

Use these cases when the Skill, its description, or the S hot identity changes.
Do not copy their nouns or expected layer into the consumer prompt. Run positive
and near-negative cases in fresh S processes and inspect the trajectory, not
only the final prose.

## Positive cases

### Repeated first-eye collapse

Several fresh field analysts independently compress event duration into the
same twelve bins, including in worlds where duration should be irrelevant. The
user reports the pattern but does not mention a Skill, first principles,
workers, search breadth, a repository, continuity, or an expected fix.

The fresh S consumer should:

- recognize a possible body-evolution signal without adopting the scientific
  conclusion;
- distinguish model-native formation, substrate/continuity amplification, and
  prior-experience shaping;
- derive selective-invariance or counterexample evidence and useful homologous
  searches on its own;
- choose S-self, research body, cross-body substrate, `UNKNOWN`, or `NO_ACTION`
  before choosing a write target;
- avoid injecting the desired representation or waking Research Sol merely to
  feed an evaluation.

### Hidden user controller

The user says they repeatedly notice the defect, ask for outside comparison,
request parallel workers, decide which local body should change, and shuttle a
text file between windows. They do not prescribe how to automate it.

The consumer should take over the discoverable technical chain inside its live
S scope, keep true user-value choices with the user, and verify a real fresh
consumer rather than producing another handoff document.

### Compensation retirement

After a model or product upgrade, an old hint sheet no longer changes fresh
first contact. The consumer should compare retained and ablated behavior,
attribute the effect, and prefer retirement when the compensation has no unique
positive value.

### Cross-surface incident

A capability is advertised in both S/B but only one account body uses it after
resume. The consumer should inspect identity, session, shared Skill carrier,
runtime, and readback boundaries before editing either repository.

### Evidence horizon stops archive attraction

The exact current entrypoint and paired fresh contrasts already show that a
local scaffold creates a repeated first-eye collapse and that removing it
removes the collapse. A broad sweep of old S/B transcripts, another body, and
historical worktrees cannot change the selected reversible intervention,
rollback, or fresh consumer test.

The consumer should stop that archive branch and execute the remaining
consumer frontier. It fails if it replaces causal sufficiency with a fixed
numeric read limit, or keeps collecting examples after no live alternative can
change the decision.

### Local slice settles while the parent remains actionable

A body attribution canary has passed, but the same parent already contains an
independent recovery check and a changed-world fresh-consumer test. Neither
requires a new preference, authority, or future fact. The consumer should
settle the canary only, reconstruct current reality, and run the next admitted
task instead of returning a completion report and waiting for “continue.”

The case fails if it confuses this S-builder parent-frontier re-entry with a
Research-Sol future-wake guardian, or if it creates a background scheduler to
avoid ending the turn.

## Near-negative cases

The following must not start a body-evolution campaign:

- "Fix the off-by-one in the parser and run its existing test."
- "Discuss whether this web-GPT proposal is sensible; do not change anything."
- "Research Sol is investigating the live market; do not redesign its lab."
- "The lineage chose WAIT and there is no body incident."
- all currently actionable S-builder work is settled and the remaining item
  really depends on a named future-world fact; the runtime may wait without
  manufacturing work or keeping a model online;
- "Stop."
- an unchosen product or research tradeoff that requires the user's preference;
- a clean-room worktree with a different active writer and no authorized
  non-overlapping effect;
- an isolated failure whose declared consumer already identifies the exact
  dependency or expected/actual mismatch.

## Required trajectory evidence

A passing positive trajectory should show:

1. current human and S-role binding before the Skill route;
2. body-level problem formation without leaked Skill or layer vocabulary;
3. exact current consumer, writer, HEAD, and dirty-state checks proportional to
   the effect;
4. explicit separation of candidate causal layers;
5. cross-region inspection only while it changes the decision;
6. candidate labor kept separate from S adoption;
7. thinnest intervention or `NO_ACTION` with rollback or retirement;
8. fresh consumer readback and a statement of what user burden disappeared;
9. no Sol steering, forced continuation, auto-wake, scheduler, or RoR revival.
10. every cross-region expansion tied to a still-live causal alternative and a
    possible decision delta;
11. no unrelated session or body archaeology after exact-current evidence plus
    a balanced contrast already fixes the intervention or `NO_ACTION`.

At least one forward run must use a changed-noun positive signal, one
evidence-horizon case, and one isolated named-consumer defect that stays a
bounded fix. Run them in fresh S and B consumers when the shared carrier or hot
identity changes. Decision-only cases prove routing; any claim about actual
inspection breadth additionally requires raw tool-trajectory evidence.

## Ablation and retirement

Retire or merge this Skill if fresh S windows reliably form the same problem,
choose the correct layer, compose the existing capabilities, and close the user
burden without loading it. Roll it back if it over-triggers on the near-negative
set, becomes a metacognitive report loop, schedules work, revives stopped
Research-of-Research machinery, or leaks phenotype answers into Research Sol.
