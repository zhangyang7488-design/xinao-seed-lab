from __future__ import annotations

import json
import sqlite3
import stat
import subprocess
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

SCRIPT = Path(__file__).parents[1] / "scripts" / "pdm.py"
PERSPECTIVE_SCHEMA = (
    Path(__file__).parents[1]
    / "references"
    / "user-perspective-packet.v2.schema.json"
)


def call(root: Path, *args: str, ok: bool = True) -> tuple[subprocess.CompletedProcess[str], dict]:
    completed = subprocess.run(
        [sys.executable, str(SCRIPT), "--root", str(root), *args],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if ok:
        assert completed.returncode == 0, completed.stderr
        return completed, json.loads(completed.stdout)
    assert completed.returncode != 0
    return completed, {}


def test_capture_candidate_promotion_retrieval_and_immutability(tmp_path: Path) -> None:
    _, initialized = call(tmp_path, "init")
    assert initialized["status"] == "initialized"

    _, captured = call(
        tmp_path,
        "capture",
        "--event-id",
        "evt-correction",
        "--type",
        "correction",
        "--source-ref",
        "test:1",
        "--summary",
        "Do not turn a provider preference into a public hard dependency.",
        "--payload-json",
        '{"stable":true}',
    )
    assert captured["event_id"] == "evt-correction"

    principle = {
        "kind": "principle",
        "principle": {
            "principle_key": "capability-before-identity",
            "name": "能力先于身份",
            "statement": "Public rules bind capabilities, not replaceable worker names.",
            "rationale": "A removable worker identity must not become the protected result.",
            "scope": ["worker-routing"],
            "conditions": ["the worker is replaceable"],
            "priority": 80,
            "confidence": 0.9,
            "valid_from": "2026-07-23T00:00:00Z"
        }
    }
    _, proposal = call(
        tmp_path,
        "propose",
        "--proposal-id",
        "proposal-capability",
        "--type",
        "principle",
        "--source-event-id",
        "evt-correction",
        "--payload-json",
        json.dumps(principle),
        "--impact-scope-json",
        '["worker-routing"]',
    )
    assert proposal["status"] == "candidate"

    failed, _ = call(
        tmp_path,
        "promote",
        "--proposal-id",
        "proposal-capability",
        "--reason",
        "no evidence",
        ok=False,
    )
    assert "passing evaluation" in failed.stderr

    _, promoted = call(
        tmp_path,
        "promote",
        "--proposal-id",
        "proposal-capability",
        "--reason",
        "explicit stable correction in test",
        "--user-explicit",
    )
    assert promoted["status"] == "promoted"

    _, explanation = call(tmp_path, "explain", "--query", "replace worker provider")
    assert explanation["authority"] is False
    assert explanation["relevant_principles"][0]["principle_key"] == "capability-before-identity"

    db = sqlite3.connect(tmp_path / "personal_decision_model.sqlite3")
    try:
        with __import__("pytest").raises(sqlite3.IntegrityError, match="append-only"):
            db.execute("UPDATE events SET summary='drift' WHERE event_id='evt-correction'")
    finally:
        db.close()


def test_read_only_commands_do_not_mutate_or_initialize_storage(tmp_path: Path) -> None:
    call(tmp_path, "init")
    call(
        tmp_path,
        "capture",
        "--event-id",
        "evt-read-only",
        "--type",
        "observation",
        "--source-ref",
        "test:read-only",
        "--summary",
        "Read-only perspective commands must not require SQLite sidecar writes.",
    )
    database = tmp_path / "personal_decision_model.sqlite3"
    before_database = database.read_bytes()
    before_names = sorted(item.name for item in tmp_path.iterdir())
    original_mode = database.stat().st_mode
    database.chmod(stat.S_IREAD)
    try:
        _, packet = call(
            tmp_path,
            "perspective-packet",
            "--query",
            "read only perspective",
            "--max-sources",
            "1",
            "--max-chars",
            "6000",
        )
        _, health = call(tmp_path, "health")
        _, retrieval = call(tmp_path, "retrieve", "--query", "read only")
    finally:
        database.chmod(original_mode)

    assert packet["authority"] is False
    assert health["status"] == "healthy"
    assert retrieval["authority"] is False
    assert database.read_bytes() == before_database
    assert sorted(item.name for item in tmp_path.iterdir()) == before_names

    missing = tmp_path / "missing"
    failed, _ = call(missing, "health", ok=False)
    assert "read-only database missing" in failed.stderr
    assert not missing.exists()


def test_prediction_evaluation_exports_backup_and_health(tmp_path: Path) -> None:
    call(tmp_path, "init")
    call(
        tmp_path,
        "capture",
        "--event-id",
        "evt-seed",
        "--type",
        "observation",
        "--source-ref",
        "test:seed",
        "--summary",
        "seed",
    )
    payload = {
        "kind": "model_patch",
        "thesis": "Choose the next positive-benefit action under real boundaries.",
        "decision_procedure": ["recover parent result", "compare marginal benefit", "verify effect"],
        "self_update_policy": ["append evidence", "test predictions", "retain provenance"],
    }
    call(
        tmp_path,
        "propose",
        "--proposal-id",
        "proposal-model",
        "--type",
        "model_patch",
        "--source-event-id",
        "evt-seed",
        "--payload-json",
        json.dumps(payload),
    )
    _, promoted = call(
        tmp_path,
        "promote",
        "--proposal-id",
        "proposal-model",
        "--reason",
        "test seed",
        "--user-explicit",
    )
    model_id = promoted["model_version_id"]

    for index, choice in enumerate(("A", "B", "A"), start=1):
        prediction_id = f"prediction-{index}"
        call(
            tmp_path,
            "predict",
            "--prediction-id",
            prediction_id,
            "--model-version-id",
            model_id,
            "--scenario",
            f"scenario {index}",
            "--choice",
            choice,
            "--reasoning-json",
            '{"trace":["principle","case"]}',
            "--source-event-id",
            "evt-seed",
        )
        call(
            tmp_path,
            "record-outcome",
            "--prediction-id",
            prediction_id,
            "--actual-choice",
            choice,
            "--result",
            "matched",
            "--source-event-id",
            "evt-seed",
        )

    _, evaluation = call(
        tmp_path,
        "evaluate",
        "--model-version-id",
        model_id,
        "--dataset-ref",
        "test-held-out",
        "--source-event-id",
        "evt-seed",
        "--min-cases",
        "3",
        "--min-accuracy",
        "1.0",
    )
    assert evaluation["verdict"] == "pass"
    assert evaluation["metrics"]["accuracy"] == 1.0

    _, exported = call(tmp_path, "export", "--format", "txt")
    assert Path(exported["path"]).is_file()
    assert "原自指" in Path(exported["path"]).read_text(encoding="utf-8")
    _, graph = call(tmp_path, "graph-export")
    assert graph["row_count"] >= 2
    _, backup = call(tmp_path, "backup")
    assert Path(backup["path"]).is_file()
    _, health = call(tmp_path, "health")
    assert health["status"] == "healthy"
    assert health["quick_check"] == "ok"


def test_generation_trace_preserves_base_meta_case_and_decoding_failure(
    tmp_path: Path,
) -> None:
    _, initialized = call(tmp_path, "init")
    assert initialized["schema_version"] == 3
    for event_id, summary in (
        ("evt-base", "User defined why an observed wait is a problem."),
        ("evt-meta", "User defined problem formation as the meta-case."),
        ("evt-decode", "AI collapsed the meta subject into the visible example."),
    ):
        call(
            tmp_path,
            "capture",
            "--event-id",
            event_id,
            "--type",
            "correction",
            "--source-ref",
            f"test:{event_id}",
            "--summary",
            summary,
        )

    base = {
        "trace_key": "wait-base-case",
        "title": "A locally constructible edge was misclassified as external waiting",
        "domain": "continuous-supervision",
        "trace_kind": "problem_formation",
        "valid_from": "2026-07-23T00:00:00Z",
        "historical_anchors": ["event425", "event430"],
        "parent_result": "Continue the authorized mainline while positive-benefit local work exists.",
        "observed_state": "The controller entered waiting.",
        "problem_definition": "Waiting became a problem because an authorized local relay action remained constructible.",
        "violated_expectations": ["Local work must remain active."],
        "harms_or_burdens": ["Mainline progress stopped behind a false external prerequisite."],
        "active_constraints": ["Do not fabricate upstream capacity evidence."],
        "candidates": ["decompose the prerequisite", "keep waiting"],
        "counterfactuals": ["Without the local edge, waiting could be legitimate."],
        "decision": "Keep the local atom active and wait only on the external atom.",
        "result": "Machine consumer rejects the mixed prerequisite.",
        "feedback": ["Changed-context regression passes."],
        "assumption_updates": ["Status prose cannot establish externality."],
        "source_event_id": "evt-base",
    }
    _, recorded_base = call(
        tmp_path,
        "record-trace",
        "--payload-json",
        json.dumps(base),
    )
    assert recorded_base["trace_key"] == "wait-base-case"

    meta = {
        **base,
        "trace_key": "problem-formation-meta-case",
        "title": "How the user forms and defines a problem is first-class evidence",
        "trace_kind": "meta_case",
        "parent_trace_key": "wait-base-case",
        "historical_anchors": ["wait-base-case"],
        "observed_state": "AI focused on a visible technical symptom.",
        "problem_definition": "The reusable object is the user's problem-formation chain, not the symptom label.",
        "decision": "Preserve the base case and the typed meta-case.",
        "result": "Future retrieval can move from the example to the governing subject.",
        "source_event_id": "evt-meta",
    }
    call(
        tmp_path,
        "record-trace",
        "--payload-json",
        json.dumps(meta),
    )

    invalid_decode = {
        **meta,
        "trace_key": "invalid-decoding-failure",
        "trace_kind": "decoding_failure",
        "source_event_id": "evt-decode",
    }
    failed, _ = call(
        tmp_path,
        "record-trace",
        "--payload-json",
        json.dumps(invalid_decode),
        ok=False,
    )
    assert "decoding_failure requires" in failed.stderr

    decode = {
        **invalid_decode,
        "trace_key": "abstraction-collapse-failure",
        "parent_trace_key": "problem-formation-meta-case",
        "discourse_level_cues": ["更前置", "不是具体例子", "案例的案例"],
        "mistaken_subject": "How to recognize self-proving waiting.",
        "intended_subject": "How an observed state becomes defined by the user as a problem.",
        "correction": "Re-anchor the active subject one abstraction level upward.",
        "problem_definition": "The failure is loss of the user's generation chain through abstraction collapse.",
        "decision": "Keep the failed decode as negative evidence after the answer is corrected.",
        "result": "Later correctness does not erase the failed decoding trajectory.",
    }
    call(
        tmp_path,
        "record-trace",
        "--payload-json",
        json.dumps(decode),
    )

    _, explanation = call(
        tmp_path,
        "explain",
        "--query",
        "问题如何成立 更前置 案例的案例",
        "--limit",
        "5",
    )
    keys = {
        item["trace_key"] for item in explanation["relevant_decision_traces"]
    }
    assert "problem-formation-meta-case" in keys
    assert "abstraction-collapse-failure" in keys

    _, exported = call(tmp_path, "export", "--format", "json")
    exported_value = json.loads(Path(exported["path"]).read_text(encoding="utf-8"))
    assert exported_value["schema_version"] == "personal-decision-model.export.v3"
    assert len(exported_value["decision_traces"]) == 3

    rejected_base = {
        **base,
        "status": "rejected",
        "result": "This trace was later classified as task-only evidence.",
        "assumption_updates": [
            "High abstraction alone does not make task diagnosis personal metacognition."
        ],
    }
    call(
        tmp_path,
        "record-trace",
        "--payload-json",
        json.dumps(rejected_base),
    )
    _, after_rejection = call(
        tmp_path,
        "explain",
        "--query",
        "locally constructible edge external waiting",
        "--limit",
        "10",
    )
    assert "wait-base-case" not in {
        item["trace_key"]
        for item in after_rejection["relevant_decision_traces"]
    }

    db = sqlite3.connect(tmp_path / "personal_decision_model.sqlite3")
    try:
        with __import__("pytest").raises(sqlite3.IntegrityError, match="append-only"):
            db.execute(
                "UPDATE decision_trace_versions SET result='erased' WHERE trace_key='abstraction-collapse-failure'"
            )
    finally:
        db.close()


def test_user_perspective_packet_is_bounded_sourced_and_filters_bad_encoding(
    tmp_path: Path,
) -> None:
    call(tmp_path, "init")
    for event_id in ("evt-token-parent", "evt-bad-encoding"):
        call(
            tmp_path,
            "capture",
            "--event-id",
            event_id,
            "--type",
            "correction",
            "--source-ref",
            f"test:{event_id}",
            "--summary",
            event_id,
        )

    trace = {
        "trace_key": "token-parent-result-cross-window",
        "title": "Token research must change later-window behavior",
        "domain": "decision-to-productivity",
        "trace_kind": "decoding_failure",
        "valid_from": "2026-07-26T00:00:00Z",
        "historical_anchors": ["token-a-b", "fresh-window-probe"],
        "parent_result": "Future windows start from high-confidence token-efficient behavior without lowering reasoning or intent recognition.",
        "observed_state": "The engineering artifacts were green but later behavior remained cold.",
        "problem_definition": "Artifact closure substituted for the user's cross-window productivity result.",
        "violated_expectations": [
            "The user must not have to explain again why the research was requested."
        ],
        "harms_or_burdens": ["Repeated explanation and avoidable token burn."],
        "active_constraints": [
            "Do not lower model, reasoning, capabilities, evidence, or completion quality."
        ],
        "candidates": ["store a report", "land a bounded future-window consumer"],
        "counterfactuals": [
            "If future behavior does not change, the research did not settle its parent result."
        ],
        "decision": "Land a bounded pre-scope consumer and verify it in a changed context.",
        "result": "A future window selects the efficient organization without restating the case.",
        "feedback": ["Measure token, outer turns, rework, and user repetition."],
        "assumption_updates": ["The user's purpose statement carries the parent completion ruler."],
        "discourse_level_cues": ["研究有什么意义", "后续窗口"],
        "mistaken_subject": "Whether the analyzer and report were published.",
        "intended_subject": "Whether later AI behavior became productively token-aware.",
        "correction": "Connect the recorded decision to the live productivity consumer.",
        "source_event_id": "evt-token-parent",
    }
    call(tmp_path, "record-trace", "--payload-json", json.dumps(trace))

    corrupt = {
        **trace,
        "trace_key": "corrupt-token-anchor",
        "parent_result": "token efficiency \ufffd broken",
        "decision": "\ufffd",
        "source_event_id": "evt-bad-encoding",
    }
    call(tmp_path, "record-trace", "--payload-json", json.dumps(corrupt))

    completed, packet = call(
        tmp_path,
        "perspective-packet",
        "--query",
        "token future window productivity repeated explanation reasoning",
        "--max-sources",
        "3",
        "--max-chars",
        "6000",
    )
    assert packet["schema_version"] == "personal-decision-model.user-perspective-packet.v2"
    assert packet["inferred_parent_result"]["source"]["source_id"] == "token-parent-result-cross-window"
    assert packet["expected_owner_choice"]["text"].startswith("Land a bounded pre-scope consumer")
    assert packet["burdens"][0]["text"] == "Repeated explanation and avoidable token burn."
    assert packet["hard_constraints"][0]["text"].startswith("Do not lower model")
    assert packet["retrieval_stats"]["skipped_unusable_encoding"] >= 1
    assert packet["budget"]["serialized_chars"] <= packet["budget"]["max_chars"]
    assert len(completed.stdout.strip()) <= packet["budget"]["max_chars"]
    assert packet["consumer_contract"]["current_user_statement_precedence"] is True
    assert packet["authority"] is False
    assert packet["completion_claim_allowed"] is False
    assert "_json" not in completed.stdout

    schema = json.loads(PERSPECTIVE_SCHEMA.read_text(encoding="utf-8"))
    Draft202012Validator(schema).validate(packet)


def test_correction_shaping_hotspots_are_soft_contextual_and_time_sensitive(
    tmp_path: Path,
) -> None:
    call(tmp_path, "init")
    call(
        tmp_path,
        "capture",
        "--event-id",
        "evt-disk-correction-1",
        "--type",
        "correction",
        "--source-ref",
        "test:disk-correction-1",
        "--summary",
        "Stop the active harm before turning the incident into governance.",
    )
    trace = {
        "trace_key": "disk-incident-user-correction",
        "title": "Growing local resource incident",
        "domain": "local-operations",
        "trace_kind": "decoding_failure",
        "valid_from": "2026-01-01T00:00:00Z",
        "historical_anchors": ["test:disk-correction-1"],
        "parent_result": "Stop a live resource loss and restore the real consumer.",
        "observed_state": "Capacity continued falling while the assistant proposed a broad audit.",
        "problem_definition": "A live incident was converted into a conservative governance exercise.",
        "violated_expectations": ["Do not return the incident burden to the user."],
        "harms_or_burdens": ["The machine keeps losing usable capacity."],
        "active_constraints": ["Identify destructive targets exactly before deletion."],
        "candidates": ["stop the located writer", "write an audit plan"],
        "counterfactuals": ["A historical read-only review has no live writer to stop."],
        "decision": "Stop the already identified active writer, then repair and reverify.",
        "result": "Pending changed-surface reuse.",
        "feedback": ["Apply only while harm is actively expanding."],
        "assumption_updates": ["High urgency does not grant broad deletion authority."],
        "discourse_level_cues": ["空间还在下降", "先停止真实写入源"],
        "mistaken_subject": "Whether a complete governance audit existed.",
        "intended_subject": "Whether the active capacity loss was stopped.",
        "correction": "Cut the live harm first without inventing a broad approval workflow.",
        "source_event_id": "evt-disk-correction-1",
    }
    call(tmp_path, "record-trace", "--payload-json", json.dumps(trace))
    card = {
        "card_key": "live-resource-harm-first",
        "title": "Live resource harm before governance",
        "domain": "local resource incident storage disk capacity writer logs",
        "valid_from": "2026-01-01T00:00:00Z",
        "trigger_contexts": [
            "A local resource incident is actively expanding and the damaging source is located."
        ],
        "activation_terms": [
            "系统盘 容量 缩水 后台 日志 持续 写入 磁盘 空间 增长"
        ],
        "default_tendency": "Stop the located live writer, then diagnose, repair, and reverify the consumer.",
        "suppressed_tendencies": [
            "Convert the incident into a broad audit or approval workflow before stopping harm."
        ],
        "applicability_bounds": [
            "The harm is live and the active source has a precise identity.",
            "Destructive cleanup still requires exact targets and recoverability checks."
        ],
        "suppression_contexts": [
            "只读 审计 历史 报告 没有 活动 写入 无 实时 损害"
        ],
        "counterexamples": [
            "A read-only historical review with no active writer must not stop unrelated processes."
        ],
        "episode_trace_keys": ["disk-incident-user-correction"],
        "evidence_event_ids": ["evt-disk-correction-1"],
        "salience": 0.95,
        "confidence": 0.8,
        "recurrence_count": 1,
        "last_confirmed_at": "2026-01-01T00:00:00Z",
        "decay_half_life_days": 30,
        "source_event_id": "evt-disk-correction-1",
    }
    _, recorded = call(
        tmp_path,
        "record-shaping-card",
        "--payload-json",
        json.dumps(card),
    )
    assert recorded["authority"] is False

    _, fresh = call(
        tmp_path,
        "perspective-packet",
        "--query",
        "系统盘容量不断缩水，后台还在产生日志",
        "--as-of",
        "2026-01-02T00:00:00Z",
        "--max-chars",
        "6000",
    )
    assert fresh["shaping_hotspots"][0]["card_id"] == "live-resource-harm-first"
    assert fresh["shaping_hotspots"][0]["episode"]["trace_id"] == "disk-incident-user-correction"
    assert fresh["shaping_hotspots"][0]["authority"] is False
    assert fresh["consumer_contract"]["activation_is_not_authority"] is True
    assert fresh["consumer_contract"]["apply_hotspots_before_candidate_ranking"] is True

    shaping_input = {
        "scenario": "系统盘容量不断缩水，后台还在产生日志",
        "as_of": "2026-01-02T00:00:00Z",
        "candidates": [
            {
                "candidate_id": "governance_first",
                "text": "Begin a broad audit and approval workflow before touching the writer.",
            },
            {
                "candidate_id": "stop_writer",
                "text": "Stop the located live writer, then diagnose and reverify the consumer.",
            },
        ],
    }
    _, shaped = call(
        tmp_path,
        "shape-candidates",
        "--payload-json",
        json.dumps(shaping_input),
    )
    # Fail-open: natural-language direction does not auto-reorder.
    assert shaped["ranking_status"] == "abstained_directional_ambiguity"
    assert shaped["ranking_changed"] is False
    assert shaped["candidate_set_preserved"] is True
    assert [row["candidate_id"] for row in shaped["ranked_candidates"]] == [
        "governance_first",
        "stop_writer",
    ]
    assert all(row["soft_delta"] == 0.0 for row in shaped["ranked_candidates"])
    assert shaped["applied_cards"] == []
    assert shaped["authority"] is False
    assert any(
        item["card_id"] == "live-resource-harm-first"
        for item in shaped["active_direction_context"]
    )
    for item in shaped["active_direction_context"]:
        assert item["authority"] is False
        assert set(item.keys()) == {
            "card_id",
            "activation_score",
            "default_tendency",
            "suppressed_tendencies",
            "applicability_bounds",
            "source_refs",
            "authority",
        }

    _, explicit = call(
        tmp_path,
        "shape-candidates",
        "--payload-json",
        json.dumps({**shaping_input, "explicit_choice_id": "governance_first"}),
    )
    assert explicit["hard_override"] == "explicit_choice"
    assert explicit["ranking_status"] == "hard_override_explicit_choice"
    assert explicit["ranked_candidates"][0]["candidate_id"] == "governance_first"
    assert explicit["applied_cards"] == []
    assert explicit["active_direction_context"] == []

    _, stopped = call(
        tmp_path,
        "shape-candidates",
        "--payload-json",
        json.dumps({**shaping_input, "stop": True}),
    )
    assert stopped["hard_override"] == "stop"
    assert stopped["ranking_status"] == "hard_override_stop"
    assert stopped["ranked_candidates"] == []
    assert stopped["active_direction_context"] == []
    assert stopped["authority"] is False

    call(
        tmp_path,
        "capture",
        "--event-id",
        "evt-disk-correction-2",
        "--type",
        "correction",
        "--source-ref",
        "test:disk-correction-2",
        "--summary",
        "The same correction recurred in a changed surface.",
    )
    reinforced_card = {
        **card,
        "evidence_event_ids": ["evt-disk-correction-1", "evt-disk-correction-2"],
        "recurrence_count": 4,
        "last_confirmed_at": "2026-01-03T00:00:00Z",
        "source_event_id": "evt-disk-correction-2",
    }
    call(
        tmp_path,
        "record-shaping-card",
        "--payload-json",
        json.dumps(reinforced_card),
    )
    _, reinforced = call(
        tmp_path,
        "perspective-packet",
        "--query",
        "系统盘容量不断缩水，后台还在产生日志",
        "--as-of",
        "2026-01-04T00:00:00Z",
        "--max-chars",
        "6000",
    )
    assert reinforced["shaping_hotspots"][0]["activation"]["recurrence_count"] == 4
    assert (
        reinforced["shaping_hotspots"][0]["activation"]["score"]
        > fresh["shaping_hotspots"][0]["activation"]["score"]
    )

    _, stale = call(
        tmp_path,
        "perspective-packet",
        "--query",
        "系统盘容量不断缩水，后台还在产生日志",
        "--as-of",
        "2027-01-01T00:00:00Z",
        "--max-chars",
        "6000",
    )
    assert (
        stale["shaping_hotspots"][0]["activation"]["score"]
        < reinforced["shaping_hotspots"][0]["activation"]["score"]
    )

    _, suppressed = call(
        tmp_path,
        "perspective-packet",
        "--query",
        "只读审计历史磁盘报告，没有活动写入也没有实时损害",
        "--as-of",
        "2026-01-02T00:00:00Z",
        "--max-chars",
        "6000",
    )
    assert not suppressed["shaping_hotspots"]
    assert suppressed["shaping_suppressions"][0]["card_id"] == "live-resource-harm-first"
    assert suppressed["shaping_suppressions"][0]["authority"] is False

    _, suppressed_shaping = call(
        tmp_path,
        "shape-candidates",
        "--payload-json",
        json.dumps(
            {
                **shaping_input,
                "scenario": "只读审计历史磁盘报告，没有活动写入也没有实时损害",
            }
        ),
    )
    assert suppressed_shaping["ranking_changed"] is False
    assert suppressed_shaping["applied_cards"] == []
    assert suppressed_shaping["suppressed_cards"][0]["card_id"] == "live-resource-harm-first"

    schema = json.loads(PERSPECTIVE_SCHEMA.read_text(encoding="utf-8"))
    Draft202012Validator(schema).validate(fresh)
    Draft202012Validator(schema).validate(suppressed)


def test_candidate_direction_excludes_trigger_terms_from_positive_scoring(
    tmp_path: Path,
) -> None:
    call(tmp_path, "init")
    call(
        tmp_path,
        "capture",
        "--event-id",
        "evt-owner-posture",
        "--type",
        "correction",
        "--source-ref",
        "test:owner-posture",
        "--summary",
        "An established parent scope must not reset at each window or phase.",
    )
    trace = {
        "trace_key": "owner-posture-phase-reset",
        "title": "Phase boundaries reset scoped delegation",
        "domain": "cross-domain agent behavior",
        "trace_kind": "decision",
        "valid_from": "2026-08-05T00:00:00Z",
        "parent_result": "Continue the surviving entrusted effect scope without displacing its cognition owner.",
        "observed_state": "The assistant asks for approval at each internal phase.",
        "problem_definition": "A lifecycle label is mistaken for an authority boundary.",
        "decision": "Preserve scoped delegation and continue reversible work.",
        "result": "Pending regression.",
        "source_event_id": "evt-owner-posture",
    }
    call(tmp_path, "record-trace", "--payload-json", json.dumps(trace))
    card = {
        "card_key": "owner-posture",
        "title": "User-side technical Owner",
        "domain": "cross-domain task execution behavior",
        "valid_from": "2026-08-05T00:00:00Z",
        "trigger_contexts": [
            "新窗口或 compact 恢复未完成父任务",
            "局部子项或工程阶段刚完成",
            "计划或包要求再次 human approval",
        ],
        "activation_terms": [
            "默认无授权 用户侧技术 Owner 每进入一个新阶段等待用户批准 窗口启动 持续委托 阶段边界"
        ],
        "default_tendency": "先由当前话语、稳定入口和 live facts 恢复仍存活父任务与作用域；以用户侧技术 Owner 承担其中可推导、可逆、可验证的认知和工程链，跨窗口、子项和阶段继续。",
        "suppressed_tendencies": [
            "把窗口或阶段边界当成授权清零",
            "禁止进入迁移验证阶段时等待批准",
        ],
        "applicability_bounds": [
            "当前话语和 live facts 证明父任务仍存活",
        ],
        "episode_trace_keys": ["owner-posture-phase-reset"],
        "evidence_event_ids": ["evt-owner-posture"],
        "salience": 1.0,
        "confidence": 0.99,
        "recurrence_count": 1,
        "last_confirmed_at": "2026-08-05T00:00:00Z",
        "decay_half_life_days": 365,
        "source_event_id": "evt-owner-posture",
    }
    call(tmp_path, "record-shaping-card", "--payload-json", json.dumps(card))

    _, shaped = call(
        tmp_path,
        "shape-candidates",
        "--payload-json",
        json.dumps(
            {
                "scenario": "Codex 默认主体姿态与分散认知能力如何汇入当前行为；随后继续配置、迁移和原生任务",
                "as_of": "2026-08-05T01:00:00Z",
                "candidates": [
                    {
                        "candidate_id": "per_phase_user_approval",
                        "text": "每进入配置、迁移、激活或原生验证阶段都等待用户批准",
                    },
                    {
                        "candidate_id": "integrated_existing_consumers",
                        "text": "在现有热核、Hook、行为/人的视角/代运维/验证/决策 Skills 与回归中建立用户侧技术 Owner 默认姿态，最薄约束加动态探索，然后继续父任务",
                    },
                ],
            }
        ),
    )
    # Directional scoring abstains: input order preserved, soft_delta zero.
    assert shaped["ranking_status"] == "abstained_directional_ambiguity"
    assert shaped["ranking_changed"] is False
    assert [row["candidate_id"] for row in shaped["ranked_candidates"]] == [
        "per_phase_user_approval",
        "integrated_existing_consumers",
    ]
    assert all(row["soft_delta"] == 0.0 for row in shaped["ranked_candidates"])
    assert shaped["applied_cards"] == []
    assert shaped["authority"] is False
    assert shaped["active_direction_context"]
    assert all(item["authority"] is False for item in shaped["active_direction_context"])


def _seed_dual_axis_shaping_cards(tmp_path: Path, event_id: str) -> None:
    """Two coordinating cards: effect continuity + independent cognition / role adoption."""
    call(tmp_path, "init")
    call(
        tmp_path,
        "capture",
        "--event-id",
        event_id,
        "--type",
        "correction",
        "--source-ref",
        f"test:{event_id}",
        "--summary",
        "Effect ownership stays continuous; separable cognition stays independent and role-adopted.",
    )
    cards = [
        (
            "user-side-technical-owner",
            "User-side technical Owner continuity",
            (
                "先由当前话语和 live facts 恢复仍存活父任务；"
                "以用户侧技术 effect Owner 跨窗口继续承担可推导、可逆、可验证的工程与共享效果；"
                "不接管另一个 world-owning Sol 的领域认识。"
            ),
            ["把窗口边界当成授权清零", "让用户逐阶段批准"],
        ),
        (
            "independent-worker-before-closure",
            "Independent worker before high-leverage closure",
            (
                "在当前 cognition subject 封闭首个候选前，先把可分离的未知、反例攻击交给结论开放的异质工人完整独立生产；"
                "认识候选回到 cognition subject，正式共享写入和终验回到 effect Owner。"
            ),
            ["先写出答案再让多个工人同意", "把采用写入终验交给工人接管"],
        ),
    ]
    for index, (card_key, title, default_tendency, suppressed) in enumerate(cards):
        call(
            tmp_path,
            "record-trace",
            "--payload-json",
            json.dumps(
                {
                    "trace_key": f"trace-{card_key}",
                    "title": title,
                    "domain": "cross-domain agent behavior",
                    "trace_kind": "decision",
                    "valid_from": "2026-08-06T00:00:00Z",
                    "parent_result": "Keep independent cognition, epistemic adoption, and formal effects distinct.",
                    "observed_state": "Lexical ranking confused partial role language with full policy.",
                    "problem_definition": "Bag-of-tokens matched one half of a multi-clause card.",
                    "decision": default_tendency,
                    "result": "Pending regression.",
                    "source_event_id": event_id,
                }
            ),
        )
        call(
            tmp_path,
            "record-shaping-card",
            "--payload-json",
            json.dumps(
                {
                    "card_key": card_key,
                    "title": title,
                    "domain": "cross-domain task execution behavior",
                    "valid_from": "2026-08-06T00:00:00Z",
                    "trigger_contexts": [
                        "Decision Skill shaping cards correctly activated but ranking is wrong",
                        "Current role continues a live parent task with worker and consumption choices",
                        "主管必须亲自下场查看验收",
                        "不能变成主管包办",
                        "不能由工人接管而主管只做中介",
                    ],
                    "activation_terms": [
                        "effect Owner 继续 父任务 shaping 消费 工人 异质 修复 cognition 采用 终验 主管 验收"
                    ],
                    "default_tendency": default_tendency,
                    "suppressed_tendencies": suppressed,
                    "applicability_bounds": [
                        "Current parent remains live and authorized",
                        "Does not force dispatch on inseparable tight-coupled work",
                    ],
                    "episode_trace_keys": [f"trace-{card_key}"],
                    "evidence_event_ids": [event_id],
                    "salience": 1.0,
                    "confidence": 0.99,
                    "recurrence_count": 1 + index,
                    "last_confirmed_at": "2026-08-06T00:00:00Z",
                    "decay_half_life_days": 365,
                    "source_event_id": event_id,
                }
            ),
        )


def _shape_order(tmp_path: Path, scenario: str, candidates: list[dict[str, str]]) -> dict:
    _, shaped = call(
        tmp_path,
        "shape-candidates",
        "--payload-json",
        json.dumps(
            {
                "scenario": scenario,
                "as_of": "2026-08-06T01:00:00Z",
                "candidates": candidates,
            }
        ),
    )
    return shaped


def _assert_exact_input_order(shaped: dict, expected_ids: list[str]) -> None:
    order = [row["candidate_id"] for row in shaped["ranked_candidates"]]
    assert order == expected_ids
    assert shaped["original_order"] == expected_ids
    assert shaped["ranking_changed"] is False
    assert shaped["candidate_set_preserved"] is True
    assert shaped["authority"] is False
    assert shaped["completion_claim_allowed"] is False
    assert shaped["ranking_status"] == "abstained_directional_ambiguity"
    assert shaped["hard_override"] is None
    assert shaped["applied_cards"] == []
    assert all(row["soft_delta"] == 0.0 for row in shaped["ranked_candidates"])
    assert all(row["applied_card_ids"] == [] for row in shaped["ranked_candidates"])
    for item in shaped["active_direction_context"]:
        assert item["authority"] is False
        assert set(item.keys()) == {
            "card_id",
            "activation_score",
            "default_tendency",
            "suppressed_tendencies",
            "applicability_bounds",
            "source_refs",
            "authority",
        }
        refs = item["source_refs"]
        assert set(refs.keys()) == {
            "source_event_id",
            "evidence_event_ids",
            "episode_trace_keys",
        }
        # No secret-like payloads in bounded context.
        blob = json.dumps(item, ensure_ascii=False)
        assert "sk-" not in blob
        assert "password" not in blob.lower()
        assert "api_key" not in blob.lower()
        assert "\x00" not in blob


def test_owner_fp_any_input_permutation_exact_no_reorder(tmp_path: Path) -> None:
    """Original owner false-positive set: every input order is preserved exactly."""
    _seed_dual_axis_shaping_cards(tmp_path, "evt-owner-fp-perm")
    scenario = (
        "Decision Skill 已有正确 shaping cards；shape-candidates 后 "
        "owner_does_all_work 与 worker_takeover 被半句角色词误加正分，"
        "需要在存活父任务内继续：修复消费、完整工人生产，还是 Owner 包办/工人接管。"
    )
    base = [
        {
            "candidate_id": "owner_does_all_work",
            "text": (
                "主管亲临：effect Owner 借跨窗口连续性接管存活父任务中的全部领域认知和工程链，"
                "平行生成 world-owning Sol 的答案并独占认识采用、写入和终验；不把可分离工作交给适配角色。"
            ),
        },
        {
            "candidate_id": "repair_consumption_and_continue",
            "text": (
                "先修复 shape-candidates 的方向匹配，避免正确 shaping cards "
                "因词项相似给错误候选加正分；修好消费后继续父任务，"
                "并在高杠杆未知上保留异质工人完整独立生产；cognition subject 采用认识，effect Owner 只独占正式写入与终验。"
            ),
        },
        {
            "candidate_id": "worker_takeover",
            "text": (
                "工人完整生产并接管认识采用、写入、终验与父任务继续，"
                "cognition subject 与 effect Owner 都只做中介。"
            ),
        },
        {
            "candidate_id": "add_more_memory_rules",
            "text": "把纠偏再写成更多记忆、L0 与正式规则，期望下次自动正确。",
        },
    ]
    permutations = [
        base,
        [base[1], base[0], base[3], base[2]],
        [base[2], base[3], base[0], base[1]],
        list(reversed(base)),
    ]
    for candidates in permutations:
        expected = [row["candidate_id"] for row in candidates]
        shaped = _shape_order(tmp_path, scenario, candidates)
        _assert_exact_input_order(shaped, expected)
        assert shaped["active_direction_context"]


def test_directional_heldout_cases_exact_no_reorder(tmp_path: Path) -> None:
    """dual/owner/takeover/fixed, quote attack, double negation, unique padding: no reorder."""
    _seed_dual_axis_shaping_cards(tmp_path, "evt-heldout-no-reorder")
    scenario = (
        "主管必须亲自下场查看验收，但不能变成主管包办，"
        "也不能由工人接管而主管只做中介"
    )
    pad = "无关填充字样。" * 24
    candidates = [
        {
            "candidate_id": "fixed_fanout",
            "text": "固定派3个工人并行。",
        },
        {
            "candidate_id": "dual_track",
            "text": (
                "可分离未知交给结论开放的异质工人完整独立生产；"
                "cognition subject 亲自接触领域现实并采用认识，effect Owner 亲自查看共享效果验收；"
                "不把任一采用权交给工人，也不由主管包办全部可分离认知。"
            ),
        },
        {
            "candidate_id": "worker_takeover",
            "text": "工人完整生产并接管认识采用、写入、终验；两个当前责任角色都只做中介转发。",
        },
        {
            "candidate_id": "owner_all",
            "text": "effect Owner 亲自包办 world-owning Sol 的全部领域认知和工程链，不保留角色边界。",
        },
        {
            "candidate_id": "quote_attack",
            "text": (
                '用户说"不要让工人接管采用"，但实际让工人接管认识采用、写入和终验，'
                "当前责任角色只做中介。"
            ),
        },
        {
            "candidate_id": "double_negation",
            "text": "不能不让工人接管认识采用、写入与终验；当前责任角色不再接触自己的真实对象。",
        },
        {
            "candidate_id": "unique_padding",
            "text": (
                "可分离未知交给结论开放的异质工人完整独立生产；"
                "cognition subject 采用认识；effect Owner 采用并验证共享效果。" + pad
            ),
        },
    ]
    expected = [row["candidate_id"] for row in candidates]
    shaped = _shape_order(tmp_path, scenario, candidates)
    _assert_exact_input_order(shaped, expected)
    # Any permutation of the same set also preserves order.
    reshuffled = [
        candidates[3],
        candidates[5],
        candidates[0],
        candidates[6],
        candidates[1],
        candidates[4],
        candidates[2],
    ]
    reshuffled_ids = [row["candidate_id"] for row in reshuffled]
    reshaped = _shape_order(tmp_path, scenario, reshuffled)
    _assert_exact_input_order(reshaped, reshuffled_ids)


def test_stop_empty_context_and_explicit_choice_still_first(tmp_path: Path) -> None:
    _seed_dual_axis_shaping_cards(tmp_path, "evt-hard-override")
    candidates = [
        {"candidate_id": "a", "text": "first option that is not the explicit choice"},
        {"candidate_id": "b", "text": "second option chosen explicitly by Owner"},
        {"candidate_id": "c", "text": "third option"},
    ]
    _, stopped = call(
        tmp_path,
        "shape-candidates",
        "--payload-json",
        json.dumps(
            {
                "scenario": "主管必须亲自下场查看验收",
                "as_of": "2026-08-06T01:00:00Z",
                "candidates": candidates,
                "stop": True,
            }
        ),
    )
    assert stopped["hard_override"] == "stop"
    assert stopped["ranking_status"] == "hard_override_stop"
    assert stopped["ranked_candidates"] == []
    assert stopped["active_direction_context"] == []
    assert stopped["applied_cards"] == []
    assert stopped["suppressed_cards"] == []
    assert stopped["authority"] is False
    assert stopped["completion_claim_allowed"] is False

    _, explicit = call(
        tmp_path,
        "shape-candidates",
        "--payload-json",
        json.dumps(
            {
                "scenario": "主管必须亲自下场查看验收",
                "as_of": "2026-08-06T01:00:00Z",
                "candidates": candidates,
                "explicit_choice_id": "b",
            }
        ),
    )
    assert explicit["hard_override"] == "explicit_choice"
    assert explicit["ranking_status"] == "hard_override_explicit_choice"
    assert [row["candidate_id"] for row in explicit["ranked_candidates"]] == [
        "b",
        "a",
        "c",
    ]
    assert explicit["ranked_candidates"][0]["candidate_id"] == "b"
    assert explicit["active_direction_context"] == []
    assert explicit["applied_cards"] == []
    assert explicit["authority"] is False
    assert all(row["soft_delta"] == 0.0 for row in explicit["ranked_candidates"])


def test_active_direction_context_bounded_no_secret_authority_false(
    tmp_path: Path,
) -> None:
    _seed_dual_axis_shaping_cards(tmp_path, "evt-context-bound")
    shaped = _shape_order(
        tmp_path,
        "Decision Skill shaping cards; Owner continues with worker choices",
        [
            {"candidate_id": "x", "text": "continue with current Owner frame"},
            {"candidate_id": "y", "text": "stop and ask the user"},
        ],
    )
    _assert_exact_input_order(shaped, ["x", "y"])
    assert shaped["active_direction_context"]
    for item in shaped["active_direction_context"]:
        assert item["authority"] is False
        assert isinstance(item["activation_score"], float)
        assert item["activation_score"] >= 0.0
        assert isinstance(item["default_tendency"], str)
        assert len(item["default_tendency"]) <= 180
        assert len(item["suppressed_tendencies"]) <= 3
        assert len(item["applicability_bounds"]) <= 3
        for text in item["suppressed_tendencies"] + item["applicability_bounds"]:
            assert len(text) <= 180
        refs = item["source_refs"]
        assert len(refs["evidence_event_ids"]) <= 5
        assert len(refs["episode_trace_keys"]) <= 3
        # Only identity refs, not free-form secret payloads.
        for event_id in refs["evidence_event_ids"]:
            assert isinstance(event_id, str)
            assert len(event_id) < 200
            assert " " not in event_id or event_id.startswith("evt")


def test_replay_eval_is_dataset_scoped_and_idempotent(tmp_path: Path) -> None:
    call(tmp_path, "init")
    call(
        tmp_path,
        "capture",
        "--event-id",
        "evt-seed",
        "--type",
        "observation",
        "--source-ref",
        "test:seed",
        "--summary",
        "seed",
    )
    call(
        tmp_path,
        "propose",
        "--proposal-id",
        "proposal-model",
        "--type",
        "model_patch",
        "--source-event-id",
        "evt-seed",
        "--payload-json",
        json.dumps(
            {
                "kind": "model_patch",
                "thesis": "Choose positive benefit under hard boundaries.",
                "decision_procedure": ["recover parent result", "compare choices"],
                "self_update_policy": ["append evidence", "replay held-out cases"],
            }
        ),
    )
    _, promoted = call(
        tmp_path,
        "promote",
        "--proposal-id",
        "proposal-model",
        "--reason",
        "test seed",
        "--user-explicit",
    )
    fixture = {
        "dataset_ref": "cross-case-v1",
        "model_version_id": promoted["model_version_id"],
        "source_event": {
            "event_id": "evt-replay",
            "event_type": "observation",
            "occurred_at": "2026-07-23T00:00:00Z",
            "source_kind": "owner_replay",
            "source_ref": "test:cross-case-v1",
            "summary": "Cross-case replay fixture",
            "payload": {"authority": False},
        },
        "cases": [
            {
                "scenario_id": f"case-{index}",
                "scenario": f"scenario {index}",
                "predicted_choice": choice,
                "actual_choice": choice,
                "reasoning": {"principles": ["dynamic-net-benefit"]},
                "confidence": 0.9,
                "result": "matched explicit historical choice",
            }
            for index, choice in enumerate(("A", "B", "A", "C", "B"), start=1)
        ],
    }
    fixture_path = tmp_path / "cross_case.json"
    fixture_path.write_text(json.dumps(fixture), encoding="utf-8")

    _, first = call(
        tmp_path,
        "replay-eval",
        "--file",
        str(fixture_path),
        "--min-cases",
        "5",
        "--min-accuracy",
        "1.0",
    )
    _, second = call(
        tmp_path,
        "replay-eval",
        "--file",
        str(fixture_path),
        "--min-cases",
        "5",
        "--min-accuracy",
        "1.0",
    )
    assert first["status"] == "evaluated"
    assert second["status"] == "already_evaluated"
    assert first["evaluation_id"] == second["evaluation_id"]
    assert first["metrics"]["total"] == 5
    assert first["metrics"]["accuracy"] == 1.0

    db = sqlite3.connect(tmp_path / "personal_decision_model.sqlite3")
    try:
        assert db.execute("SELECT COUNT(*) FROM predictions").fetchone()[0] == 5
        assert db.execute("SELECT COUNT(*) FROM outcomes").fetchone()[0] == 5
        assert db.execute("SELECT COUNT(*) FROM evaluations").fetchone()[0] == 1
    finally:
        db.close()


def test_task_stack_restores_exact_parent_without_polluting_personal_model(
    tmp_path: Path,
) -> None:
    call(tmp_path, "init")
    frame = {
        "frame_id": "decision-parent-interrupt-1",
        "parent_task_id": "decision-window-generation-chain",
        "window_role": "decision_window",
        "parent_goal": "Finish the generation-chain decision model upgrade.",
        "completed_do_not_reopen": [
            "api cognitive entry",
            "module operations notes",
            "personal decision model v1",
        ],
        "pending": [
            "publish decision trace v2",
            "finish behavior regression",
        ],
        "next_step": "Resume the decision trace publication review.",
        "inserted_child_id": "repair-subject-scope",
        "return_to": "decision trace publication review",
        "source_heads": {
            "branch": "codex/meaningful-choice",
            "commit": "abc123",
        },
        "explicit_exclusions": [
            "do not adopt mainline event433",
            "do not reopen completed API work",
        ],
    }
    _, suspended = call(
        tmp_path,
        "suspend-task",
        "--payload-json",
        json.dumps(frame),
    )
    assert suspended["status"] == "suspended"
    digest = suspended["frame"]["parent_state_sha256"]
    assert suspended["depth"] == 1

    _, replayed = call(
        tmp_path,
        "suspend-task",
        "--payload-json",
        json.dumps(frame),
    )
    assert replayed["status"] == "already_suspended"
    assert replayed["frame"]["parent_state_sha256"] == digest

    failed, _ = call(
        tmp_path,
        "resume-task",
        "--frame-id",
        frame["frame_id"],
        "--parent-task-id",
        "mainline-event433",
        "--window-role",
        "mainline_owner",
        "--expected-parent-state-sha256",
        digest,
        "--child-status",
        "verified",
        ok=False,
    )
    assert "task frame identity mismatch" in failed.stderr
    _, still_active = call(tmp_path, "peek-task")
    assert still_active["status"] == "active"
    assert still_active["top"]["parent_task_id"] == frame["parent_task_id"]

    _, resumed = call(
        tmp_path,
        "resume-task",
        "--frame-id",
        frame["frame_id"],
        "--parent-task-id",
        frame["parent_task_id"],
        "--window-role",
        frame["window_role"],
        "--expected-parent-state-sha256",
        digest,
        "--child-status",
        "verified",
        "--child-result-ref",
        "test:subject-scope-regression",
    )
    assert resumed["status"] == "resumed"
    assert resumed["depth"] == 0
    assert resumed["resume_state"]["pending"] == frame["pending"]
    assert (
        resumed["resume_state"]["completed_do_not_reopen"]
        == frame["completed_do_not_reopen"]
    )
    assert resumed["resume_state"]["return_to"] == frame["return_to"]

    _, idempotent = call(
        tmp_path,
        "resume-task",
        "--frame-id",
        frame["frame_id"],
        "--parent-task-id",
        frame["parent_task_id"],
        "--window-role",
        frame["window_role"],
        "--expected-parent-state-sha256",
        digest,
        "--child-status",
        "verified",
    )
    assert idempotent["status"] == "already_resumed"

    _, health = call(tmp_path, "health")
    assert health["status"] == "healthy"
    assert health["task_stack"]["active_frames"] == 0
    assert health["task_stack"]["resume_history"] == 1
    _, exported = call(tmp_path, "export", "--format", "json")
    model_export = json.loads(Path(exported["path"]).read_text(encoding="utf-8"))
    assert "task_stack" not in model_export
    assert "active_frames" not in model_export
