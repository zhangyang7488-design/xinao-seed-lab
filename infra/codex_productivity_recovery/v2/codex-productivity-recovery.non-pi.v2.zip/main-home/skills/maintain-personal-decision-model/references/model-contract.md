# Personal decision model contract

## Object and storage boundaries

- Authoritative personal-model fact source: `D:\XINAO_RESEARCH_RUNTIME\state\personal_decision_model\personal_decision_model.sqlite3`.
- Stable runtime pointer: `D:\XINAO_RESEARCH_RUNTIME\tools\personal-decision-model\current.json`.
- Optional runtime release: the `release_root` named by that pointer.
- Replaceable access skill: `C:\Users\xx363\.codex\skills\maintain-personal-decision-model`.
- Stable CLI: `C:\Users\xx363\CodexLaunchers\Invoke-PersonalDecisionModel.ps1`.
- Human exports: the data root's `exports` directory and the explicitly published archive projection.
- Short-term interruption stack: `D:\XINAO_RESEARCH_RUNTIME\state\personal_decision_model\task_stack.v1.json`,
  governed by `task-interruption-frame.v1.schema.json`.

Deleting the skill, optional runtime, Graphiti projection, viewer, or one provider must not delete or reinterpret SQLite. Deleting the data requires a separate explicit data-deletion instruction.

The interruption stack is not part of SQLite personal truth. It is a non-authority, atomically
replaced, cross-process-locked LIFO recovery surface for an unfinished parent task displaced by an
inserted child. A frame binds parent task identity, window role, completed-do-not-reopen and pending
sets, exact next step, child identity, return point, source heads, exclusions, and a canonical
parent-state hash. Exact replay is idempotent; wrong parent, role, hash, or non-top resume fails
without mutation. Resume history remains auditable, while model exports and retrieval exclude all
task-frame contents.

## Current intent graph consumer boundary

The durable model does not own the current intent graph. Current user words, current object facts,
authorization, and Stop bind the live frame. A perspective packet may contribute sourced candidates
for the human-practice, parent-result, burden, constraint, counterfactual, and level-shift portions of
the current relation slice, but the currently appointed cognition or effect role must revalidate and connect them to the active object,
admissible approach, responsibility, runtime carrier, and real consumer effect. Empty fields, stale
anchors, or a superficially related hotspot remain evidence about retrieval quality; they do not
freeze or block the live task.

Ordinary turns must not export, traverse, or inject the whole graph/database. Use bounded retrieval
before a material strategy choice, and materialize a structured current frame only for evaluation,
handoff, consequential effects, or a real ambiguity. This keeps personal continuity effective without
turning it into prompt bulk, authority, or a second planner.

## Fact model

Raw facts are append-only `events`. Decision traces, shaping cards, cases, principles, relations, model versions,
proposals, proposal decisions, predictions, outcomes, and evaluations are append-only or versioned
facts with update/delete triggers. Search indexes and exports are derived and rebuildable.

Every durable item binds a source event. A material metacognitive statement is preserved as an event
by semantic content without requiring an extra `remember` or `make this a rule` phrase. As a
first-person fact it establishes that the user understands their decision core this way; sparse case
support limits only the scope and confidence of derived generalizations, not the existence of the
self-report. The event, its conditional proposal, evaluation, and promoted principle are separate
facts. The AI owns downstream case gathering and rule engineering so the user is not forced into a
recursive meta-metacognitive proof burden. A correction can become a candidate proposal immediately,
but it becomes a promoted current model only after a passing evaluation or an explicit stable user
correction. Old facts and originating metacognition are superseded through new versions; they are
not overwritten.

The generated Pydantic/JSON Schema contract is `personal-decision-model.v3.schema.json`. Schema
changes require a new migration, a backup, positive/negative tests, fresh health output, and
regenerated exports. Older schema files remain historical compatibility references.

The derived pre-scope consumer is `user-perspective-packet.v2.schema.json`. It does not change or
promote SQLite facts. It selects a few sourced traces/cases/principles plus a tiny hot working set
of applicable correction-shaping cards, filters unusable encoding,
enforces a hard serialized-character budget, exposes uncertainty, and carries explicit
`authority=false` / `completion_claim_allowed=false` boundaries. Full retrieval remains a debug
surface; the bounded packet is the ordinary planning input.

## User-correction shaping layer

Authority and activation are independent. A `shaping_card` is deliberately non-authoritative but
may have high activation when the current context resembles the concrete correction episodes it
cites. It exists between an event/trace and a formal proposal: it changes attention and orders only
already-admissible candidates, while the current user statement, live facts, authorization, Stop,
and hard boundaries always take precedence.

Each versioned card records trigger contexts and retrieval terms, a default tendency, tendencies to
suppress, applicability bounds, explicit suppression contexts/counterexamples, linked episode
traces and source events, salience, confidence, recurrence, last confirmation, and a decay
half-life. Retrieval requires contextual relevance; salience or repetition alone cannot make a
card global. Matching a suppression context emits an explicit suppression instead of a hotspot.
Recency decay lowers activation without deleting evidence. Reinforcement, scope splitting,
contradiction, retirement, and supersession append versions and preserve the originating episodes.
Only the ordinary proposal/evaluation/promotion path may turn a stable result into a formal
principle. The read-only `shape-candidates` consumer accepts only candidates already admitted by
the current role-bound frame. Hard overrides remain: `stop` empties the ranking; `explicit_choice_id`
places that candidate first. Otherwise it **fails open without directional auto-reorder**:
`ranking_status=abstained_directional_ambiguity`, input order preserved, `soft_delta=0` on every
row, candidate set preserved, `authority=false`, plus a bounded `active_direction_context` of
activated cards (card_id, activation_score, default_tendency, suppressed_tendencies,
applicability_bounds, source refs, each `authority=false`) for the appointed role plus live-frame semantic
judgment. That context is never permission or completion proof and does not call a model.
Lexical/negation/F1 direction scorers are intentionally not used as authority after held-out
breaks. The consumer cannot generate candidates, delete an admissible alternative, grant
authority, or claim completion. Older response fields (`applied_cards`, `soft_delta`,
`ranking_changed`, `suppressed_cards`) remain for compatibility; they must not be deleted.

## Decision trace as the primary object

A conclusion is only a time-slice projection. The durable primary object is a versioned
`decision_trace` with:

1. historical anchors and optional parent trace;
2. parent result and observed state;
3. the user's problem definition, violated expectations, and burden or harm;
4. current constraints, candidates, and counterfactuals;
5. decision, result, feedback, and assumption updates;
6. for decoding failures, the level-shift cues, mistaken subject, intended subject, and correction.

This is a selective event-sourced domain model, not a transcript or task-incident archive. Bind the
active subject before capture: a task/system causal diagnosis remains in task evidence unless the
user explicitly elevates it into a personal-model base/meta-case or it directly states reusable
personal decision logic. Store bounded semantic
facts and exact source references, not raw chat. A base case and its meta-case are separate typed
traces connected by `parent_trace_key`; do not copy recursive prose. A corrected answer never
deletes the earlier decoding failure, because the failure is evidence for improving the model's
future interpretation path.

## Decision generation

For a new scenario:

1. Recover the user's parent result, current real constraints, relevant decision traces, and any
   contextually applicable shaping hotspots; revalidate every hotspot against the current words and
   facts before it influences candidate order.
2. Preserve the active discourse level: concrete object, problem formation, parent intent/harm,
   upstream cause, remedy, or model-maintenance meta-layer.
3. Retrieve analogous cases and active principles as of the relevant time.
4. Separate protected outcomes/hard boundaries from replaceable means, identities, counts, and rituals.
5. Test whether a user decision really exists: require at least two admissible in-scope alternatives
   that materially change the business goal, completion shape, user value, or major external effect.
   A sole dominant necessary, bounded, reversible chain-internal route is decided by the current
   technical effect Owner for engineering effects or by the designated cognition subject for its
   epistemic work; an
   explicitly excluded object, topology, account, audience, persistent controller, or irreversible
   migration remains outside authority even when no alternative route exists.
6. Estimate the marginal decision/result gain of the next unit of search, context, tooling, worker effort, validation, or persistence.
7. Choose the smallest reversible action that maximizes expected net benefit without lowering the parent quality, evidence, or completion bar.
8. State the chosen action, historical anchors, active conditions, uncertainty, and counterfactuals.
   For important technical material, preserve the exact technical facts and also produce a
   familiar-object plain-language meaning layer plus a one-sentence action/choice layer covering
   current/next state, effect, risk, rollback, non-effects, and why user input is or is not needed.
9. Connect the chosen action to its real consumer and observe token/outer-turn cost, rework, repeated
   user explanation, latency, rollback cost, and actual result. Where useful, save a prediction
   before learning the outcome; later outcome evidence updates model quality.

This chain predicts preferences but never creates task authority.

## Optional graph projection

`graph-export` emits episodes and current versioned objects for Graphiti/FalkorDB. The graph may improve temporal/relational retrieval, but it is a cache/projection until an independent parity test proves it can be rebuilt from SQLite. Graphiti LLM/embedding calls are opt-in cognitive work and must use the existing provider routing and candidate-only rules; they do not promote facts.

FalkorDB's Docker image is downloaded but no container is created or started by installation. A temporary on-demand container must bind only a dedicated model projection directory, use loopback ports, and be stopped after the viewing/sync episode.

## Recovery

1. Read `current.json` and the referenced installation receipt.
2. Run the stable launcher `health`.
3. If an inserted child displaced the current parent, run `peek-task` and resume only the exact top
   frame; never infer the return target from themes or a different window's latest checkpoint.
4. If the venv is missing, recreate it from the release `requirements.lock.txt`; do not ask the user for package names or paths.
5. If SQLite is unhealthy, stop mutation, preserve the file, use the latest backup in `backups`, and compare event-chain hashes. Do not repair by deleting rows.
6. Rebuild JSON/TXT and graph exports after recovery.

The stdio MCP facade must start CLI subprocesses with stdin disconnected from the MCP pipe. On Windows, inheriting that pipe can leave a tool call without a response even after the CLI has exited; the permanent regression is `tests/test_mcp_stdio.py`.

No secret values are stored. External model credentials remain external handles.
