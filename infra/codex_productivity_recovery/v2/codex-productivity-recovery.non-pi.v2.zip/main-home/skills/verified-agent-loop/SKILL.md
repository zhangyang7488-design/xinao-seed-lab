---
name: verified-agent-loop
description: Execute role-bound engineering, delivery, migration, repair, monitoring, or controlled-experiment effects with explicit scope, observable acceptance criteria, bounded recovery, and real-consumer verification. Use only after current words and live facts appoint Codex/S to own that effect surface. Do not use this loop to choose, supervise, or duplicate a world-owning Sol's research cognition, and do not infer continuous mode, Goals, worker routing, or parent ownership from task size. Skip dialogue, simple work, and sufficient read-only adjudication.
---

# Verified Agent Loop

Use Codex's native tools, plans, hooks, memory, and skills only after the current role and effect
surface are bound. When separable labor or independent experimental branches have positive value,
consume `amplify-supervisor-worker`. Inside S's own engineering/control/effect cone it preserves
ordinary Grok as the default separable labor surface at dynamic width; that default does not select
or enter a world-owning Sol's cognition and does not create a fixed branch count. Add no second agent
runtime.
Keep raw Chain-of-Thought private; expose assumptions, actions, evidence, and verdicts.

On Windows, every agent-facing task-run command uses `scripts/task_run.cmd`. Never invoke
`task_run.py` directly from PowerShell: a bare `.py` path can be opened by the user's text editor
instead of executed. The launcher selects the verified Python interpreter without changing the
machine's `.py` association, Codex executable, or user applications.

## Route the request

Select the shallowest fitting mode:

- `dialogue`: answer or inspect read-only; do not manufacture execution.
- `plan_only`: investigate and plan without mutation when the user explicitly asks to plan first.
- `bounded_task`: implement a scoped engineering or delivery terminal state, verify it, then stop.
- `controlled_experiment`: operate only the admitted runtime, evidence, lifecycle, and effect
  contract while independent cognition subjects own their research.
- `ongoing_observation`: monitor or iterate only when current words or the live contract explicitly
  keep that lifecycle active; define event and stop conditions.

Mode selection does not reset authorization or assign epistemic ownership. For an already established
engineering/effect scope, treat Codex as its user-side technical effect Owner: a new window,
resume/compact, plan stage, local completion, report, or internal engineering phase is not a new
permission boundary. Continue derivable, reversible, verifiable chain-internal effect work until
that scope's completion ruler is met or an explicit Pause/Stop, user-exclusive fact/value fork,
major external effect, or proved blocker intervenes. If a world-owning Sol has been appointed, its
domain cognition remains outside this loop even while S operates the experiment around it.

Bind the mode to the live parent, not merely to the child currently being repaired. An explicitly
ordered multi-part request or exact return point with known unresolved siblings keeps that parent
active even when each child is bounded. After such a child closes, report its scoped status as
commentary and resume the next admitted machine frontier. `END_TURN`, `IDLE`, and hand-back are
effect-bearing actions, not neutral defaults: final-yield is allowed only when the root object is
itself bounded and closed, the parent is verified complete, or Pause/Stop, a material user fork,
major boundary, real blocker, or current lifecycle end requires yielding. This does not create
unattended or cross-restart continuation.

For an active ongoing engineering or experiment contract, status questions, explanations, worker terminals, and local
`verified|partial|blocked` reports are additive commentary boundaries. Record the local status and
resume the exact parent frontier; none may final-yield the parent. An explicitly bounded or one-shot
non-research object remains bounded.

Do not autonomously create or revive a native Goal. Use an existing Goal only when current words and
the live consumer explicitly retain it; otherwise keep task state in the already-admitted local
contract, evidence, or checkpoint. Goal presence never expands scope, authority, Stop, unattended
execution, cognition ownership, or cross-restart continuation.

For a material task, define the objective, read/write scope, risk, limits, and observable completion
criteria before editing. Use the native plan for ordinary multi-step work. Use
`scripts/task_run.cmd init` when the task spans windows, agents, risky bulk changes, or a long run.

## Build context just in time

Keep the current request, applicable `AGENTS.md`, short checkpoint, and authority index near
context. Retrieve specifications, code, memories, and history only when relevant. Record why a
source was loaded and its path or URL. Send separable large reads or research to the current
external-worker surface when useful and merge only their cited candidate findings.

Do not load every repository document into every prompt. Availability is not injection.

## Decompose and assign

Use `amplify-supervisor-worker` only when lanes are genuinely separable and supervision has positive
effect. A world-owning research lane receives the permitted reality and hard experiment boundary,
not a supervisor answer or a preselected local question unless the experiment itself fixes one. An
engineering worker receives a bounded candidate package and never acquires shared-write authority.

- Give each lane one bounded question, output contract, and stop condition.
- Assign one writer for every overlapping path or external object; other lanes remain read-only.
- Require workers to return artifacts, diffs, commands, terminal state, or source URLs—not a
  confidence statement.
- Give the verifier the request, acceptance criteria, artifacts, and raw evidence; do not prime it
  with the worker's self-evaluation.
- Prefer dynamic width. Do not spend multi-agent tokens on tightly coupled or trivial work.

## Act with bounded autonomy

Prefer API or purpose-built connector, then native CLI, then DOM/UIA, then visual coordinates.
Keep user-scoped irreversible or external actions inside explicit authority.

For a named transaction in an existing repository with an existing authorized remote and PR/merge
workflow, a request to implement, fix, build, land, finish, or close the transaction supplies clear
workflow scope for its exact commit, push, PR/merge, remote readback, real-consumer verification,
and transaction-hygiene chain. Do not stop for a second publish instruction. Explicit local-only/no-publish/pause/stop, a
missing existing remote workflow, or a new repository, remote, account, audience, payment,
persistence, major security effect, or a rollout that introduces a new live object, topology,
audience, or irreversible state migration remains a real authority boundary. A bounded reversible
version switch within the already authorized object and topology is not a boundary merely because
it is called deployment. In a mixed
worktree, isolate the named transaction and never stage unrelated state. Record the pre-transaction
baseline, commit every useful scoped artifact, and after remote/effect verification retire classified
temporary files, worktrees, branches, containers, and one-shot evidence. Verify physical absence and
no transaction-added dirt while preserving every unrelated baseline change; unclassified carriers
fail closed.

Preserve intelligence while enforcing the boundary. Capability availability is a hard default, but
activation and worker width stay adaptive to expected task fit, quality, evidence gain, speed, risk,
latency, cost, and coordination friction. Do not manufacture a numeric score, fixed lane count, or
mandatory tool sequence. The task envelope, authority boundary, and evidence criteria are hard
rails; the procedure between them is a revisable strategy, not a second execution controller.

- Classify failures as deterministic or transient.
- Fix deterministic failures; do not blindly retry them.
- Retry transient network, lock, or rate failures at one layer only and within the declared budget.
- Give resumable side effects an idempotency or operation ID.
- Before an interrupt or handoff, persist a checkpoint after the last completed side effect.

Keep one logical `work_key` across windows, worker packages, commits, PRs, runtime verification,
and any temporary carrier. If a worktree or branch is created, bind its carrier identity and
generation to the existing task-run immediately. An interruption freezes mutation and records the
exact next consumer; it does not abandon, silently continue, or reclassify the half-finished work.
After acceptance, distinguish commit, push, merge, remote readback, runtime effect, and carrier
retirement, then retire the carrier only after physical absence is independently observed. Never
leave a dirty, unique, or unclassified carrier as an implicit archive.

Use `scripts/task_run.cmd event` for compact, redacted events. A retryable side-effect outcome uses
one stable `--event-id` plus the same phase, target, and side-effect identity so replay is
idempotent; the event chain is the fact source and the state file is its recoverable projection.
If a typed mutation derives identity, generation, or admissibility from the current event prefix,
validate the proposed transition first and pass that prefix count and exact event-file digest as
`--expected-events-count` plus `--expected-events-sha256` to the locked append. A changed head is
a typed conflict to re-read or retry, never permission to append against stale state; exact
existing event-ID replay remains idempotent.
Store references to evidence rather than raw terminal transcripts, secrets, or thought traces.

## Verify independently

Before any repeated test or revalidation after a rebase, baseline, version, or pin change, apply the
global L0 evidence-delta rule at the action boundary. Inspect the changed surface and its dependency
or runtime-semantic reach first. Preserve and reuse prior evidence when the tested inputs, relevant
dependencies, and execution semantics are unchanged; a disjoint upstream change never justifies a
second full-suite run by itself. When they intersect, run the smallest verification that covers the
new risk. Expand to the full suite only when a shared dependency or runtime changed, or when a
material blast radius cannot be bounded reliably. This keeps engineering invariants risk-bound; it
is not permission to skip affected tests.

Read the real terminal state. Match every observable criterion to a test, status query, file,
artifact, screenshot, diff, or primary source.

Use `scripts/task_run.cmd verify` to attach evidence to criteria for durable runs. A ledger entry is
an index, not proof; inspect the referenced artifact.

Finish with one status:

- `verified`: every observable criterion passed with real evidence.
- `partial`: some criteria passed and the remainder is explicit.
- `blocked`: a concrete blocker remains after bounded attempts; list attempted paths and an
  actionable alternative.
- `unverified`: an artifact may exist but could not be checked; never call it complete.

`scripts/task_run.cmd finish --status verified` refuses to close unless every criterion has a
passing evidence record. Finishing a bounded child ledger records only that child's status; it does
not authorize a final-yield transition for an active ongoing effect contract.

## Learn only from outcomes

Create a reflection only when a test, tool, user correction, or other external signal produced a
real lesson. Keep: trigger, observed failure or success, cause supported by evidence, and the
narrow next-time action.

Turn repeatable failures into an eval case. Test candidate prompt, router, tool, or skill changes in
isolation; run regression checks; promote them only after evidence and review. Never let one run
rewrite global instructions, authorization, or procedural memory automatically.

Store stable user facts in semantic memory, task trajectories in episodic memory, and validated
workflows in versioned procedural skills. Apply scope, provenance, confidence, supersession, and
expiry where the memory surface supports them.

Read [references/source-patterns.md](references/source-patterns.md) only when choosing or reviewing
an external agent mechanism.
