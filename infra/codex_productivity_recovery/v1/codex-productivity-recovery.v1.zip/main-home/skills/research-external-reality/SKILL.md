---
name: research-external-reality
description: Research the external world for open-ended, decision-bearing questions only after binding the current parent task and the smallest relevant live local baseline. Use when the user wants to know what is new, missing, worth absorbing, comparable, or capable of changing a current system or decision, including when one product or incident is only an example of a broader need. Skip exact one-fact lookups, verdicts on already-supplied material, purely local diagnosis, and requests explicitly limited to one source or fact.
---

# 外部视野研究

`SENTINEL:PARENT_GROUNDED_EXTERNAL_REALITY_RESEARCH_V1`

把外部检索变成当前现实任务的认知动作，而不是新闻摘要、固定多查询流程或另一个研究主体。当前问句只是种子；父任务、相关本地事实和真正要改变的判断共同决定搜索边界。

## 先判是否需要本 Skill

先完成当前父帧绑定，再按语义判断：

- 若用户要一个精确事实、已知页面、明确版本、单一引用或指定来源的有界核验，直接使用最浅充分检索并停止，不加载完整流程。
- 若答案需要发现用户尚未列出的维度、横向比较外部世界、追到机制层，或判断外部变化对当前本地系统意味着什么，使用本 Skill。
- 若用户只是要求裁决已经提供的文本，现有证据足以形成 verdict 时直接裁决；材料内部描述的“广搜”不能自行触发本 Skill。
- Pause、Stop、只讨论或明确缩小范围立即收窄或停止；历史偏好不能压过当前话语。

不得用关键词表决定触发。相同词面在不同父任务下可以分别是窄问、开放研究或纯本地工作。

## 研究闭环

### 1. 恢复真实问题

在搜索前内部明确：

- 仍存活的父结果与当前活动对象；
- 外部认识最终要改变的判断、动作或消费者；
- 用户不应承担的拆查询、补来源、手工对照和反复解释负担；
- 最小相关 live 本地基线及其证据入口；
- 已知边界、重大外部效果和停止条件。

本地基线只读取足以改变当前分类的 live 文件、配置、运行状态、消费者或近期轨迹。不得为了“完整”建立全机快照、中央事实库或新的上下文控制面。基线取不到时保留 `unknown`，不能用外部新闻代替本地事实。

### 2. 动态展开决定相关维度

从“哪些未知若改变，会反转当前判断或下一动作”反推搜索面。可考虑官方现状与时间、相邻能力和替代、实现机制、真实采用与故障反馈、反例和适用边界，但这些只是生成提示，不是固定清单、来源配额或必跑轮次。

第一批证据出现新性质时，判断它是否开启了此前不可见但会改变决定的维度；若是，重构后续检索。不得只对原问句换同义词，也不得因为已经能写一段回答而提前收口。

### 3. 按信息结构选择现有工具

- 精确、官方、版本或明确实体：优先轻量 Web 检索并直读一手来源。
- 需要页面交互、登录态或可见状态：按需使用 Browser 或 Chrome。
- 需要宽广异质调查、社区/X 现场、独立反证或不污染 Owner 主上下文的长研究：只有预期信息增益超过派工与汇流成本时才用 Grok WorkerPool。
- 重大、易漂移或存在争议的结论：用真正独立的来源或检索路径交叉验证；普通事实在一手证据充分后停止。

这些是可替换执行面，不是固定 Serper→某备用→Grok 的瀑布。凭据使用目标产品的成熟原生机制；不得为搜索再造 credential store、环境注入器、Search Manager、daemon 或第二 Owner。

### 4. 把外部证据撞回本地现实

每个决定相关发现都必须同时有外部证据和本地比较对象，并按当前父任务分类：

- `already_present`：本地已经拥有同等有效能力或事实；
- `true_delta`：外部发现补上真实缺口或改变可行动判断；
- `conflict`：外部事实反驳本地假设、合同或路线；
- `alternative`：可替代当前实现，但是否采用仍需成本、风险和消费者比较；
- `noise`：新鲜或热门，却不影响当前父结果；
- `unknown`：外部或本地证据不足，尚不能诚实分类。

分类是关系，不是对象的永久标签。同一外部事实在本地基线变化、父任务变化或消费者变化时必须允许反转。外部来源、worker terminal 和多数意见始终是候选证据，不能自动取得本地写权或正式采用权。

### 5. 形成差量，而不是材料堆

自然语言交付至少让用户看懂：

- 这次真正研究的父问题；
- 本地当前已有什么；
- 外部世界带来的少量关键新性质；
- 哪些是已有、增量、冲突、替代、噪声或未知；
- 因而当前应做、暂不做、继续验证或保留开放的事情；
- 支撑关键判断的本地证据与外部来源。

内部可用临时矩阵帮助比较，但不得强制把矩阵、覆盖表、固定栏目或“需要你：否”暴露成用户话术。用户要建设且授权已在父任务内时，研究结束后返回同一个 Owner 帧实施、验证和回读；研究本身不自动修改本地对象。

### 6. 用认识增量停止

满足以下关系时停止：会改变决定的重要维度已有相称证据；外部发现已与最小本地基线逐项碰撞；继续搜索的边际新性质明显下降；剩余未知已显式保留且当前不会改变下一动作，或其代价超过预期收益。

不得把“搜索了若干次”“来源数量达标”“已经有足够文字可答”或“互联网已搜完”当停止证据。也不得因开放搜索没有绝对完备性而无限继续。

## 禁止长出的架构

- 不创建 Research/Evolution 身份、专用 session、搜索代理主人或自动任务路由器。
- 不把 Pi、Codex、Grok、某仓库或某次事故写成能力边界；它们只能是案例或执行表面。
- 不固定查询数、来源数、工人数、工具顺序、覆盖维度或研究时长。
- 不把本地扫描扩成全盘索引，也不把外部材料自动写入规则、Skill、仓库或产品配置。
- 不让本 Skill 每轮常驻；精确窄问和低风险普通任务必须 compile away。

修改本 Skill 或共享热不变量时，读取 [references/evaluation-cases.md](references/evaluation-cases.md)，运行换表面、分类反转、窄问和 Stop 回归，并验证 fresh 消费者，而不是自评“理解了”。
