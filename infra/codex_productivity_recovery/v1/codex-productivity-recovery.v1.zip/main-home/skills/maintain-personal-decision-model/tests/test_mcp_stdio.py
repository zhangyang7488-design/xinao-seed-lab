from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
from pathlib import Path

from mcp.client.stdio import stdio_client

from mcp import ClientSession, StdioServerParameters

SERVER = Path(__file__).parents[1] / "scripts" / "pdm_mcp_server.py"
PDM = Path(__file__).parents[1] / "scripts" / "pdm.py"


def test_mcp_stdio_health_and_no_promotion_tool(tmp_path: Path) -> None:
    initialized = subprocess.run(
        [sys.executable, str(PDM), "--root", str(tmp_path), "init"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    assert initialized.returncode == 0, initialized.stderr

    async def run() -> None:
        environment = dict(os.environ)
        environment["XINAO_PERSONAL_DECISION_MODEL_ROOT"] = str(tmp_path)
        params = StdioServerParameters(command=sys.executable, args=[str(SERVER)], env=environment)
        async with stdio_client(params) as streams:
            async with ClientSession(*streams) as session:
                await session.initialize()
                tools = await session.list_tools()
                names = sorted(tool.name for tool in tools.tools)
                assert "pdm_health" in names
                assert "pdm_propose_update" in names
                assert "pdm_record_decision_trace" in names
                assert "pdm_record_shaping_card" in names
                assert "pdm_shape_candidates" in names
                assert "pdm_user_perspective_packet" in names
                assert all("promote" not in name for name in names)
                result = await asyncio.wait_for(session.call_tool("pdm_health", {}), timeout=10)
                health = json.loads(result.content[0].text)
                assert health["status"] == "healthy"
                assert health["authority"] is False
                perspective_result = await asyncio.wait_for(
                    session.call_tool(
                        "pdm_user_perspective_packet",
                        {"scenario": "决策如何连接生产力", "max_chars": 6000},
                    ),
                    timeout=10,
                )
                perspective = json.loads(perspective_result.content[0].text)
                assert perspective["scenario"] == "决策如何连接生产力"
                assert perspective["authority"] is False
                assert perspective["completion_claim_allowed"] is False

                shape_result = await asyncio.wait_for(
                    session.call_tool(
                        "pdm_shape_candidates",
                        {
                            "context": {
                                "scenario": "决策如何连接生产力",
                                "candidates": [
                                    {"candidate_id": "keep", "text": "keep input order A"},
                                    {"candidate_id": "other", "text": "keep input order B"},
                                ],
                                "stop": False,
                            }
                        },
                    ),
                    timeout=10,
                )
                shaped = json.loads(shape_result.content[0].text)
                assert shaped["authority"] is False
                assert shaped["completion_claim_allowed"] is False
                assert shaped["ranking_status"] == "abstained_directional_ambiguity"
                assert [row["candidate_id"] for row in shaped["ranked_candidates"]] == [
                    "keep",
                    "other",
                ]
                assert all(row["soft_delta"] == 0.0 for row in shaped["ranked_candidates"])
                assert isinstance(shaped.get("active_direction_context"), list)

    asyncio.run(run())
