---
name: maintain-personal-decision-model
description: >-
  User-facing name is Decision Skill (决策 Skill / 决策模式). After current-statement
  and active-subject binding, use it immediately as a sidecar when the user says
  决策skill, 进入决策模式, or 进入运维模式; also use it when the user materially
  describes how they judge, detect mismatch, experience AI burden, or want AI to
  understand them, without requiring a remember phrase. Maintain the temporal personal
  decision model and its non-authoritative high-activation correction-shaping layer:
  preserve sourced episodes, retrieve a tiny context-sensitive hotspot set before
  candidate ranking, absorb stable corrections, stop repeated cross-window explanation,
  record outcomes, and evolve/export the model. Current words, live facts, authorization
  and Stop always override shaping memory. Do not trigger for transient task state,
  one-off wording, a task-local diagnosis of mismatch or AI burden, or a request to
  judge supplied material unless the user also states stable first-person decision
  logic or explicitly asks for Decision Mode/capture. Never let retrieval or capture
  replace parent-frame admission, the current response/action, or the continuous frontier.
---

# Maintain Personal Decision Model

This skill exposes an event-sourced personal decision model. Its primary object is the user's
decision-generation chain, not a conclusion or a flat preference list. Structured data is the
truth; text is a regenerable view. The skill and optional graph/viewer runtime are replaceable,
while the D-drive database remains separate.

## User-facing activation identity

- Display and speak of this capability as **决策 Skill** and its active work identity as **决策模式**.
- The phrases `决策skill`, `进入决策模式`, and `进入运维模式` are guaranteed short activators, not a whitelist. Semantically equivalent requests to enter today's self-model, decision-reasoning, metacognition, or AI-behavior-correction work identity activate the same skill without requiring exact wording. If the user says `进入运维模式`, acknowledge it as `决策模式` so the user does not have to keep seeing the stressful operations label.
- This is a current-window sidecar work identity for the bundle implemented here: metacognition capture, case and principle lineage, meaningful-choice analysis, plain-language technical adaptation, AI-behavior correction, and discussion-to-effect closure.
- Activation never starts or replaces the mainline, consumes the task's response/action slot, stops an active continuous frontier, creates a Goal/control plane/daemon, or adds another Owner. It does not itself authorize mutation. The user's accompanying request defines the bounded work; Pause/Stop or discuss-first forbids retrieval/capture tool work until the user resumes, and absent a concrete mutation request all other work remains inspect/explain/model only.
- Keep the internal skill ID, launcher, database, and runtime paths stable. The user-facing alias is a replaceable interface name, not a data migration.

## Fixed authority boundary

Apply this order: current user statement, real object facts, and hard boundaries → a live, falsifiable user-owned problem/completion-identity hypothesis with subject binding (not the deepest known cause or repair carrier) → the bounded perspective packet when applicable → closure of the predecision frame (parent result, active subject/object, means versus endpoint, roles, consumer/completion bar, hard boundaries) and current task completion ruler → admissible candidates. Compile the result as the current minimal relation slice `human practice → parent result/burden → current frame → approach/capability → responsibility → runtime carrier → consumer effect`; roles, authority/Stop, evidence, dependencies, and lifecycle remain cross-cutting. The packet supplies sourced candidate nodes and level-shift evidence only. It never selects the live graph or completion identity by authority, grants authorization, selects a task merely by association, blocks unrelated work, changes a parent goal, or proves completion. Do not load or serialize the whole personal model in ordinary work. Retrieval, capture, trace maintenance, and export are bounded sidecar operations; after them return to the exact task/frame in the same episode. If the model is missing, stale, unhealthy, or contradictory, continue the original task and report only the local model-maintenance gap.

When current words and live facts already establish a surviving parent and scope, preserve the user's stable expectation that Codex acts as their technically capable Owner rather than resetting to an authorization-free assistant at each window or phase. The model may make this correction highly salient, but current scope remains the authority source. Plan stages, local completion, reports, package approval fields, resume, and compact do not manufacture a new user gate; only explicit Pause/Stop, a user-exclusive decisive fact or value fork, or a newly introduced major external effect does. Capture this posture and its failure recurrences without turning the model itself into a task generator or permission source.

## Route

Use the stable launcher:

```powershell
& 'C:\Users\xx363\CodexLaunchers\Invoke-PersonalDecisionModel.ps1' health
```

Read `references/model-contract.md` before changing schemas, promotion logic, provenance, or the software boundary. Read `references/maintenance-policy.md` before deciding whether a correction is stable enough to capture or promote.

## Workflow

1. After current user/system/global/project instructions identify this skill as applicable, first bind from the current statement and hard facts a live, falsifiable user-owned problem/completion-identity hypothesis plus the active subject/object; then run `health` and call `perspective-packet` **before deeper task-material loading or finalizing the parent result, completion ruler, or strategy**. The packet may refine this initial frame but never originates or replaces it. Build the first query from the user's own core terms and level-shift cues; do not translate Chinese into generic English or paraphrase away retrieval vocabulary before the packet. For each returned `shaping_hotspot`, revalidate its applicability and counterexamples against the current words, live facts, authorization and Stop. After the Owner has formed the in-scope admissible candidates, call `shape-candidates` with only those candidates. Hard overrides remain first: `stop` returns an empty ranking, and `explicit_choice_id` places that candidate first. For all other natural-language direction cases the consumer **abstains from auto-reorder** (`ranking_status=abstained_directional_ambiguity`): `ranked_candidates` keep input order, every `soft_delta=0`, the candidate set is preserved, and `authority=false`. It also returns a bounded non-authoritative `active_direction_context` (card_id, activation_score, default_tendency, suppressed_tendencies, applicability_bounds, source refs only) so the Codex Owner can revalidate against the live frame; the context is not permission, completion proof, or a model call. Do not expand a local negation/token/F1 parser into authority—held-out polarity already broke those approaches. The shaper cannot invent/drop candidates, select the parent result, create permission, or prove completion. `shaping_suppressions` are positive evidence that a superficially related card must stay inactive. Use the rest of the packet to select the minimum relevant context; it does not waive any task-specific stable source that must still be read before design or mutation. Do not emit a provisional answer first, consume the packet afterward, reread the same large source, or treat late consumption as equivalent. Reserve `retrieve` and `explain` for targeted audit instead of dumping the full model into ordinary work. If the packet is missing or low-confidence, use current facts and a bounded official/mature external comparison where it can resolve the uncertainty; do not turn uncertainty into an automatic user question.
2. Before capture, bind the active subject and object scope. A task/system diagnosis remains task
   evidence even when it uses causal or metacognitive language. Do not activate or write this
   model merely because the user explains why a mainline state, controller, prompt, or tool became
   a problem. A pasted diagnosis plus “is this right?” remains source adjudication even when its
   preamble mentions recurring AI burden; do not run health, retrieval, shaping, or capture unless
   the current user statement independently supplies stable personal decision logic. It enters the personal model only when the user explicitly elevates that case into
   their reusable cross-case decision logic, explicitly invokes Decision Mode for it, or the
   statement itself materially describes the user's decision logic, mismatch detector, burden,
   desired AI understanding, or cross-case reasoning.
3. Recognize personal metacognition by meaning, not by a magic phrase. A material statement about
   the user's own decision logic defaults to event-level capture even if the user did not say
   `remember` or `make this a rule`. Preserve it as the first-person fact that the user understands
   their decision core this way. Sparse supporting cases limit only generalization and predictive
   confidence; they do not invalidate the self-report or justify asking the user to recursively
   prove why it deserves capture. Preserve a precise non-secret `source_ref` and a bounded summary;
   never save raw chat or secret values by default. Capture is not the response or task result; after
   it, return to the exact live task/frame unless the user paused or stopped.
4. When the statement exposes how a personal decision or personally elevated base/meta-case was generated, record a versioned
   `decision_trace`: historical anchors → parent result → observed state → how the user defined
   the problem → violated expectation/burden → constraints and candidates → counterfactuals →
   decision → result/feedback → assumption updates. A base case may be the parent of a typed
   meta-case. Any material failure that makes the user restate, re-anchor, or repair the parent
   intent, active subject, object scope, action binding, or suspended return point defaults to a
   versioned `decoding_failure` trace; do not wait for a second `remember` or rule-making command.
   Preserve the user's level-shift cues, the mistaken active subject, the intended subject, the
   correction, the actual burden, and the downstream behavior change. If the same failure family
   recurs, append a new source event and trace version or child trace instead of pointing at the
   older case as though recurrence were already solved. The later correct answer or successful
   action never overwrites that negative trajectory.
5. Keep five layers separate: captured event, decision trace, soft shaping card, conditional rule
   proposal, and promoted current principle. Event capture preserves what the user revealed; the trace
   preserves how the understanding or choice was generated; neither is authorization,
   permanence, agreement, or automatic rule promotion. A shaping card is the defeasible middle
   state for a correction that should strongly alter attention or candidate ordering before it is
   a formal rule. It must cite one or more concrete trace episodes, name trigger contexts, default
   and suppressed tendencies, applicability bounds and counterexamples, and carry explicit
   salience, confidence, recurrence, last-confirmed time and decay. Repeated evidence appends a new
   version; contradiction, scope splitting, suppression and supersession never erase the episodes.
   High activation remains orthogonal to authority. Once captured, the AI—not the user
   caught inside the recursion—owns the work of finding cases, conditions, counterexamples, and
   tests. Create `propose` only when a conditional generalization can improve future choices,
   and state its scope, conditions, counterexamples, counterfactual impact, and historical cases.
6. Test proposals against held-out historical or later real cases. Promote only with a passing evaluation, or when the user explicitly states a stable cross-case rule and the proposal has been checked for hard-boundary conflicts. Promotion is an Owner action; MCP deliberately omits it. Revising a rule never deletes the originating metacognitive event, decision trace, or derivation.
7. After promotion, regenerate JSON and TXT exports and run `health`. Keep the previous model version and provenance; never silently overwrite history.
8. On an actual future choice, store the prediction before the outcome when practical, then record the real outcome and evaluate. A model that becomes less predictive is revised, demoted, or rolled back rather than defended.

## Interruption-safe task frames

Use the separate short-term task stack when a newly inserted child issue would otherwise displace
an unfinished parent in the same window. Before entering the child, call `suspend-task` with the
exact parent task ID, current window role, completed-do-not-reopen set, pending set, unique next
step, inserted child ID, return point, source heads, and explicit exclusions. After the child
closes, call `resume-task` with the same frame, parent, role, and parent-state hash. Resume only the
top frame. A mismatch fails without changing the stack.

Do not reconstruct a parent from topic similarity, the newest checkpoint, a long transcript, or
the existence of repository files. Do not reopen completed history without new evidence. A child
cannot replace the parent task identity or adopt work owned by another window. If the current user
explicitly replaces or stops the parent, the current request wins; the frame remains non-authority
recovery evidence.

The task stack is `task_stack.v1.json` beside the model database and follows
`references/task-interruption-frame.v1.schema.json`. It uses a cross-process lock, atomic replace,
LIFO resume, idempotent frame identity, and retained resume history. It is short-term task state,
not personal-model truth: never export it with personal facts, retrieve it as a preference, or
promote its current task contents. Only a user-elevated stable lesson exposed by an interruption
may enter the event/trace/principle chain.

## Decision and explanation use

- First apply current user words, real object facts, and hard contracts. The model only supplies analogous cases, conditions, and counterfactuals when the remaining choice is genuinely hard.
- Maintain a discourse-level stack when the user moves between the concrete event, how it became
  a problem, its parent intent/harm, upstream cause, remedy, and how the remedy becomes future
  behavior. Cues such as `更前置`, `不是具体例子`, and `案例的案例` re-anchor the active
  subject upward; do not collapse the example into the goal or flatten a generation chain into
  a convenient label. The live task, not this Skill, chooses the current causal problem level;
  remedy, behavior-consumer landing, and model-maintenance persistence are orthogonal targets
  selected only after that hypothesis is supported.
- Ask the user only for a meaningful fork: at least two in-scope admissible alternatives must materially change the business goal, completion shape, user value, or major external effect. One dominant necessary, bounded, reversible chain-internal route under an already authorized parent result is an Owner decision plus a plain-language notice, not a permission questionnaire.
- When technical material matters to the user, preserve the exact technical layer and add a familiar-object meaning layer plus one sentence stating the actual action or choice. Include current/next state, concrete effect, risk, rollback, non-effects, and why a real user decision exists. Translate the meaning, not merely the English term.
- A stable problem is not closed by capture, explanation, or a report. Land the smallest existing behavior consumer and changed-context regression when authorized and beneficial; otherwise report the model item as candidate/partial. Never convert an actionable request into text-only Decision Mode work merely because its correction was captured.
- Close the decision-to-productivity loop: user problem formation and completion ruler → bounded perspective packet → scope/strategy/tool choice → real consumer effect → token/outer-turn cost, rework, repeated user explanation, latency, rollback, and outcome feedback. A stored decision that never changes a later choice or observable result is an unconsumed record, not a working Decision Skill.

## Common commands

```powershell
$pdm = 'C:\Users\xx363\CodexLaunchers\Invoke-PersonalDecisionModel.ps1'
& $pdm perspective-packet --query 'current non-trivial situation' --max-sources 3 --max-chars 9000
& $pdm shape-candidates --payload-json '{"scenario":"...","candidates":[{"candidate_id":"a","text":"..."},{"candidate_id":"b","text":"..."}],"stop":false}'
& $pdm retrieve --query 'new situation' --limit 5
& $pdm explain --query 'new situation' --limit 5
& $pdm suspend-task --payload-json '<task-frame-json>'
& $pdm peek-task
& $pdm resume-task --frame-id '<frame>' --parent-task-id '<parent>' --window-role '<role>' --expected-parent-state-sha256 '<sha256>' --child-status verified
& $pdm capture --type correction --source-ref 'thread:<id>:turn:<n>' --summary '...' --payload-json '{}'
& $pdm record-trace --payload-json '{"trace_key":"...","trace_kind":"problem_formation",...}'
& $pdm record-shaping-card --payload-json '{"card_key":"...","trigger_contexts":["..."],"default_tendency":"...","applicability_bounds":["..."],"episode_trace_keys":["..."],"evidence_event_ids":["..."],...}'
& $pdm propose --type principle --source-event-id '<event>' --payload-json '<json>' --impact-scope-json '["..."]'
& $pdm predict --scenario '...' --choice '...' --reasoning-json '{"cases":[],"principles":[]}' --source-event-id '<event>'
& $pdm record-outcome --prediction-id '<id>' --actual-choice '...' --result '...' --source-event-id '<event>'
& $pdm evaluate --dataset-ref '<held-out-set>' --source-event-id '<event>'
& $pdm replay-eval --file '<versioned cross-case fixture.json>' --min-cases 5 --min-accuracy 0.8
& $pdm export --format json
& $pdm export --format txt
& $pdm backup
```

## Optional surfaces

- Run `scripts/pdm_mcp_server.py` over stdio only when a client needs the common tools. Do not register it globally merely because it exists.
- `graph-export` creates a provider-neutral JSONL input for the optional Graphiti/FalkorDB projection. SQLite remains authoritative if the graph is absent.
- Datasette and FalkorDB Browser are on-demand viewers. Do not start them as services, schedulers, startup hooks, or completion gates.
- Reuse existing LangGraph/Temporal only for an explicitly useful multi-step maintenance episode. Do not create a second orchestrator.

## Thin self-maintenance

Maintenance is event-driven and piggybacks on relevant work. Do not scan every task, call a model on a timer, or create upkeep for its own sake. A failed capture/export/evaluation stays local and never reverses a completed parent task. Back up before a schema migration; rebuild optional projections from SQLite; keep one current pointer with exact runtime, data, skill, and recovery paths.
