# Event-driven self-maintenance policy

## Capture when

- the user materially describes how they judge, reason, detect mismatch, experience AI burden, want AI to understand them, or derive a choice across cases; this is recognized by meaning and does not require `remember` or `make this a rule`;
- the user explicitly corrects a recurring interpretation or says a preference should survive windows;
- a real decision reveals how a general principle changes under current constraints;
- a prior prediction is confirmed or falsified;
- the user explicitly elevates how an observed state became a problem into their reusable
  cross-case decision logic, moves the personal-model subject to a more upstream abstraction
  level, or marks the current episode as a personal-model base case or meta-case;
- an AI decoding trajectory loses that level despite explicit cues, or requires the user to
  restate/re-anchor the parent intent, active subject, object scope, action binding, or suspended
  return point; append the failed and corrected trajectory even when the final answer or action
  succeeds, and record same-family recurrence as new provenance rather than treating the old case
  as proof that the failure is solved;
- two active principles conflict in a new cross-case setting;
- a tool/module fails and the durable lesson is a capability, recovery, or boundary fact rather than a transient error string.

## Do not capture when

- the fact is ordinary task state, a temporary path, a one-off choice, raw conversation, or already represented without new evidence;
- the fact is a current task frame, inserted child, completed/pending list, resume pointer, branch
  head, or checkpoint cursor; keep those in the interruption stack and task evidence, never in
  personal-model retrieval or exports;
- the user is diagnosing the cause, scope, or required repair of a task, mainline, controller,
  prompt, worker, or tool and has not elevated it into personal cross-case decision logic;
- the lesson merely repeats an existing promoted principle;
- capturing it cannot improve a future decision, recovery, explanation, or prediction;
- it would include secret values or confer authority not present in the user request.

Event capture is the low-friction preservation layer, not rule creation. A material first-person
metacognitive statement is authoritative as evidence that the user understands their own decision
core this way; lack of supporting cases limits only generalization and predictive confidence. Keep
the bounded metacognition and provenance even if no proposal is warranted, and do not force the user
to recurse into explaining why it deserves capture. If a generalization is useful, the AI creates a
separate conditional proposal with scope, counterexamples, and conflicts. A later revision may
supersede a proposal or principle but must not erase the originating event or derivation.

Use a `decision_trace` when the reusable evidence is the generation chain rather than just the
statement. Keep it bounded: link historical anchors and parent traces, but do not store a raw
conversation or recursively duplicate every layer. The minimum complete chain includes parent
result, observed state, problem definition, constraint/counterfactual, decision, result or pending
state, and assumption update. A decoding-failure trace additionally requires level-shift cues,
mistaken subject, intended subject, and correction.

Create or version a `shaping_card` when a sourced correction episode should be highly likely to
change interpretation, attention, or candidate ordering in a related future task but is not yet a
formal cross-case rule. The card must retain links to concrete episode traces and events, not just
an abstract preference label. Give it explicit trigger contexts, applicability bounds,
counterexamples and suppression contexts. Recurrence may increase activation; elapsed time may
decay it; neither operation changes authority. A new contradiction or narrower context creates a
new version that splits, suppresses, retires, or supersedes the old card without deleting evidence.
Do not create a card for surface style, a one-off task fact, a provider identity that is merely an
example, or a statement whose only effect would be globally forcing a favorite workflow.

An interruption may expose a stable personal or AI-burden lesson, but the current frame itself is
not that lesson. First restore the exact suspended parent through the separate task stack. Capture
only the user-elevated cross-case rule—such as requiring precise parent restoration instead of
theme-based reconstruction—with its failure trace and changed-context regression.

## Promotion

Promote the smallest generalization supported by the evidence. Record conditions and counterexamples. Prefer conditional principles over absolute personality claims. A provider or tool identity remains an example unless identity itself is the protected result; public rules normally bind the capability.

The default promotion gate is a passing held-out or future-outcome evaluation. A high-salience
shaping card is not already promoted. `--user-explicit` is reserved for a clear stable correction
from the user, not an AI inference. Promotion always creates a new model version and keeps the prior one.

When the user clearly states that the metacognition itself is a stable cross-case operating rule,
`--user-explicit` may be used only after checking it against hard contracts and at least the
relevant positive/negative cross-case fixtures. Explicit stability removes the need for a second
magic phrase; it does not remove the separation between event, proposal, evaluation, and version.

## Effect metric

The model is useful only if it reduces repeated user explanation, improves held-out/future choice prediction, produces traceable explanations, or shortens recovery without weakening task quality. More events, tokens, graph nodes, model calls, or prose are not success metrics.

Track prediction count, resolved outcomes, exact/semantic match, unexplained corrections, model
reversals, retrieval evidence coverage, generation-chain coverage, retained decoding failures, and
maintenance cost. If evidence is sparse, report uncertainty instead of manufacturing confidence.

## Self-reference and failure isolation

The model explains its own organization and update rule because those rules are also revisable assumptions. When new evidence shows that its capture threshold, retrieval shape, evaluation gate, software topology, or self-description causes user burden or prediction loss, propose a model-maintenance change through the same event → proposal → evaluation → promotion chain.

Do not let this recurse without a real external signal. No timer, daemon, scheduler, standing worker, or automatic promotion is allowed. A maintenance failure never blocks the task that exposed it.
