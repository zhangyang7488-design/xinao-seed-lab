#!/usr/bin/env python3
"""Optional on-demand stdio MCP facade for the personal decision model.

It is intentionally not registered globally by installation. Promotion remains
an Owner CLI operation; MCP tools expose context reads and candidate capture.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

SCRIPT = Path(__file__).with_name("pdm.py")
MODEL_ROOT = os.environ.get(
    "XINAO_PERSONAL_DECISION_MODEL_ROOT",
    r"D:\XINAO_RESEARCH_RUNTIME\state\personal_decision_model",
)
mcp = FastMCP("personal-decision-model")


def debug(message: str) -> None:
    if os.environ.get("XINAO_PDM_MCP_DEBUG") == "1":
        print(f"PDM_MCP_DEBUG {message}", file=sys.stderr, flush=True)


def invoke(*args: str) -> dict[str, Any]:
    debug(f"invoke_start args={args!r}")
    child_env = os.environ.copy()
    child_env["PYTHONUTF8"] = "1"
    child_env["PYTHONIOENCODING"] = "utf-8"
    completed = subprocess.run(
        [sys.executable, str(SCRIPT), "--root", MODEL_ROOT, *args],
        check=False,
        stdin=subprocess.DEVNULL,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        env=child_env,
    )
    debug(f"subprocess_end returncode={completed.returncode} stdout_bytes={len(completed.stdout)} stderr_bytes={len(completed.stderr)}")
    if completed.returncode != 0:
        raise RuntimeError(completed.stderr.strip() or f"pdm exit={completed.returncode}")
    value = json.loads(completed.stdout)
    if not isinstance(value, dict):
        raise RuntimeError("pdm result must be an object")
    debug(f"invoke_end keys={sorted(value)}")
    return value


@mcp.tool()
def pdm_health() -> dict[str, Any]:
    """Check the isolated model database and optional local components."""
    return invoke("health")


@mcp.tool()
def pdm_retrieve(query: str, as_of: str = "", limit: int = 5) -> dict[str, Any]:
    """Retrieve relevant principles and analogous cases; never grants authority."""
    args = ["retrieve", "--query", query, "--limit", str(limit)]
    if as_of:
        args += ["--as-of", as_of]
    return invoke(*args)


@mcp.tool()
def pdm_explain(scenario: str, as_of: str = "", limit: int = 5) -> dict[str, Any]:
    """Build a traceable evidence bundle for explaining or predicting a decision."""
    args = ["explain", "--query", scenario, "--limit", str(limit)]
    if as_of:
        args += ["--as-of", as_of]
    return invoke(*args)


@mcp.tool()
def pdm_user_perspective_packet(
    scenario: str,
    as_of: str = "",
    max_sources: int = 3,
    max_chars: int = 9000,
) -> dict[str, Any]:
    """Return a bounded pre-scope user-perspective packet; never grants authority."""
    args = [
        "perspective-packet",
        "--query",
        scenario,
        "--max-sources",
        str(max_sources),
        "--max-chars",
        str(max_chars),
    ]
    if as_of:
        args += ["--as-of", as_of]
    return invoke(*args)


@mcp.tool()
def pdm_shape_candidates(context: dict[str, Any]) -> dict[str, Any]:
    """Preserve Owner-admitted candidate order (directional abstain) with bounded card context; explicit choice and Stop still override."""
    return invoke(
        "shape-candidates",
        "--payload-json",
        json.dumps(context, ensure_ascii=False),
    )


@mcp.tool()
def pdm_capture_correction(
    summary: str,
    source_ref: str,
    payload: dict[str, Any],
    occurred_at: str = "",
) -> dict[str, Any]:
    """Append one user correction as immutable evidence; it does not promote a rule."""
    args = [
        "capture",
        "--type",
        "correction",
        "--source-kind",
        "user_statement",
        "--source-ref",
        source_ref,
        "--summary",
        summary,
        "--payload-json",
        json.dumps(payload, ensure_ascii=False),
    ]
    if occurred_at:
        args += ["--occurred-at", occurred_at]
    return invoke(*args)


@mcp.tool()
def pdm_record_decision_trace(trace: dict[str, Any]) -> dict[str, Any]:
    """Append one sourced generation chain; it is evidence, not a promoted rule."""
    return invoke(
        "record-trace",
        "--payload-json",
        json.dumps(trace, ensure_ascii=False),
    )


@mcp.tool()
def pdm_record_shaping_card(card: dict[str, Any]) -> dict[str, Any]:
    """Append one versioned soft shaping card; activation never grants authority."""
    return invoke(
        "record-shaping-card",
        "--payload-json",
        json.dumps(card, ensure_ascii=False),
    )


@mcp.tool()
def pdm_propose_update(
    source_event_id: str,
    proposal_type: str,
    payload: dict[str, Any],
    impact_scope: list[str],
) -> dict[str, Any]:
    """Create a candidate model update; promotion and authority remain outside MCP."""
    return invoke(
        "propose",
        "--type",
        proposal_type,
        "--source-event-id",
        source_event_id,
        "--payload-json",
        json.dumps(payload, ensure_ascii=False),
        "--impact-scope-json",
        json.dumps(impact_scope, ensure_ascii=False),
    )


@mcp.tool()
def pdm_export(format: str = "json") -> dict[str, Any]:
    """Regenerate the current human or machine projection on demand."""
    if format not in {"json", "txt"}:
        raise ValueError("format must be json or txt")
    return invoke("export", "--format", format)


if __name__ == "__main__":
    mcp.run(transport="stdio")
