#!/usr/bin/env python3
"""Event-sourced personal decision model store and deterministic CLI.

The database is context, never authority.  Raw facts are append-only; current
views are derived from versioned facts and can be rebuilt or exported.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import sqlite3
import sys
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator, Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator

SCHEMA_VERSION = 3
DEFAULT_ROOT = Path(r"D:\XINAO_RESEARCH_RUNTIME\state\personal_decision_model")
DEFAULT_DB_NAME = "personal_decision_model.sqlite3"
TASK_STACK_SCHEMA = "personal_decision_model.task_stack.v1"
DEFAULT_TASK_STACK_NAME = "task_stack.v1.json"
FACT_TABLES = (
    "events",
    "event_links",
    "model_versions",
    "case_versions",
    "decision_trace_versions",
    "shaping_card_versions",
    "principle_versions",
    "relation_versions",
    "proposals",
    "proposal_decisions",
    "predictions",
    "outcomes",
    "evaluations",
)
PERSPECTIVE_PACKET_SCHEMA = "personal-decision-model.user-perspective-packet.v2"
PERSPECTIVE_PACKET_DEFAULT_MAX_CHARS = 9000
PERSPECTIVE_PACKET_MIN_CHARS = 6000
PERSPECTIVE_PACKET_MAX_CHARS = 20000
PERSPECTIVE_PACKET_FIELD_CHARS = 180
PERSPECTIVE_TRACE_KIND_BONUS = {
    "decoding_failure": 0.12,
    "problem_formation": 0.10,
    "meta_case": 0.08,
    "decision": 0.05,
    "model_maintenance": 0.02,
}


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def json_object(raw: str, label: str) -> dict[str, Any]:
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"{label} must be valid JSON: {exc}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"{label} must be a JSON object")
    return value


def root_path(raw: str | None = None) -> Path:
    value = raw or os.environ.get("XINAO_PERSONAL_DECISION_MODEL_ROOT")
    return Path(value).expanduser() if value else DEFAULT_ROOT


def db_path(raw_db: str | None, raw_root: str | None) -> Path:
    return Path(raw_db).expanduser() if raw_db else root_path(raw_root) / DEFAULT_DB_NAME


def task_stack_path(raw_root: str | None) -> Path:
    return root_path(raw_root) / DEFAULT_TASK_STACK_NAME


def empty_task_stack() -> TaskStackDocument:
    return TaskStackDocument(updated_at=now())


def load_task_stack(path: Path) -> TaskStackDocument:
    if not path.exists():
        return empty_task_stack()
    return TaskStackDocument.model_validate_json(path.read_text(encoding="utf-8-sig"))


def write_task_stack(path: Path, stack: TaskStackDocument) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    stack.updated_at = now()
    content = json.dumps(
        stack.model_dump(mode="json"), ensure_ascii=False, indent=2, sort_keys=True
    ) + "\n"
    temporary = path.with_name(
        f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp"
    )
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


@contextmanager
def task_stack_lock(path: Path, timeout_seconds: float = 5.0) -> Iterator[None]:
    lock_path = path.with_suffix(path.suffix + ".lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a+b") as handle:
        handle.seek(0, os.SEEK_END)
        if handle.tell() == 0:
            handle.write(b"\0")
            handle.flush()
        started = time.monotonic()
        while True:
            try:
                handle.seek(0)
                if os.name == "nt":
                    import msvcrt

                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl

                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError as exc:
                if time.monotonic() - started >= timeout_seconds:
                    raise TimeoutError(
                        f"timed out acquiring task stack lock: {lock_path}"
                    ) from exc
                time.sleep(0.05)
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def task_frame_digest(item: TaskFrameInput) -> str:
    return sha256_text(canonical(item.model_dump(mode="json")))


def task_frame_record(item: TaskFrameInput) -> TaskFrameRecord:
    return TaskFrameRecord(
        **item.model_dump(mode="json"),
        paused_at=now(),
        parent_state_sha256=task_frame_digest(item),
    )


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class TaskFrameInput(StrictModel):
    frame_id: str = Field(min_length=1, pattern=r"^[A-Za-z0-9][A-Za-z0-9._:-]*$")
    parent_task_id: str = Field(min_length=1)
    window_role: str = Field(min_length=1)
    parent_goal: str = Field(min_length=1)
    completed_do_not_reopen: list[str] = Field(default_factory=list)
    pending: list[str] = Field(default_factory=list)
    next_step: str = Field(min_length=1)
    inserted_child_id: str = Field(min_length=1)
    return_to: str = Field(min_length=1)
    source_heads: dict[str, str] = Field(default_factory=dict)
    explicit_exclusions: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_task_frame(self) -> "TaskFrameInput":
        if self.parent_task_id == self.inserted_child_id:
            raise ValueError("inserted_child_id must differ from parent_task_id")
        for label, values in (
            ("completed_do_not_reopen", self.completed_do_not_reopen),
            ("pending", self.pending),
            ("explicit_exclusions", self.explicit_exclusions),
        ):
            if len(values) != len(set(values)):
                raise ValueError(f"{label} must not contain duplicates")
        overlap = set(self.completed_do_not_reopen) & set(self.pending)
        if overlap:
            raise ValueError(
                "completed_do_not_reopen and pending must be disjoint: "
                + ", ".join(sorted(overlap))
            )
        return self


class TaskFrameRecord(TaskFrameInput):
    paused_at: str
    parent_state_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")


class TaskResumeRecord(TaskFrameRecord):
    resumed_at: str
    child_status: Literal["verified", "partial", "blocked", "not_applicable"]
    child_result_ref: str | None = None


class TaskStackDocument(StrictModel):
    schema_version: Literal["personal_decision_model.task_stack.v1"] = TASK_STACK_SCHEMA
    updated_at: str
    active_frames: list[TaskFrameRecord] = Field(default_factory=list)
    resume_history: list[TaskResumeRecord] = Field(default_factory=list)
    authority: Literal[False] = False
    completion_claim_allowed: Literal[False] = False

    @model_validator(mode="after")
    def validate_frame_id_uniqueness(self) -> "TaskStackDocument":
        frame_ids = [
            frame.frame_id for frame in [*self.active_frames, *self.resume_history]
        ]
        if len(frame_ids) != len(set(frame_ids)):
            raise ValueError(
                "frame_id must be unique across active_frames and resume_history"
            )
        return self


class EventInput(StrictModel):
    event_id: str | None = None
    event_type: Literal[
        "correction", "case", "decision", "outcome", "observation", "promotion", "maintenance"
    ]
    occurred_at: str
    source_kind: str = "user_statement"
    source_ref: str
    summary: str = Field(min_length=1)
    payload: dict[str, Any] = Field(default_factory=dict)
    parent_event_id: str | None = None
    actor: str = "codex-owner"


class CaseInput(StrictModel):
    case_key: str
    title: str
    domain: str
    valid_from: str
    status: Literal["active", "superseded", "rejected"] = "active"
    parent_result: str
    constraints: list[str] = Field(default_factory=list)
    candidates: list[str] = Field(default_factory=list)
    decision: str
    result: str
    counterfactuals: list[str] = Field(default_factory=list)
    source_event_id: str


class DecisionTraceInput(StrictModel):
    trace_key: str
    title: str
    domain: str
    trace_kind: Literal[
        "decision",
        "problem_formation",
        "meta_case",
        "decoding_failure",
        "model_maintenance",
    ]
    valid_from: str
    status: Literal["active", "superseded", "rejected"] = "active"
    parent_trace_key: str | None = None
    historical_anchors: list[str] = Field(default_factory=list)
    parent_result: str
    observed_state: str
    problem_definition: str
    violated_expectations: list[str] = Field(default_factory=list)
    harms_or_burdens: list[str] = Field(default_factory=list)
    active_constraints: list[str] = Field(default_factory=list)
    candidates: list[str] = Field(default_factory=list)
    counterfactuals: list[str] = Field(default_factory=list)
    decision: str
    result: str
    feedback: list[str] = Field(default_factory=list)
    assumption_updates: list[str] = Field(default_factory=list)
    discourse_level_cues: list[str] = Field(default_factory=list)
    mistaken_subject: str | None = None
    intended_subject: str | None = None
    correction: str | None = None
    source_event_id: str

    @model_validator(mode="after")
    def validate_trace_shape(self) -> "DecisionTraceInput":
        if self.parent_trace_key == self.trace_key:
            raise ValueError("parent_trace_key cannot equal trace_key")
        if self.trace_kind == "decoding_failure":
            required = {
                "discourse_level_cues": bool(self.discourse_level_cues),
                "mistaken_subject": bool(self.mistaken_subject),
                "intended_subject": bool(self.intended_subject),
                "correction": bool(self.correction),
            }
            missing = [name for name, present in required.items() if not present]
            if missing:
                raise ValueError(
                    "decoding_failure requires " + ", ".join(missing)
                )
        return self


class ShapingCardInput(StrictModel):
    card_key: str
    title: str
    domain: str
    valid_from: str
    status: Literal["active", "superseded", "retired", "rejected"] = "active"
    trigger_contexts: list[str] = Field(min_length=1)
    activation_terms: list[str] = Field(default_factory=list)
    default_tendency: str = Field(min_length=1)
    suppressed_tendencies: list[str] = Field(default_factory=list)
    applicability_bounds: list[str] = Field(min_length=1)
    suppression_contexts: list[str] = Field(default_factory=list)
    counterexamples: list[str] = Field(default_factory=list)
    episode_trace_keys: list[str] = Field(min_length=1)
    evidence_event_ids: list[str] = Field(min_length=1)
    salience: float = Field(default=0.8, ge=0, le=1)
    confidence: float = Field(default=0.5, ge=0, le=1)
    recurrence_count: int = Field(default=1, ge=1)
    last_confirmed_at: str
    decay_half_life_days: float = Field(default=180.0, gt=0)
    source_event_id: str

    @model_validator(mode="after")
    def validate_shaping_card(self) -> "ShapingCardInput":
        if self.source_event_id not in self.evidence_event_ids:
            raise ValueError("source_event_id must be present in evidence_event_ids")
        if len(self.evidence_event_ids) != len(set(self.evidence_event_ids)):
            raise ValueError("evidence_event_ids must be unique")
        if len(self.episode_trace_keys) != len(set(self.episode_trace_keys)):
            raise ValueError("episode_trace_keys must be unique")
        return self


class PrincipleInput(StrictModel):
    principle_key: str
    name: str
    statement: str
    rationale: str
    scope: list[str] = Field(default_factory=list)
    conditions: list[str] = Field(default_factory=list)
    priority: int = 50
    confidence: float = Field(default=0.5, ge=0, le=1)
    status: Literal["active", "candidate", "retired", "rejected"] = "candidate"
    valid_from: str
    source_event_id: str


class RelationInput(StrictModel):
    relation_key: str
    subject_type: Literal["case", "trace", "principle", "model", "event", "prediction"]
    subject_id: str
    predicate: str
    object_type: Literal["case", "trace", "principle", "model", "event", "prediction"]
    object_id: str
    status: Literal["asserted", "retracted"] = "asserted"
    valid_from: str
    confidence: float = Field(default=0.5, ge=0, le=1)
    source_event_id: str


class ModelVersionInput(StrictModel):
    model_version_id: str
    parent_version_id: str | None = None
    status: Literal["candidate", "promoted", "rejected"] = "candidate"
    thesis: str
    decision_procedure: list[str]
    self_update_policy: list[str]
    evaluation: dict[str, Any] = Field(default_factory=dict)
    source_event_id: str


class SeedInput(StrictModel):
    seed_id: str
    events: list[EventInput]
    cases: list[CaseInput]
    decision_traces: list[DecisionTraceInput] = Field(default_factory=list)
    shaping_cards: list[ShapingCardInput] = Field(default_factory=list)
    principles: list[PrincipleInput]
    relations: list[RelationInput] = Field(default_factory=list)
    model_version: ModelVersionInput


class ReplayCaseInput(StrictModel):
    scenario_id: str
    scenario: str
    predicted_choice: str
    actual_choice: str
    reasoning: dict[str, Any]
    confidence: float = Field(default=0.5, ge=0, le=1)
    result: str


class ReplayFixtureInput(StrictModel):
    dataset_ref: str
    model_version_id: str | None = None
    source_event: EventInput
    cases: list[ReplayCaseInput] = Field(min_length=1)


class ShapeCandidateInput(StrictModel):
    candidate_id: str = Field(min_length=1, max_length=120)
    text: str = Field(min_length=1, max_length=1000)


class ShapeCandidatesInput(StrictModel):
    scenario: str = Field(min_length=1, max_length=1000)
    candidates: list[ShapeCandidateInput] = Field(min_length=1, max_length=50)
    as_of: str | None = None
    stop: bool = False
    explicit_choice_id: str | None = None

    @model_validator(mode="after")
    def validate_candidate_identity(self) -> "ShapeCandidatesInput":
        candidate_ids = [item.candidate_id for item in self.candidates]
        if len(candidate_ids) != len(set(candidate_ids)):
            raise ValueError("candidate_id values must be unique")
        if self.explicit_choice_id and self.explicit_choice_id not in candidate_ids:
            raise ValueError("explicit_choice_id must name an existing candidate")
        return self


DDL = """
CREATE TABLE IF NOT EXISTS schema_migrations(
  version INTEGER PRIMARY KEY,
  applied_at TEXT NOT NULL,
  migration_sha256 TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS meta(
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS events(
  event_id TEXT PRIMARY KEY,
  event_type TEXT NOT NULL,
  occurred_at TEXT NOT NULL,
  recorded_at TEXT NOT NULL,
  source_kind TEXT NOT NULL,
  source_ref TEXT NOT NULL,
  summary TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  parent_event_id TEXT REFERENCES events(event_id),
  actor TEXT NOT NULL,
  content_sha256 TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS event_links(
  link_id TEXT PRIMARY KEY,
  from_event_id TEXT NOT NULL REFERENCES events(event_id),
  relation TEXT NOT NULL,
  to_event_id TEXT NOT NULL REFERENCES events(event_id),
  recorded_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS model_versions(
  model_version_id TEXT PRIMARY KEY,
  parent_version_id TEXT REFERENCES model_versions(model_version_id),
  status TEXT NOT NULL,
  thesis TEXT NOT NULL,
  decision_procedure_json TEXT NOT NULL,
  self_update_policy_json TEXT NOT NULL,
  evaluation_json TEXT NOT NULL,
  source_event_id TEXT NOT NULL REFERENCES events(event_id),
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS case_versions(
  case_version_id TEXT PRIMARY KEY,
  case_key TEXT NOT NULL,
  version_number INTEGER NOT NULL,
  valid_from TEXT NOT NULL,
  status TEXT NOT NULL,
  title TEXT NOT NULL,
  domain TEXT NOT NULL,
  parent_result TEXT NOT NULL,
  constraints_json TEXT NOT NULL,
  candidates_json TEXT NOT NULL,
  decision TEXT NOT NULL,
  result TEXT NOT NULL,
  counterfactuals_json TEXT NOT NULL,
  source_event_id TEXT NOT NULL REFERENCES events(event_id),
  recorded_at TEXT NOT NULL,
  UNIQUE(case_key, version_number)
);
CREATE TABLE IF NOT EXISTS decision_trace_versions(
  trace_version_id TEXT PRIMARY KEY,
  trace_key TEXT NOT NULL,
  version_number INTEGER NOT NULL,
  valid_from TEXT NOT NULL,
  status TEXT NOT NULL,
  trace_kind TEXT NOT NULL,
  title TEXT NOT NULL,
  domain TEXT NOT NULL,
  parent_trace_key TEXT,
  historical_anchors_json TEXT NOT NULL,
  parent_result TEXT NOT NULL,
  observed_state TEXT NOT NULL,
  problem_definition TEXT NOT NULL,
  violated_expectations_json TEXT NOT NULL,
  harms_or_burdens_json TEXT NOT NULL,
  active_constraints_json TEXT NOT NULL,
  candidates_json TEXT NOT NULL,
  counterfactuals_json TEXT NOT NULL,
  decision TEXT NOT NULL,
  result TEXT NOT NULL,
  feedback_json TEXT NOT NULL,
  assumption_updates_json TEXT NOT NULL,
  discourse_level_cues_json TEXT NOT NULL,
  mistaken_subject TEXT,
  intended_subject TEXT,
  correction TEXT,
  source_event_id TEXT NOT NULL REFERENCES events(event_id),
  recorded_at TEXT NOT NULL,
  content_sha256 TEXT NOT NULL,
  UNIQUE(trace_key, version_number),
  UNIQUE(trace_key, content_sha256)
);
CREATE TABLE IF NOT EXISTS shaping_card_versions(
  shaping_card_version_id TEXT PRIMARY KEY,
  card_key TEXT NOT NULL,
  version_number INTEGER NOT NULL,
  valid_from TEXT NOT NULL,
  status TEXT NOT NULL,
  title TEXT NOT NULL,
  domain TEXT NOT NULL,
  trigger_contexts_json TEXT NOT NULL,
  activation_terms_json TEXT NOT NULL,
  default_tendency TEXT NOT NULL,
  suppressed_tendencies_json TEXT NOT NULL,
  applicability_bounds_json TEXT NOT NULL,
  suppression_contexts_json TEXT NOT NULL,
  counterexamples_json TEXT NOT NULL,
  episode_trace_keys_json TEXT NOT NULL,
  evidence_event_ids_json TEXT NOT NULL,
  salience REAL NOT NULL,
  confidence REAL NOT NULL,
  recurrence_count INTEGER NOT NULL,
  last_confirmed_at TEXT NOT NULL,
  decay_half_life_days REAL NOT NULL,
  source_event_id TEXT NOT NULL REFERENCES events(event_id),
  recorded_at TEXT NOT NULL,
  content_sha256 TEXT NOT NULL,
  UNIQUE(card_key, version_number),
  UNIQUE(card_key, content_sha256)
);
CREATE TABLE IF NOT EXISTS principle_versions(
  principle_version_id TEXT PRIMARY KEY,
  principle_key TEXT NOT NULL,
  version_number INTEGER NOT NULL,
  valid_from TEXT NOT NULL,
  status TEXT NOT NULL,
  name TEXT NOT NULL,
  statement TEXT NOT NULL,
  rationale TEXT NOT NULL,
  scope_json TEXT NOT NULL,
  conditions_json TEXT NOT NULL,
  priority INTEGER NOT NULL,
  confidence REAL NOT NULL,
  source_event_id TEXT NOT NULL REFERENCES events(event_id),
  model_version_id TEXT REFERENCES model_versions(model_version_id),
  recorded_at TEXT NOT NULL,
  UNIQUE(principle_key, version_number)
);
CREATE TABLE IF NOT EXISTS relation_versions(
  relation_version_id TEXT PRIMARY KEY,
  relation_key TEXT NOT NULL,
  version_number INTEGER NOT NULL,
  subject_type TEXT NOT NULL,
  subject_id TEXT NOT NULL,
  predicate TEXT NOT NULL,
  object_type TEXT NOT NULL,
  object_id TEXT NOT NULL,
  status TEXT NOT NULL,
  valid_from TEXT NOT NULL,
  confidence REAL NOT NULL,
  source_event_id TEXT NOT NULL REFERENCES events(event_id),
  recorded_at TEXT NOT NULL,
  UNIQUE(relation_key, version_number)
);
CREATE TABLE IF NOT EXISTS proposals(
  proposal_id TEXT PRIMARY KEY,
  proposal_type TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  impact_scope_json TEXT NOT NULL,
  source_event_id TEXT NOT NULL REFERENCES events(event_id),
  created_at TEXT NOT NULL,
  content_sha256 TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS proposal_decisions(
  proposal_decision_id TEXT PRIMARY KEY,
  proposal_id TEXT NOT NULL REFERENCES proposals(proposal_id),
  decision TEXT NOT NULL,
  reason TEXT NOT NULL,
  evaluation_id TEXT REFERENCES evaluations(evaluation_id),
  source_event_id TEXT NOT NULL REFERENCES events(event_id),
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS predictions(
  prediction_id TEXT PRIMARY KEY,
  model_version_id TEXT NOT NULL REFERENCES model_versions(model_version_id),
  scenario TEXT NOT NULL,
  predicted_choice TEXT NOT NULL,
  reasoning_json TEXT NOT NULL,
  confidence REAL NOT NULL,
  source_event_id TEXT NOT NULL REFERENCES events(event_id),
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS outcomes(
  outcome_id TEXT PRIMARY KEY,
  prediction_id TEXT NOT NULL REFERENCES predictions(prediction_id),
  actual_choice TEXT NOT NULL,
  result TEXT NOT NULL,
  source_event_id TEXT NOT NULL REFERENCES events(event_id),
  observed_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS evaluations(
  evaluation_id TEXT PRIMARY KEY,
  model_version_id TEXT NOT NULL REFERENCES model_versions(model_version_id),
  evaluation_kind TEXT NOT NULL,
  dataset_ref TEXT NOT NULL,
  metrics_json TEXT NOT NULL,
  verdict TEXT NOT NULL,
  source_event_id TEXT NOT NULL REFERENCES events(event_id),
  created_at TEXT NOT NULL
);
CREATE VIRTUAL TABLE IF NOT EXISTS search_index USING fts5(
  object_type UNINDEXED,
  object_id UNINDEXED,
  title,
  body,
  tokenize='unicode61'
);
CREATE INDEX IF NOT EXISTS ix_case_key ON case_versions(case_key, version_number DESC);
CREATE INDEX IF NOT EXISTS ix_decision_trace_key ON decision_trace_versions(trace_key, version_number DESC);
CREATE INDEX IF NOT EXISTS ix_decision_trace_parent ON decision_trace_versions(parent_trace_key);
CREATE INDEX IF NOT EXISTS ix_shaping_card_key ON shaping_card_versions(card_key, version_number DESC);
CREATE INDEX IF NOT EXISTS ix_principle_key ON principle_versions(principle_key, version_number DESC);
CREATE INDEX IF NOT EXISTS ix_relation_key ON relation_versions(relation_key, version_number DESC);
CREATE INDEX IF NOT EXISTS ix_event_occurred ON events(occurred_at);
"""


READ_ONLY_ACTIONS = frozenset(
    {
        "health",
        "perspective-packet",
        "shape-candidates",
        "retrieve",
        "explain",
        "simulate",
    }
)


def connect(path: Path, *, read_only: bool = False) -> sqlite3.Connection:
    if read_only:
        if not path.is_file():
            raise FileNotFoundError(f"read-only database missing: {path}")
        uri = f"{path.resolve().as_uri()}?mode=ro&immutable=1"
        db = sqlite3.connect(uri, uri=True)
        db.execute("PRAGMA query_only=ON")
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        db = sqlite3.connect(path)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    db.execute("PRAGMA busy_timeout=5000")
    if not read_only:
        db.execute("PRAGMA journal_mode=WAL")
    return db


def init_schema(db: sqlite3.Connection) -> None:
    db.executescript(DDL)
    migration_hash = sha256_text(DDL)
    db.execute(
        "INSERT OR IGNORE INTO schema_migrations(version,applied_at,migration_sha256) VALUES(?,?,?)",
        (SCHEMA_VERSION, now(), migration_hash),
    )
    for table in FACT_TABLES:
        db.execute(
            f"CREATE TRIGGER IF NOT EXISTS {table}_no_update BEFORE UPDATE ON {table} "
            f"BEGIN SELECT RAISE(ABORT, '{table} is append-only'); END"
        )
        db.execute(
            f"CREATE TRIGGER IF NOT EXISTS {table}_no_delete BEFORE DELETE ON {table} "
            f"BEGIN SELECT RAISE(ABORT, '{table} is append-only'); END"
        )
    db.commit()


def ensure_event(db: sqlite3.Connection, item: EventInput) -> str:
    payload = item.model_dump(exclude={"event_id"})
    digest = sha256_text(canonical(payload))
    event_id = item.event_id or f"evt-{digest[:24]}"
    existing = db.execute("SELECT content_sha256 FROM events WHERE event_id=?", (event_id,)).fetchone()
    if existing:
        if existing[0] != digest:
            raise ValueError(f"event identity drift: {event_id}")
        return event_id
    if item.parent_event_id and not db.execute(
        "SELECT 1 FROM events WHERE event_id=?", (item.parent_event_id,)
    ).fetchone():
        raise ValueError(f"parent event missing: {item.parent_event_id}")
    db.execute(
        "INSERT INTO events VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        (
            event_id,
            item.event_type,
            item.occurred_at,
            now(),
            item.source_kind,
            item.source_ref,
            item.summary,
            canonical(item.payload),
            item.parent_event_id,
            item.actor,
            digest,
        ),
    )
    db.execute(
        "INSERT INTO search_index(object_type,object_id,title,body) VALUES('event',?,?,?)",
        (event_id, item.summary, canonical(item.payload)),
    )
    return event_id


def next_version(db: sqlite3.Connection, table: str, key_name: str, key: str) -> int:
    row = db.execute(
        f"SELECT COALESCE(MAX(version_number),0)+1 FROM {table} WHERE {key_name}=?", (key,)
    ).fetchone()
    return int(row[0])


def insert_case(db: sqlite3.Connection, item: CaseInput) -> str:
    version = next_version(db, "case_versions", "case_key", item.case_key)
    version_id = f"casev-{sha256_text(canonical(item.model_dump()) + str(version))[:24]}"
    db.execute(
        "INSERT INTO case_versions VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            version_id,
            item.case_key,
            version,
            item.valid_from,
            item.status,
            item.title,
            item.domain,
            item.parent_result,
            canonical(item.constraints),
            canonical(item.candidates),
            item.decision,
            item.result,
            canonical(item.counterfactuals),
            item.source_event_id,
            now(),
        ),
    )
    db.execute(
        "INSERT INTO search_index(object_type,object_id,title,body) VALUES('case',?,?,?)",
        (item.case_key, item.title, canonical(item.model_dump())),
    )
    return version_id


def insert_decision_trace(db: sqlite3.Connection, item: DecisionTraceInput) -> str:
    if not db.execute(
        "SELECT 1 FROM events WHERE event_id=?", (item.source_event_id,)
    ).fetchone():
        raise ValueError(f"source event missing: {item.source_event_id}")
    if item.parent_trace_key and not db.execute(
        "SELECT 1 FROM decision_trace_versions WHERE trace_key=?",
        (item.parent_trace_key,),
    ).fetchone():
        raise ValueError(f"parent trace missing: {item.parent_trace_key}")
    digest = sha256_text(canonical(item.model_dump()))
    existing = db.execute(
        """SELECT trace_version_id FROM decision_trace_versions
           WHERE trace_key=? AND content_sha256=?""",
        (item.trace_key, digest),
    ).fetchone()
    if existing:
        return str(existing[0])
    version = next_version(
        db, "decision_trace_versions", "trace_key", item.trace_key
    )
    version_id = f"tracev-{digest[:20]}-{version}"
    db.execute(
        """INSERT INTO decision_trace_versions(
        trace_version_id,trace_key,version_number,valid_from,status,trace_kind,title,domain,
        parent_trace_key,historical_anchors_json,parent_result,observed_state,problem_definition,
        violated_expectations_json,harms_or_burdens_json,active_constraints_json,candidates_json,
        counterfactuals_json,decision,result,feedback_json,assumption_updates_json,
        discourse_level_cues_json,mistaken_subject,intended_subject,correction,source_event_id,
        recorded_at,content_sha256
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            version_id,
            item.trace_key,
            version,
            item.valid_from,
            item.status,
            item.trace_kind,
            item.title,
            item.domain,
            item.parent_trace_key,
            canonical(item.historical_anchors),
            item.parent_result,
            item.observed_state,
            item.problem_definition,
            canonical(item.violated_expectations),
            canonical(item.harms_or_burdens),
            canonical(item.active_constraints),
            canonical(item.candidates),
            canonical(item.counterfactuals),
            item.decision,
            item.result,
            canonical(item.feedback),
            canonical(item.assumption_updates),
            canonical(item.discourse_level_cues),
            item.mistaken_subject,
            item.intended_subject,
            item.correction,
            item.source_event_id,
            now(),
            digest,
        ),
    )
    db.execute(
        "INSERT INTO search_index(object_type,object_id,title,body) VALUES('trace',?,?,?)",
        (item.trace_key, item.title, canonical(item.model_dump())),
    )
    return version_id


def insert_shaping_card(db: sqlite3.Connection, item: ShapingCardInput) -> str:
    missing_events = [
        event_id
        for event_id in item.evidence_event_ids
        if not db.execute(
            "SELECT 1 FROM events WHERE event_id=?", (event_id,)
        ).fetchone()
    ]
    if missing_events:
        raise ValueError(
            "shaping card evidence events missing: " + ", ".join(missing_events)
        )
    missing_traces = [
        trace_key
        for trace_key in item.episode_trace_keys
        if not db.execute(
            "SELECT 1 FROM decision_trace_versions WHERE trace_key=?", (trace_key,)
        ).fetchone()
    ]
    if missing_traces:
        raise ValueError(
            "shaping card episode traces missing: " + ", ".join(missing_traces)
        )
    digest = sha256_text(canonical(item.model_dump()))
    existing = db.execute(
        """SELECT shaping_card_version_id FROM shaping_card_versions
           WHERE card_key=? AND content_sha256=?""",
        (item.card_key, digest),
    ).fetchone()
    if existing:
        return str(existing[0])
    version = next_version(db, "shaping_card_versions", "card_key", item.card_key)
    version_id = f"shapingv-{digest[:20]}-{version}"
    db.execute(
        """INSERT INTO shaping_card_versions(
        shaping_card_version_id,card_key,version_number,valid_from,status,title,domain,
        trigger_contexts_json,activation_terms_json,default_tendency,
        suppressed_tendencies_json,applicability_bounds_json,suppression_contexts_json,
        counterexamples_json,episode_trace_keys_json,evidence_event_ids_json,salience,
        confidence,recurrence_count,last_confirmed_at,decay_half_life_days,source_event_id,
        recorded_at,content_sha256
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            version_id,
            item.card_key,
            version,
            item.valid_from,
            item.status,
            item.title,
            item.domain,
            canonical(item.trigger_contexts),
            canonical(item.activation_terms),
            item.default_tendency,
            canonical(item.suppressed_tendencies),
            canonical(item.applicability_bounds),
            canonical(item.suppression_contexts),
            canonical(item.counterexamples),
            canonical(item.episode_trace_keys),
            canonical(item.evidence_event_ids),
            item.salience,
            item.confidence,
            item.recurrence_count,
            item.last_confirmed_at,
            item.decay_half_life_days,
            item.source_event_id,
            now(),
            digest,
        ),
    )
    db.execute(
        "INSERT INTO search_index(object_type,object_id,title,body) VALUES('shaping_card',?,?,?)",
        (item.card_key, item.title, canonical(item.model_dump())),
    )
    return version_id


def insert_principle_exact(
    db: sqlite3.Connection, item: PrincipleInput, model_version_id: str | None
) -> str:
    version = next_version(db, "principle_versions", "principle_key", item.principle_key)
    version_id = f"principlev-{sha256_text(canonical(item.model_dump()) + str(version))[:24]}"
    db.execute(
        """INSERT INTO principle_versions(
        principle_version_id,principle_key,version_number,valid_from,status,name,statement,rationale,
        scope_json,conditions_json,priority,confidence,source_event_id,model_version_id,recorded_at
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            version_id,
            item.principle_key,
            version,
            item.valid_from,
            item.status,
            item.name,
            item.statement,
            item.rationale,
            canonical(item.scope),
            canonical(item.conditions),
            item.priority,
            item.confidence,
            item.source_event_id,
            model_version_id,
            now(),
        ),
    )
    db.execute(
        "INSERT INTO search_index(object_type,object_id,title,body) VALUES('principle',?,?,?)",
        (item.principle_key, item.name, item.statement + "\n" + item.rationale),
    )
    return version_id


def insert_relation(db: sqlite3.Connection, item: RelationInput) -> str:
    version = next_version(db, "relation_versions", "relation_key", item.relation_key)
    version_id = f"relationv-{sha256_text(canonical(item.model_dump()) + str(version))[:24]}"
    db.execute(
        """INSERT INTO relation_versions(
        relation_version_id,relation_key,version_number,subject_type,subject_id,predicate,
        object_type,object_id,status,valid_from,confidence,source_event_id,recorded_at
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            version_id,
            item.relation_key,
            version,
            item.subject_type,
            item.subject_id,
            item.predicate,
            item.object_type,
            item.object_id,
            item.status,
            item.valid_from,
            item.confidence,
            item.source_event_id,
            now(),
        ),
    )
    return version_id


def insert_model(db: sqlite3.Connection, item: ModelVersionInput) -> str:
    db.execute(
        "INSERT INTO model_versions VALUES(?,?,?,?,?,?,?,?,?)",
        (
            item.model_version_id,
            item.parent_version_id,
            item.status,
            item.thesis,
            canonical(item.decision_procedure),
            canonical(item.self_update_policy),
            canonical(item.evaluation),
            item.source_event_id,
            now(),
        ),
    )
    return item.model_version_id


def row_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    return dict(row) if row is not None else None


def active_rows(db: sqlite3.Connection, table: str, key: str, as_of: str | None) -> list[dict[str, Any]]:
    cutoff = as_of or "9999-12-31T23:59:59Z"
    sql = f"""
      SELECT t.* FROM {table} t
      JOIN (
        SELECT {key}, MAX(version_number) AS v FROM {table}
        WHERE valid_from<=? GROUP BY {key}
      ) x ON x.{key}=t.{key} AND x.v=t.version_number
    """
    return [dict(row) for row in db.execute(sql, (cutoff,)).fetchall()]


def current_model(db: sqlite3.Connection) -> dict[str, Any] | None:
    row = db.execute(
        "SELECT * FROM model_versions WHERE status='promoted' ORDER BY created_at DESC,rowid DESC LIMIT 1"
    ).fetchone()
    value = row_dict(row)
    if value:
        for field in ("decision_procedure_json", "self_update_policy_json", "evaluation_json"):
            value[field[:-5]] = json.loads(value.pop(field))
    return value


def tokenize(text: str) -> set[str]:
    lowered = text.lower()
    words = set(re.findall(r"[a-z0-9_\-]{2,}", lowered))
    han = "".join(re.findall(r"[\u4e00-\u9fff]", lowered))
    words.update(han[i : i + 2] for i in range(max(0, len(han) - 1)))
    return {value for value in words if value}


def relevance(query: str, body: str) -> float:
    q = tokenize(query)
    b = tokenize(body)
    return 0.0 if not q else len(q & b) / len(q)


def row_json_strings(row: dict[str, Any], field: str) -> list[str]:
    raw = row.get(f"{field}_json")
    if not isinstance(raw, str):
        return []
    try:
        value = json.loads(raw)
    except json.JSONDecodeError:
        return []
    if not isinstance(value, list):
        return []
    return [item for item in value if isinstance(item, str) and item]


def parse_instant(raw: str | None) -> datetime | None:
    if not raw:
        return None
    try:
        return datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return None


def explicit_shaping_override(scenario: str) -> str | None:
    normalized = " ".join(scenario.casefold().split())
    patterns = (
        (r"(?:不要|不再|禁止)(?:派工|使用工人|调用工人)", "current statement forbids worker dispatch"),
        (r"(?:停止|暂停)(?:任何|全部|当前)?(?:研究|任务|工作|行动)", "current statement stops or pauses the activity"),
        (r"只(?:用)?一句话", "current statement requests a one-off bounded answer"),
        (r"(?:明确)?单线程", "current statement requests single-thread execution"),
        (r"\b(?:stop|pause)\b", "current statement stops or pauses the activity"),
        (r"\b(?:no workers|do not dispatch|single-thread(?:ed)?)\b", "current statement forbids worker breadth"),
        (r"(?:不要|不再)(?:记住|使用)(?:过去|历史)?(?:偏好|记忆)", "current statement suppresses remembered preferences"),
    )
    for pattern, reason in patterns:
        if re.search(pattern, normalized):
            return reason
    return None


def shaping_activation(
    row: dict[str, Any], scenario: str, as_of: str | None
) -> dict[str, Any]:
    positive_text = " ".join(
        [
            str(row.get("title") or ""),
            str(row.get("domain") or ""),
            str(row.get("default_tendency") or ""),
            *row_json_strings(row, "trigger_contexts"),
            *row_json_strings(row, "activation_terms"),
            *row_json_strings(row, "applicability_bounds"),
        ]
    )
    negative_text = " ".join(
        [
            *row_json_strings(row, "suppression_contexts"),
            *row_json_strings(row, "counterexamples"),
        ]
    )
    semantic_relevance = relevance(scenario, positive_text)
    suppression_relevance = relevance(scenario, negative_text)
    reference_time = parse_instant(as_of) or datetime.now(timezone.utc)
    confirmed_time = parse_instant(str(row.get("last_confirmed_at") or ""))
    age_days = 0.0
    if confirmed_time is not None:
        age_days = max(0.0, (reference_time - confirmed_time).total_seconds() / 86400.0)
    half_life = max(1.0, float(row.get("decay_half_life_days") or 180.0))
    recency_factor = 0.35 + 0.65 * math.pow(2.0, -age_days / half_life)
    recurrence_count = max(1, int(row.get("recurrence_count") or 1))
    recurrence_factor = 1.0 + min(0.35, 0.1 * math.log2(recurrence_count))
    salience = float(row.get("salience") or 0.0)
    confidence = float(row.get("confidence") or 0.0)
    shaping_weight = 0.45 + (0.35 * salience) + (0.20 * confidence)
    explicit_override = explicit_shaping_override(scenario)
    suppressed = bool(explicit_override) or (
        suppression_relevance >= 0.25
        and suppression_relevance >= semantic_relevance * 0.75
    )
    raw_score = semantic_relevance * shaping_weight * recurrence_factor * recency_factor
    activation_score = (
        0.0 if suppressed else max(0.0, raw_score - (0.25 * suppression_relevance))
    )
    return {
        "semantic_relevance": semantic_relevance,
        "suppression_relevance": suppression_relevance,
        "salience": salience,
        "confidence": confidence,
        "recurrence_count": recurrence_count,
        "recency_factor": recency_factor,
        "age_days": age_days,
        "activation_score": activation_score,
        "suppressed": suppressed,
        "suppression_reason": explicit_override,
    }


def explanation_bundle(db: sqlite3.Connection, scenario: str, as_of: str | None, limit: int) -> dict[str, Any]:
    principles = [row for row in active_rows(db, "principle_versions", "principle_key", as_of) if row["status"] == "active"]
    cases = [row for row in active_rows(db, "case_versions", "case_key", as_of) if row["status"] == "active"]
    traces = [
        row
        for row in active_rows(
            db, "decision_trace_versions", "trace_key", as_of
        )
        if row["status"] == "active"
    ]
    shaping_cards = [
        row
        for row in active_rows(
            db, "shaping_card_versions", "card_key", as_of
        )
        if row["status"] == "active"
    ]
    for row in principles:
        row["relevance"] = relevance(scenario, row["name"] + " " + row["statement"] + " " + row["rationale"])
    for row in cases:
        row["relevance"] = relevance(scenario, row["title"] + " " + row["parent_result"] + " " + row["decision"] + " " + row["result"])
    for row in traces:
        row["relevance"] = relevance(
            scenario,
            " ".join(
                [
                    row["title"],
                    row["parent_result"],
                    row["observed_state"],
                    row["problem_definition"],
                    row["decision"],
                    row["result"],
                    row["mistaken_subject"] or "",
                    row["intended_subject"] or "",
                ]
            ),
        )
    for row in shaping_cards:
        row.update(shaping_activation(row, scenario, as_of))
    principles.sort(key=lambda row: (row["relevance"], row["priority"], row["confidence"]), reverse=True)
    cases.sort(key=lambda row: (row["relevance"], row["valid_from"]), reverse=True)
    traces.sort(
        key=lambda row: (row["relevance"], row["valid_from"]), reverse=True
    )
    active_shaping_cards = [
        row
        for row in shaping_cards
        if not row["suppressed"] and float(row["activation_score"]) > 0
    ]
    suppressed_shaping_cards = [row for row in shaping_cards if row["suppressed"]]
    active_shaping_cards.sort(
        key=lambda row: (
            row["activation_score"],
            row["last_confirmed_at"],
            row["valid_from"],
        ),
        reverse=True,
    )
    suppressed_shaping_cards.sort(
        key=lambda row: (
            row["suppression_relevance"],
            row["last_confirmed_at"],
        ),
        reverse=True,
    )
    model = current_model(db)
    return {
        "schema_version": "personal-decision-model.explanation-bundle.v2",
        "scenario": scenario,
        "as_of": as_of or now(),
        "model": model,
        "relevant_principles": principles[:limit],
        "analogous_cases": cases[:limit],
        "relevant_decision_traces": traces[:limit],
        "relevant_shaping_cards": active_shaping_cards[:limit],
        "suppressed_shaping_cards": suppressed_shaping_cards[:limit],
        "decision_instruction": "Preserve the generation chain and discourse level. Use cited traces, cases, and active principles; recover how the user defines the problem, settle current constraints, state uncertainty and counterfactuals, then make one prediction. Do not infer authorization.",
        "authority": False,
        "completion_claim_allowed": False,
    }


def packet_text(value: Any, max_chars: int = PERSPECTIVE_PACKET_FIELD_CHARS) -> str | None:
    if not isinstance(value, str):
        return None
    normalized = " ".join(value.split())
    if not normalized or "\ufffd" in normalized or "\x00" in normalized:
        return None
    if len(re.findall(r"(?:Ã.|Â.|â€|ðŸ)", normalized)) >= 2:
        return None
    if len(normalized) <= max_chars:
        return normalized
    return normalized[: max_chars - 1].rstrip() + "…"


def packet_json_list(row: dict[str, Any], field: str) -> list[str]:
    raw = row.get(f"{field}_json")
    if not isinstance(raw, str):
        return []
    try:
        value = json.loads(raw)
    except json.JSONDecodeError:
        return []
    if not isinstance(value, list):
        return []
    result: list[str] = []
    for item in value:
        text = packet_text(item)
        if text and text not in result:
            result.append(text)
    return result


def packet_source(row: dict[str, Any], source_type: Literal["trace", "case"]) -> dict[str, Any]:
    source_id = row["trace_key"] if source_type == "trace" else row["case_key"]
    value: dict[str, Any] = {
        "source_type": source_type,
        "source_id": source_id,
        "source_event_id": row["source_event_id"],
        "relevance": round(float(row.get("relevance", 0.0)), 6),
    }
    title = packet_text(row.get("title"), 120)
    if title:
        value["title"] = title
    if source_type == "trace":
        value["trace_kind"] = row["trace_kind"]
        lineage = packet_json_list(row, "historical_anchors")[:3]
        if lineage:
            value["lineage_ids"] = [packet_text(item, 100) for item in lineage]
    return value


def shaping_card_packet(
    db: sqlite3.Connection, row: dict[str, Any], as_of: str | None
) -> dict[str, Any]:
    trace_keys = row_json_strings(row, "episode_trace_keys")
    evidence_event_ids = row_json_strings(row, "evidence_event_ids")
    episode: dict[str, Any] | None = None
    if trace_keys:
        cutoff = as_of or "9999-12-31T23:59:59Z"
        trace = db.execute(
            """SELECT * FROM decision_trace_versions
               WHERE trace_key=? AND valid_from<=?
               ORDER BY version_number DESC LIMIT 1""",
            (trace_keys[0], cutoff),
        ).fetchone()
        if trace is not None:
            trace_row = dict(trace)
            excerpt = (
                packet_text(trace_row.get("correction"))
                or packet_text(trace_row.get("problem_definition"))
                or packet_text(trace_row.get("decision"))
            )
            episode = {
                "trace_id": trace_row["trace_key"],
                "source_event_id": trace_row["source_event_id"],
                "title": packet_text(trace_row.get("title"), 120),
                "correction_excerpt": excerpt,
            }
    return {
        "card_id": row["card_key"],
        "source_event_id": row["source_event_id"],
        "title": packet_text(row.get("title"), 120),
        "domain": packet_text(row.get("domain"), 100),
        "default_tendency": packet_text(row.get("default_tendency")),
        "suppressed_tendencies": [
            value
            for value in (
                packet_text(item) for item in row_json_strings(row, "suppressed_tendencies")[:3]
            )
            if value
        ],
        "applicability_bounds": [
            value
            for value in (
                packet_text(item) for item in row_json_strings(row, "applicability_bounds")[:3]
            )
            if value
        ],
        "counterexamples": [
            value
            for value in (
                packet_text(item) for item in row_json_strings(row, "counterexamples")[:2]
            )
            if value
        ],
        "episode": episode,
        "evidence_event_ids": evidence_event_ids[:5],
        "activation": {
            "score": round(float(row.get("activation_score", 0.0)), 6),
            "semantic_relevance": round(float(row.get("semantic_relevance", 0.0)), 6),
            "salience": round(float(row.get("salience", 0.0)), 6),
            "confidence": round(float(row.get("confidence", 0.0)), 6),
            "recurrence_count": int(row.get("recurrence_count") or 1),
            "recency_factor": round(float(row.get("recency_factor", 0.0)), 6),
        },
        "authority": False,
        "must_revalidate_against_current_context": True,
    }


def packet_item(text: str | None, source: dict[str, Any], kind: str) -> dict[str, Any] | None:
    if not text:
        return None
    return {"kind": kind, "text": text, "source": source}


def append_packet_item(
    items: list[dict[str, Any]],
    text: str | None,
    source: dict[str, Any],
    kind: str,
    limit: int,
) -> None:
    item = packet_item(text, source, kind)
    if not item or any(existing["text"] == item["text"] for existing in items):
        return
    if len(items) < limit:
        items.append(item)


def packet_text_similarity(left: str, right: str) -> float:
    left_tokens = tokenize(left)
    right_tokens = tokenize(right)
    union = left_tokens | right_tokens
    return 1.0 if not union else len(left_tokens & right_tokens) / len(union)


def packet_serialized_chars(packet: dict[str, Any]) -> int:
    return len(canonical(packet))


def settle_packet_budget(packet: dict[str, Any], max_chars: int) -> dict[str, Any]:
    has_shaping_signal = bool(
        packet.get("shaping_hotspots") or packet.get("shaping_suppressions")
    )
    ordinary_evidence_minimum = 0 if has_shaping_signal else 1
    trim_order = (
        (
            "shaping_suppressions",
            1 if packet.get("shaping_suppressions") else 0,
        ),
        ("counterfactuals", 0),
        ("principles", ordinary_evidence_minimum),
        ("burdens", ordinary_evidence_minimum),
        ("hard_constraints", ordinary_evidence_minimum),
        ("completion_ruler_candidates", ordinary_evidence_minimum),
        ("historical_anchors", ordinary_evidence_minimum),
        ("shaping_hotspots", 1 if packet.get("shaping_hotspots") else 0),
    )
    while True:
        for _ in range(4):
            packet["budget"]["serialized_chars"] = packet_serialized_chars(packet)
        if packet["budget"]["serialized_chars"] <= max_chars:
            packet["retrieval_stats"]["emitted_anchors"] = len(packet["historical_anchors"])
            packet["retrieval_stats"]["emitted_principles"] = len(packet["principles"])
            for _ in range(4):
                packet["budget"]["serialized_chars"] = packet_serialized_chars(packet)
            if packet["budget"]["serialized_chars"] <= max_chars:
                return packet
        trimmed = False
        for key, minimum in trim_order:
            if len(packet[key]) > minimum:
                packet[key].pop()
                trimmed = True
                break
        if not trimmed and packet.get("shaping_hotspots"):
            hotspot = packet["shaping_hotspots"][-1]
            for key, minimum in (
                ("counterexamples", 0),
                ("suppressed_tendencies", 1),
                ("applicability_bounds", 1),
                ("evidence_event_ids", 1),
            ):
                if len(hotspot[key]) > minimum:
                    hotspot[key].pop()
                    trimmed = True
                    break
        if not trimmed:
            raise ValueError(
                f"user perspective packet cannot fit max_chars={max_chars} without dropping its minimum evidence"
            )


def user_perspective_packet(
    db: sqlite3.Connection,
    scenario: str,
    as_of: str | None,
    max_sources: int,
    max_chars: int,
) -> dict[str, Any]:
    if not 1 <= max_sources <= 5:
        raise ValueError("max-sources must be between 1 and 5")
    if not PERSPECTIVE_PACKET_MIN_CHARS <= max_chars <= PERSPECTIVE_PACKET_MAX_CHARS:
        raise ValueError(
            f"max-chars must be between {PERSPECTIVE_PACKET_MIN_CHARS} and {PERSPECTIVE_PACKET_MAX_CHARS}"
        )
    scenario_text = packet_text(scenario, 500)
    if not scenario_text:
        raise ValueError("query is empty or contains unusable encoding")

    bundle = explanation_bundle(db, scenario, as_of, max(12, max_sources * 4))
    shaping_hotspots = [
        shaping_card_packet(db, row, as_of)
        for row in bundle["relevant_shaping_cards"][:max_sources]
    ]
    shaping_suppressions = [
        {
            "card_id": row["card_key"],
            "title": packet_text(row.get("title"), 120),
            "reason": "current context matches a stored suppression or counterexample",
            "detail": row.get("suppression_reason"),
            "suppression_relevance": round(
                float(row.get("suppression_relevance", 0.0)), 6
            ),
            "authority": False,
        }
        for row in bundle["suppressed_shaping_cards"][:max_sources]
    ]
    candidates: list[tuple[float, str, dict[str, Any]]] = []
    skipped_unusable = 0
    for row in bundle["relevant_decision_traces"]:
        if float(row.get("relevance", 0.0)) <= 0:
            continue
        if not packet_text(row.get("parent_result")) or not packet_text(row.get("decision")):
            skipped_unusable += 1
            continue
        score = float(row["relevance"]) + PERSPECTIVE_TRACE_KIND_BONUS.get(row["trace_kind"], 0.0)
        candidates.append((score, "trace", row))
    for row in bundle["analogous_cases"]:
        if float(row.get("relevance", 0.0)) <= 0:
            continue
        if not packet_text(row.get("parent_result")) or not packet_text(row.get("decision")):
            skipped_unusable += 1
            continue
        candidates.append((float(row["relevance"]), "case", row))
    candidates.sort(
        key=lambda item: (item[0], item[2].get("valid_from", ""), item[2].get("recorded_at", "")),
        reverse=True,
    )
    selected = candidates[:max_sources]

    historical_anchors: list[dict[str, Any]] = []
    completion: list[dict[str, Any]] = []
    burdens: list[dict[str, Any]] = []
    constraints: list[dict[str, Any]] = []
    counterfactuals: list[dict[str, Any]] = []
    inferred_parent_result: dict[str, Any] | None = None
    expected_owner_choice: dict[str, Any] | None = None

    for _, source_type, row in selected:
        source = packet_source(row, source_type)  # type: ignore[arg-type]
        historical_anchors.append(source)
        parent_result = packet_text(row.get("parent_result"))
        decision = packet_text(row.get("decision"))
        if inferred_parent_result is None:
            inferred_parent_result = packet_item(parent_result, source, "parent_result")
        if expected_owner_choice is None:
            expected_owner_choice = packet_item(decision, source, "historical_owner_choice")
        append_packet_item(completion, parent_result, source, "parent_result", 3)
        if source_type == "trace":
            for value in packet_json_list(row, "violated_expectations"):
                append_packet_item(completion, value, source, "violated_expectation", 3)
            for value in packet_json_list(row, "harms_or_burdens"):
                append_packet_item(burdens, value, source, "burden", 3)
            for value in packet_json_list(row, "active_constraints"):
                append_packet_item(constraints, value, source, "constraint", 3)
        else:
            for value in packet_json_list(row, "constraints"):
                append_packet_item(constraints, value, source, "constraint", 3)
        for value in packet_json_list(row, "counterfactuals"):
            append_packet_item(counterfactuals, value, source, "counterfactual", 3)

    principle_rows: list[dict[str, Any]] = []
    for row in bundle["relevant_principles"]:
        if float(row.get("relevance", 0.0)) <= 0:
            continue
        if not packet_text(row.get("statement")):
            skipped_unusable += 1
            continue
        principle_rows.append(row)
    principle_rows.sort(
        key=lambda row: (float(row["relevance"]), row["priority"], row["confidence"]),
        reverse=True,
    )
    principles = [
        {
            "principle_id": row["principle_key"],
            "source_event_id": row["source_event_id"],
            "statement": packet_text(row["statement"]),
            "conditions": packet_json_list(row, "conditions")[:2],
            "confidence": row["confidence"],
            "relevance": round(float(row["relevance"]), 6),
        }
        for row in principle_rows[:max_sources]
    ]

    top_relevance = float(selected[0][2]["relevance"]) if selected else 0.0
    parent_texts = [packet_text(row.get("parent_result")) or "" for _, _, row in selected[:2]]
    score_gap = abs(selected[0][0] - selected[1][0]) if len(selected) > 1 else 1.0
    possible_conflict = (
        len(parent_texts) > 1
        and score_gap <= 0.08
        and packet_text_similarity(parent_texts[0], parent_texts[1]) < 0.12
    )
    if top_relevance >= 0.25 and len(selected) >= 2 and not possible_conflict:
        confidence = "high"
    elif top_relevance >= 0.08 and selected:
        confidence = "medium"
    else:
        confidence = "low"
    uncertainty_reasons: list[str] = []
    if not selected:
        uncertainty_reasons.append("no relevant usable historical anchor")
    elif top_relevance < 0.25:
        uncertainty_reasons.append("historical lexical match is not strong")
    if possible_conflict:
        uncertainty_reasons.append("two similarly ranked anchors imply different parent results")
    if skipped_unusable:
        uncertainty_reasons.append("one or more candidate records had unusable encoding")

    packet = {
        "schema_version": PERSPECTIVE_PACKET_SCHEMA,
        "purpose": "pre_scope_user_perspective",
        "scenario": scenario_text,
        "as_of": as_of or now(),
        "inferred_parent_result": inferred_parent_result,
        "completion_ruler_candidates": completion,
        "burdens": burdens,
        "hard_constraints": constraints,
        "expected_owner_choice": expected_owner_choice,
        "historical_anchors": historical_anchors,
        "shaping_hotspots": shaping_hotspots,
        "shaping_suppressions": shaping_suppressions,
        "principles": principles,
        "counterfactuals": counterfactuals,
        "uncertainty": {
            "confidence": confidence,
            "reasons": uncertainty_reasons,
            "possible_anchor_conflict": possible_conflict,
            "meaningful_user_fork": bool(possible_conflict and confidence == "low"),
            "must_revalidate_fork_from_current_facts": True,
        },
        "external_mature_search": {
            "recommended": confidence != "high",
            "reason": "Use current official or mature external comparison only when unresolved semantics, topology, or high-leverage implementation uncertainty remains.",
        },
        "consumer_contract": {
            "current_user_statement_precedence": True,
            "live_facts_precedence": True,
            "authorization_and_stop_precedence": True,
            "activation_is_not_authority": True,
            "apply_hotspots_before_candidate_ranking": True,
            "use_before": ["freeze_parent_result", "freeze_completion_ruler", "choose_strategy"],
            "never_use_as": ["authorization", "task_state", "completion_proof"],
            "outcome_feedback": [
                "actual_consumer_effect",
                "token_and_outer_model_turns",
                "rework_and_user_repetition",
                "latency_and_rollback_cost",
            ],
        },
        "retrieval_stats": {
            "candidate_traces": len(bundle["relevant_decision_traces"]),
            "candidate_cases": len(bundle["analogous_cases"]),
            "candidate_principles": len(bundle["relevant_principles"]),
            "candidate_shaping_cards": len(bundle["relevant_shaping_cards"]),
            "suppressed_shaping_cards": len(bundle["suppressed_shaping_cards"]),
            "selected_sources_before_budget": len(selected),
            "skipped_unusable_encoding": skipped_unusable,
            "emitted_anchors": len(historical_anchors),
            "emitted_principles": len(principles),
        },
        "budget": {"max_chars": max_chars, "serialized_chars": 0},
        "authority": False,
        "completion_claim_allowed": False,
    }
    return settle_packet_budget(packet, max_chars)


def direction_context_item(row: dict[str, Any]) -> dict[str, Any]:
    """Bounded non-authoritative card semantics for Owner judgment.

    Lexical/negation/F1 directional parsers were repeatedly broken on held-out
    natural language. This surface never reorders candidates and never grants
    authority; it only exposes the activated card fields the Owner still needs.
    """
    default_tendency = packet_text(row.get("default_tendency")) or ""
    suppressed = [
        value
        for value in (
            packet_text(item)
            for item in row_json_strings(row, "suppressed_tendencies")[:3]
        )
        if value
    ]
    bounds = [
        value
        for value in (
            packet_text(item)
            for item in row_json_strings(row, "applicability_bounds")[:3]
        )
        if value
    ]
    evidence_event_ids = [
        item
        for item in row_json_strings(row, "evidence_event_ids")[:5]
        if isinstance(item, str) and item
    ]
    episode_trace_keys = [
        item
        for item in row_json_strings(row, "episode_trace_keys")[:3]
        if isinstance(item, str) and item
    ]
    source_event_id = row.get("source_event_id")
    if not isinstance(source_event_id, str):
        source_event_id = None
    return {
        "card_id": row["card_key"],
        "activation_score": round(float(row.get("activation_score", 0.0)), 6),
        "default_tendency": default_tendency,
        "suppressed_tendencies": suppressed,
        "applicability_bounds": bounds,
        "source_refs": {
            "source_event_id": source_event_id,
            "evidence_event_ids": evidence_event_ids,
            "episode_trace_keys": episode_trace_keys,
        },
        "authority": False,
    }


def shape_candidates(
    db: sqlite3.Connection, item: ShapeCandidatesInput
) -> dict[str, Any]:
    original_order = [candidate.candidate_id for candidate in item.candidates]
    context_digest = sha256_text(canonical(item.model_dump(mode="json")))
    if item.stop:
        return {
            "schema_version": "personal-decision-model.candidate-shaping.v1",
            "scenario": item.scenario,
            "context_sha256": context_digest,
            "original_order": original_order,
            "ranked_candidates": [],
            "applied_cards": [],
            "suppressed_cards": [],
            "hard_override": "stop",
            "ranking_status": "hard_override_stop",
            "active_direction_context": [],
            "ranking_changed": False,
            "candidate_set_preserved": False,
            "authority": False,
            "completion_claim_allowed": False,
        }
    if item.explicit_choice_id:
        ordered = sorted(
            enumerate(item.candidates),
            key=lambda pair: (
                0 if pair[1].candidate_id == item.explicit_choice_id else 1,
                pair[0],
            ),
        )
        ranked = [
            {
                "candidate_id": candidate.candidate_id,
                "text": candidate.text,
                "base_index": base_index,
                "soft_delta": 0.0,
                "applied_card_ids": [],
            }
            for base_index, candidate in ordered
        ]
        ranked_order = [row["candidate_id"] for row in ranked]
        return {
            "schema_version": "personal-decision-model.candidate-shaping.v1",
            "scenario": item.scenario,
            "context_sha256": context_digest,
            "original_order": original_order,
            "ranked_candidates": ranked,
            "applied_cards": [],
            "suppressed_cards": [],
            "hard_override": "explicit_choice",
            "ranking_status": "hard_override_explicit_choice",
            "active_direction_context": [],
            "ranking_changed": ranked_order != original_order,
            "candidate_set_preserved": set(ranked_order) == set(original_order),
            "authority": False,
            "completion_claim_allowed": False,
        }

    # Fail-open: do not auto-reorder from natural-language direction scoring.
    # Prior lexical / constructional-negation / F1 scorers were broken by held-out
    # polarity, quote, and cross-lingual cases. Preserve input order (soft_delta=0),
    # surface bounded active card semantics for Owner + live-frame judgment, and
    # never treat that context as authority or completion permission.
    bundle = explanation_bundle(db, item.scenario, item.as_of, 12)
    active_cards = bundle["relevant_shaping_cards"]
    suppressed_cards = [
        {
            "card_id": row["card_key"],
            "reason": row.get("suppression_reason")
            or "current context matches a stored suppression or counterexample",
            "suppression_relevance": round(
                float(row.get("suppression_relevance", 0.0)), 6
            ),
            "authority": False,
        }
        for row in bundle["suppressed_shaping_cards"]
    ]
    ranked = [
        {
            "candidate_id": candidate.candidate_id,
            "text": candidate.text,
            "base_index": base_index,
            "soft_delta": 0.0,
            "applied_card_ids": [],
        }
        for base_index, candidate in enumerate(item.candidates)
    ]
    ranked_order = [row["candidate_id"] for row in ranked]
    active_direction_context = [direction_context_item(card) for card in active_cards]
    return {
        "schema_version": "personal-decision-model.candidate-shaping.v1",
        "scenario": item.scenario,
        "context_sha256": context_digest,
        "original_order": original_order,
        "ranked_candidates": ranked,
        "applied_cards": [],
        "suppressed_cards": suppressed_cards,
        "hard_override": None,
        "ranking_status": "abstained_directional_ambiguity",
        "active_direction_context": active_direction_context,
        "ranking_changed": ranked_order != original_order,
        "candidate_set_preserved": set(ranked_order) == set(original_order),
        "authority": False,
        "completion_claim_allowed": False,
    }


def ingest_seed(db: sqlite3.Connection, seed: SeedInput) -> dict[str, Any]:
    marker = db.execute("SELECT value FROM meta WHERE key=?", (f"seed:{seed.seed_id}",)).fetchone()
    if marker:
        return {"status": "reused", "seed_id": seed.seed_id, "content_sha256": marker[0]}
    digest = sha256_text(canonical(seed.model_dump()))
    with db:
        for event in seed.events:
            ensure_event(db, event)
        insert_model(db, seed.model_version)
        for case in seed.cases:
            insert_case(db, case)
        for trace in seed.decision_traces:
            insert_decision_trace(db, trace)
        for card in seed.shaping_cards:
            insert_shaping_card(db, card)
        for principle in seed.principles:
            insert_principle_exact(db, principle, seed.model_version.model_version_id)
        for relation in seed.relations:
            insert_relation(db, relation)
        db.execute("INSERT INTO meta(key,value) VALUES(?,?)", (f"seed:{seed.seed_id}", digest))
    return {
        "status": "ingested",
        "seed_id": seed.seed_id,
        "content_sha256": digest,
        "counts": {
            "events": len(seed.events),
            "cases": len(seed.cases),
            "decision_traces": len(seed.decision_traces),
            "shaping_cards": len(seed.shaping_cards),
            "principles": len(seed.principles),
            "relations": len(seed.relations),
        },
    }


def export_json(db: sqlite3.Connection) -> dict[str, Any]:
    model = current_model(db)
    principles = [row for row in active_rows(db, "principle_versions", "principle_key", None) if row["status"] == "active"]
    cases = [row for row in active_rows(db, "case_versions", "case_key", None) if row["status"] == "active"]
    traces = [
        row
        for row in active_rows(
            db, "decision_trace_versions", "trace_key", None
        )
        if row["status"] == "active"
    ]
    shaping_cards = [
        row
        for row in active_rows(db, "shaping_card_versions", "card_key", None)
        if row["status"] == "active"
    ]
    relations = [row for row in active_rows(db, "relation_versions", "relation_key", None) if row["status"] == "asserted"]
    events = [dict(row) for row in db.execute("SELECT * FROM events ORDER BY occurred_at,recorded_at").fetchall()]
    evaluations = [dict(row) for row in db.execute("SELECT * FROM evaluations ORDER BY created_at,evaluation_id").fetchall()]
    predictions = [dict(row) for row in db.execute("SELECT * FROM predictions ORDER BY created_at,prediction_id").fetchall()]
    outcomes = [dict(row) for row in db.execute("SELECT * FROM outcomes ORDER BY observed_at,outcome_id").fetchall()]
    return {
        "schema_version": "personal-decision-model.export.v3",
        "generated_at": now(),
        "model": model,
        "principles": principles,
        "cases": cases,
        "decision_traces": traces,
        "shaping_cards": shaping_cards,
        "relations": relations,
        "events": events,
        "predictions": predictions,
        "outcomes": outcomes,
        "evaluations": evaluations,
        "operations": {
            "trigger": "material correction, decision, outcome, prediction error, or cross-case conflict",
            "mode": "event-driven and attached to useful work; no daemon, scheduler, standing worker, or automatic promotion",
            "failure_isolation": "model capture, projection, export, viewer, or evaluation failure never blocks the parent task",
            "promotion": "candidate -> scoped evaluation -> Owner promotion; current user statements always override the model",
            "recovery": "SQLite truth -> health/backup -> regenerated JSON/TXT and graph projection",
            "success_metrics": [
                "less repeated user explanation",
                "better held-out or future decision prediction",
                "traceable case-and-principle explanations",
                "shorter module recovery without weaker parent quality",
                "generation-chain coverage without erasing decoding failures",
            ],
            "non_metrics": ["event count", "token count", "graph node count", "model calls", "document length"],
        },
        "authority": False,
        "completion_claim_allowed": False,
    }


def export_text(value: dict[str, Any]) -> str:
    model = value.get("model") or {}
    lines = [
        "个人决策生成模型｜当前自指投影",
        "",
        "性质：这是结构化事实库的可再生人读视图，不是授权、合同、人格定论或任务完成尺。",
        "当前用户话语、真实对象和硬边界始终优先；本投影缺失或损坏不阻塞其他工作。",
        "",
        "核心命题",
        str(model.get("thesis") or "尚无 promoted 模型"),
        "",
        "生成链",
    ]
    for index, step in enumerate(model.get("decision_procedure") or [], start=1):
        lines.append(f"{index}. {step}")
    lines.extend(["", "自我更新规则"])
    for index, step in enumerate(model.get("self_update_policy") or [], start=1):
        lines.append(f"{index}. {step}")
    operations = value.get("operations") or {}
    lines.extend(
        [
            "",
            "自身运维与效果判据",
            f"- 触发：{operations.get('trigger', '')}",
            f"- 运行：{operations.get('mode', '')}",
            f"- 失败隔离：{operations.get('failure_isolation', '')}",
            f"- 晋升：{operations.get('promotion', '')}",
            f"- 恢复：{operations.get('recovery', '')}",
            "- 成功只看：" + "；".join(operations.get("success_metrics") or []),
            "- 不把这些当成功：" + "；".join(operations.get("non_metrics") or []),
        ]
    )
    lines.extend(["", "当前效果评判"])
    evaluations = value.get("evaluations") or []
    if not evaluations:
        lines.append("- 尚无评测；不得声称预测效果已验证。")
    for item in evaluations:
        lines.append(
            f"- {item['evaluation_kind']}｜{item['dataset_ref']}｜{item['verdict']}｜{item['metrics_json']}"
        )
    lines.extend(["", "当前原则"])
    for item in sorted(value.get("principles") or [], key=lambda row: row["priority"], reverse=True):
        lines.append(f"- [{item['principle_key']}] {item['name']}：{item['statement']}")
        lines.append(f"  来由：{item['rationale']}（confidence={item['confidence']:.2f}）")
    lines.extend(["", "当前用户纠偏塑形卡（高激活、非权威）"])
    for item in value.get("shaping_cards") or []:
        lines.append(
            f"- [{item['card_key']}] {item['title']}｜salience={item['salience']:.2f}｜recurrence={item['recurrence_count']}"
        )
        lines.append(f"  默认倾向：{item['default_tendency']}")
        lines.append(f"  适用边界：{'；'.join(json.loads(item['applicability_bounds_json']))}")
        lines.append("  性质：只排序允许范围内的候选；当前话语、live facts、授权与 Stop 始终优先。")
    lines.extend(["", "决策生成链谱系"])
    for item in value.get("decision_traces") or []:
        lines.append(
            f"- [{item['trace_key']}] {item['title']}｜{item['trace_kind']}｜{item['domain']}"
        )
        if item.get("parent_trace_key"):
            lines.append(f"  父链：{item['parent_trace_key']}")
        lines.append(f"  父结果：{item['parent_result']}")
        lines.append(f"  问题如何成立：{item['problem_definition']}")
        lines.append(f"  选择：{item['decision']}")
        lines.append(f"  结果：{item['result']}")
        if item.get("mistaken_subject"):
            lines.append(
                f"  解码失败：{item['mistaken_subject']} → {item.get('intended_subject') or ''}"
            )
    lines.extend(["", "历史案例谱系"])
    for item in value.get("cases") or []:
        lines.append(f"- [{item['case_key']}] {item['title']}｜{item['domain']}")
        lines.append(f"  父结果：{item['parent_result']}")
        lines.append(f"  选择：{item['decision']}")
        lines.append(f"  结果：{item['result']}")
    lines.extend(
        [
            "",
            "原自指",
            "本模型之所以存在，是为了让 AI 不再依赖用户重复解释：它保存历史事实，显式区分事实、候选和晋升模型，并用未来真实选择检验自己。",
            "它只在新纠偏、真实结果、模型预测或显著冲突能产生正收益时更新；不得为了维护而维护，不运行后台循环。",
            "若预测退化、来源不可追溯、模型与当前用户话语冲突，保留旧版本并降级为候选或回滚；原任务继续，不让维护失败向外传播。",
            "任何 AI 都应能由案例重新推出原则，也能由原则解释新案例；做不到时，模型必须承认证据不足，而不是补写人格标签。",
            "",
            f"生成时间：{value.get('generated_at')}",
        ]
    )
    return "\n".join(lines) + "\n"


def graph_export(db: sqlite3.Connection, path: Path) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for event in db.execute("SELECT * FROM events ORDER BY occurred_at,recorded_at"):
        rows.append({"kind": "episode", **dict(event)})
    for table, object_type, key in (
        ("case_versions", "case", "case_key"),
        ("decision_trace_versions", "trace", "trace_key"),
        ("shaping_card_versions", "shaping_card", "card_key"),
        ("principle_versions", "principle", "principle_key"),
        ("relation_versions", "relation", "relation_key"),
    ):
        for item in active_rows(db, table, key, None):
            rows.append({"kind": object_type, **item})
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(canonical(row) + "\n" for row in rows), encoding="utf-8")
    return {"path": str(path), "row_count": len(rows), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def command(args: argparse.Namespace) -> dict[str, Any]:
    path = db_path(args.db, args.root)
    read_only = args.action in READ_ONLY_ACTIONS
    db = connect(path, read_only=read_only)
    if not read_only:
        init_schema(db)
    if args.action == "init":
        return {"status": "initialized", "db": str(path), "schema_version": SCHEMA_VERSION}
    if args.action == "schema":
        schemas = {
            "task_frame": TaskFrameInput.model_json_schema(),
            "task_stack": TaskStackDocument.model_json_schema(),
            "event": EventInput.model_json_schema(),
            "case": CaseInput.model_json_schema(),
            "decision_trace": DecisionTraceInput.model_json_schema(),
            "shaping_card": ShapingCardInput.model_json_schema(),
            "principle": PrincipleInput.model_json_schema(),
            "relation": RelationInput.model_json_schema(),
            "model_version": ModelVersionInput.model_json_schema(),
            "seed": SeedInput.model_json_schema(),
            "replay_fixture": ReplayFixtureInput.model_json_schema(),
            "shape_candidates": ShapeCandidatesInput.model_json_schema(),
        }
        if args.output:
            output = Path(args.output)
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(json.dumps(schemas, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return schemas
    if args.action == "suspend-task":
        item = TaskFrameInput.model_validate(
            json_object(args.payload_json, "payload-json")
        )
        stack_path = task_stack_path(args.root)
        identity_sha256 = task_frame_digest(item)
        with task_stack_lock(stack_path):
            stack = load_task_stack(stack_path)
            for frame in stack.active_frames:
                if frame.frame_id != item.frame_id:
                    continue
                if frame.parent_state_sha256 != identity_sha256:
                    raise ValueError(
                        f"task frame identity drift: {item.frame_id}"
                    )
                return {
                    "status": "already_suspended",
                    "path": str(stack_path),
                    "depth": len(stack.active_frames),
                    "frame": frame.model_dump(mode="json"),
                    "authority": False,
                }
            for frame in stack.resume_history:
                if frame.frame_id != item.frame_id:
                    continue
                if frame.parent_state_sha256 != identity_sha256:
                    raise ValueError(
                        f"resumed task frame identity drift: {item.frame_id}"
                    )
                return {
                    "status": "already_resumed",
                    "path": str(stack_path),
                    "depth": len(stack.active_frames),
                    "frame": frame.model_dump(mode="json"),
                    "authority": False,
                }
            frame = task_frame_record(item)
            stack.active_frames.append(frame)
            stack = TaskStackDocument.model_validate(stack.model_dump(mode="json"))
            write_task_stack(stack_path, stack)
        return {
            "status": "suspended",
            "path": str(stack_path),
            "depth": len(stack.active_frames),
            "frame": frame.model_dump(mode="json"),
            "authority": False,
        }
    if args.action == "peek-task":
        stack_path = task_stack_path(args.root)
        with task_stack_lock(stack_path):
            stack = load_task_stack(stack_path)
        top = stack.active_frames[-1] if stack.active_frames else None
        return {
            "status": "active" if top else "empty",
            "path": str(stack_path),
            "depth": len(stack.active_frames),
            "top": top.model_dump(mode="json") if top else None,
            "resume_history_count": len(stack.resume_history),
            "authority": False,
            "completion_claim_allowed": False,
        }
    if args.action == "resume-task":
        stack_path = task_stack_path(args.root)
        with task_stack_lock(stack_path):
            stack = load_task_stack(stack_path)
            for resumed in stack.resume_history:
                if resumed.frame_id != args.frame_id:
                    continue
                if (
                    resumed.parent_task_id != args.parent_task_id
                    or resumed.window_role != args.window_role
                    or resumed.parent_state_sha256
                    != args.expected_parent_state_sha256
                ):
                    raise ValueError(
                        f"resumed task frame identity drift: {args.frame_id}"
                    )
                return {
                    "status": "already_resumed",
                    "path": str(stack_path),
                    "depth": len(stack.active_frames),
                    "resume_state": resumed.model_dump(mode="json"),
                    "authority": False,
                }
            if not stack.active_frames:
                raise ValueError("no suspended parent task frame")
            frame = stack.active_frames[-1]
            if frame.frame_id != args.frame_id:
                raise ValueError(
                    f"resume must target top frame {frame.frame_id}, not {args.frame_id}"
                )
            if (
                frame.parent_task_id != args.parent_task_id
                or frame.window_role != args.window_role
                or frame.parent_state_sha256 != args.expected_parent_state_sha256
            ):
                raise ValueError(f"task frame identity mismatch: {args.frame_id}")
            stack.active_frames.pop()
            resumed = TaskResumeRecord(
                **frame.model_dump(mode="json"),
                resumed_at=now(),
                child_status=args.child_status,
                child_result_ref=args.child_result_ref,
            )
            stack.resume_history.append(resumed)
            stack = TaskStackDocument.model_validate(stack.model_dump(mode="json"))
            write_task_stack(stack_path, stack)
        return {
            "status": "resumed",
            "path": str(stack_path),
            "depth": len(stack.active_frames),
            "resume_state": frame.model_dump(mode="json"),
            "child_status": args.child_status,
            "child_result_ref": args.child_result_ref,
            "authority": False,
            "completion_claim_allowed": False,
        }
    if args.action == "ingest-seed":
        seed = SeedInput.model_validate_json(Path(args.file).read_text(encoding="utf-8-sig"))
        return ingest_seed(db, seed)
    if args.action == "capture":
        item = EventInput(
            event_id=args.event_id,
            event_type=args.type,
            occurred_at=args.occurred_at or now(),
            source_kind=args.source_kind,
            source_ref=args.source_ref,
            summary=args.summary,
            payload=json_object(args.payload_json, "payload-json"),
            parent_event_id=args.parent_event_id,
            actor=args.actor,
        )
        with db:
            event_id = ensure_event(db, item)
        return {"status": "captured", "event_id": event_id}
    if args.action == "record-trace":
        item = DecisionTraceInput.model_validate(
            json_object(args.payload_json, "payload-json")
        )
        with db:
            trace_version_id = insert_decision_trace(db, item)
        return {
            "status": "recorded",
            "trace_key": item.trace_key,
            "trace_version_id": trace_version_id,
        }
    if args.action == "record-shaping-card":
        item = ShapingCardInput.model_validate(
            json_object(args.payload_json, "payload-json")
        )
        with db:
            shaping_card_version_id = insert_shaping_card(db, item)
        return {
            "status": "recorded",
            "card_key": item.card_key,
            "shaping_card_version_id": shaping_card_version_id,
            "authority": False,
        }
    if args.action == "propose":
        if not db.execute("SELECT 1 FROM events WHERE event_id=?", (args.source_event_id,)).fetchone():
            raise ValueError("source event does not exist")
        payload = json_object(args.payload_json, "payload-json")
        impact = json.loads(args.impact_scope_json)
        if not isinstance(impact, list):
            raise ValueError("impact-scope-json must be an array")
        identity = {"type": args.type, "payload": payload, "source": args.source_event_id}
        digest = sha256_text(canonical(identity))
        proposal_id = args.proposal_id or f"proposal-{digest[:24]}"
        with db:
            db.execute(
                "INSERT INTO proposals VALUES(?,?,?,?,?,?,?)",
                (
                    proposal_id,
                    args.type,
                    canonical(payload),
                    canonical(impact),
                    args.source_event_id,
                    now(),
                    digest,
                ),
            )
        return {"status": "candidate", "proposal_id": proposal_id, "content_sha256": digest}
    if args.action == "promote":
        proposal = db.execute("SELECT * FROM proposals WHERE proposal_id=?", (args.proposal_id,)).fetchone()
        if not proposal:
            raise ValueError("proposal not found")
        if db.execute("SELECT 1 FROM proposal_decisions WHERE proposal_id=?", (args.proposal_id,)).fetchone():
            raise ValueError("proposal already decided")
        evaluation_id = args.evaluation_id or None
        if not args.user_explicit:
            evaluation = db.execute("SELECT verdict FROM evaluations WHERE evaluation_id=?", (evaluation_id,)).fetchone()
            if not evaluation or evaluation[0] != "pass":
                raise ValueError("promotion requires a passing evaluation or --user-explicit")
        payload = json.loads(proposal["payload_json"])
        source = EventInput(
            event_type="promotion",
            occurred_at=now(),
            source_kind="owner_promotion",
            source_ref=args.proposal_id,
            summary=f"Promoted proposal {args.proposal_id}",
            payload={"proposal_id": args.proposal_id, "reason": args.reason},
            parent_event_id=proposal["source_event_id"],
        )
        current = current_model(db)
        new_model_id = f"model-{sha256_text(args.proposal_id + now())[:20]}"
        thesis = str(payload.get("thesis") or (current or {}).get("thesis") or "")
        procedure = payload.get("decision_procedure") or (current or {}).get("decision_procedure") or []
        update_policy = payload.get("self_update_policy") or (current or {}).get("self_update_policy") or []
        with db:
            promotion_event_id = ensure_event(db, source)
            insert_model(
                db,
                ModelVersionInput(
                    model_version_id=new_model_id,
                    parent_version_id=(current or {}).get("model_version_id"),
                    status="promoted",
                    thesis=thesis,
                    decision_procedure=procedure,
                    self_update_policy=update_policy,
                    evaluation={"evaluation_id": evaluation_id, "user_explicit": args.user_explicit},
                    source_event_id=promotion_event_id,
                ),
            )
            if payload.get("kind") == "principle":
                principle = dict(payload.get("principle") or {})
                principle.update(source_event_id=promotion_event_id, status="active")
                insert_principle_exact(db, PrincipleInput.model_validate(principle), new_model_id)
            if payload.get("kind") == "case":
                case = dict(payload.get("case") or {})
                case.update(source_event_id=promotion_event_id, status="active")
                insert_case(db, CaseInput.model_validate(case))
            if payload.get("kind") == "decision_trace":
                trace = dict(payload.get("decision_trace") or {})
                trace.update(source_event_id=promotion_event_id, status="active")
                insert_decision_trace(
                    db, DecisionTraceInput.model_validate(trace)
                )
            decision_id = f"proposal-decision-{uuid.uuid4().hex[:20]}"
            db.execute(
                "INSERT INTO proposal_decisions VALUES(?,?,?,?,?,?,?)",
                (
                    decision_id,
                    args.proposal_id,
                    "promoted",
                    args.reason,
                    evaluation_id,
                    promotion_event_id,
                    now(),
                ),
            )
        return {"status": "promoted", "proposal_id": args.proposal_id, "model_version_id": new_model_id}
    if args.action == "perspective-packet":
        return user_perspective_packet(
            db,
            args.query,
            args.as_of,
            args.max_sources,
            args.max_chars,
        )
    if args.action == "shape-candidates":
        item = ShapeCandidatesInput.model_validate(
            json_object(args.payload_json, "payload-json")
        )
        return shape_candidates(db, item)
    if args.action in {"retrieve", "explain", "simulate"}:
        bundle = explanation_bundle(db, args.query, args.as_of, args.limit)
        if args.action == "retrieve":
            return {
                "query": args.query,
                "principles": bundle["relevant_principles"],
                "cases": bundle["analogous_cases"],
                "decision_traces": bundle["relevant_decision_traces"],
                "shaping_cards": bundle["relevant_shaping_cards"],
                "suppressed_shaping_cards": bundle["suppressed_shaping_cards"],
                "authority": False,
            }
        bundle["mode"] = args.action
        return bundle
    if args.action == "predict":
        model = current_model(db)
        model_id = args.model_version_id or (model or {}).get("model_version_id")
        if not model_id:
            raise ValueError("no promoted model version")
        if not db.execute("SELECT 1 FROM events WHERE event_id=?", (args.source_event_id,)).fetchone():
            raise ValueError("source event does not exist")
        prediction_id = args.prediction_id or f"prediction-{uuid.uuid4().hex[:20]}"
        with db:
            db.execute(
                "INSERT INTO predictions VALUES(?,?,?,?,?,?,?,?)",
                (
                    prediction_id,
                    model_id,
                    args.scenario,
                    args.choice,
                    canonical(json_object(args.reasoning_json, "reasoning-json")),
                    args.confidence,
                    args.source_event_id,
                    now(),
                ),
            )
        return {"status": "predicted", "prediction_id": prediction_id, "model_version_id": model_id}
    if args.action == "record-outcome":
        if not db.execute("SELECT 1 FROM predictions WHERE prediction_id=?", (args.prediction_id,)).fetchone():
            raise ValueError("prediction not found")
        existing = db.execute(
            "SELECT actual_choice,result,source_event_id,outcome_id FROM outcomes WHERE prediction_id=?",
            (args.prediction_id,),
        ).fetchone()
        if existing:
            if (
                existing["actual_choice"] != args.actual_choice
                or existing["result"] != args.result
                or existing["source_event_id"] != args.source_event_id
            ):
                raise ValueError(f"outcome identity drift: {args.prediction_id}")
            return {"status": "already_recorded", "outcome_id": existing["outcome_id"]}
        outcome_id = f"outcome-{uuid.uuid4().hex[:20]}"
        with db:
            db.execute(
                "INSERT INTO outcomes VALUES(?,?,?,?,?,?)",
                (outcome_id, args.prediction_id, args.actual_choice, args.result, args.source_event_id, now()),
            )
        return {"status": "recorded", "outcome_id": outcome_id}
    if args.action == "replay-eval":
        fixture = ReplayFixtureInput.model_validate_json(Path(args.file).read_text(encoding="utf-8-sig"))
        model = current_model(db)
        model_id = fixture.model_version_id or (model or {}).get("model_version_id")
        if not model_id or not db.execute(
            "SELECT 1 FROM model_versions WHERE model_version_id=?", (model_id,)
        ).fetchone():
            raise ValueError("replay fixture model version does not exist")
        fixture_digest = sha256_text(canonical(fixture.model_dump()))
        prediction_ids: list[str] = []
        with db:
            source_event_id = ensure_event(db, fixture.source_event)
            for item in fixture.cases:
                prediction_id = f"prediction-replay-{sha256_text(fixture.dataset_ref + ':' + item.scenario_id)[:20]}"
                prediction_ids.append(prediction_id)
                prediction_values = (
                    model_id,
                    item.scenario,
                    item.predicted_choice,
                    canonical(item.reasoning),
                    item.confidence,
                    source_event_id,
                )
                existing_prediction = db.execute(
                    """SELECT model_version_id,scenario,predicted_choice,reasoning_json,confidence,source_event_id
                       FROM predictions WHERE prediction_id=?""",
                    (prediction_id,),
                ).fetchone()
                if existing_prediction:
                    if tuple(existing_prediction) != prediction_values:
                        raise ValueError(f"replay prediction identity drift: {item.scenario_id}")
                else:
                    db.execute(
                        "INSERT INTO predictions VALUES(?,?,?,?,?,?,?,?)",
                        (prediction_id, *prediction_values, now()),
                    )
                outcome_id = f"outcome-replay-{sha256_text(fixture.dataset_ref + ':' + item.scenario_id)[:20]}"
                outcome_values = (
                    prediction_id,
                    item.actual_choice,
                    item.result,
                    source_event_id,
                )
                existing_outcome = db.execute(
                    "SELECT prediction_id,actual_choice,result,source_event_id FROM outcomes WHERE outcome_id=?",
                    (outcome_id,),
                ).fetchone()
                if existing_outcome:
                    if tuple(existing_outcome) != outcome_values:
                        raise ValueError(f"replay outcome identity drift: {item.scenario_id}")
                else:
                    db.execute(
                        "INSERT INTO outcomes VALUES(?,?,?,?,?,?)",
                        (outcome_id, *outcome_values, now()),
                    )
        placeholders = ",".join("?" for _ in prediction_ids)
        rows = db.execute(
            f"""SELECT p.predicted_choice,o.actual_choice
                FROM predictions p JOIN outcomes o ON o.prediction_id=p.prediction_id
                WHERE p.prediction_id IN ({placeholders})""",
            prediction_ids,
        ).fetchall()
        total = len(rows)
        correct = sum(row[0].strip().casefold() == row[1].strip().casefold() for row in rows)
        accuracy = correct / total if total else 0.0
        verdict = "pass" if total >= args.min_cases and accuracy >= args.min_accuracy else "insufficient_or_fail"
        metrics = {
            "total": total,
            "correct": correct,
            "accuracy": accuracy,
            "min_cases": args.min_cases,
            "min_accuracy": args.min_accuracy,
            "fixture_sha256": fixture_digest,
        }
        evaluation_id = f"evaluation-replay-{fixture_digest[:20]}"
        evaluation_values = (
            model_id,
            "cross_case_replay",
            fixture.dataset_ref,
            canonical(metrics),
            verdict,
            source_event_id,
        )
        with db:
            existing_evaluation = db.execute(
                """SELECT model_version_id,evaluation_kind,dataset_ref,metrics_json,verdict,source_event_id
                   FROM evaluations WHERE evaluation_id=?""",
                (evaluation_id,),
            ).fetchone()
            if existing_evaluation:
                if tuple(existing_evaluation) != evaluation_values:
                    raise ValueError("replay evaluation identity drift")
                status = "already_evaluated"
            else:
                db.execute(
                    "INSERT INTO evaluations VALUES(?,?,?,?,?,?,?,?)",
                    (evaluation_id, *evaluation_values, now()),
                )
                status = "evaluated"
        return {
            "status": status,
            "evaluation_id": evaluation_id,
            "model_version_id": model_id,
            "dataset_ref": fixture.dataset_ref,
            "verdict": verdict,
            "metrics": metrics,
            "authority": False,
        }
    if args.action == "evaluate":
        model = current_model(db)
        model_id = args.model_version_id or (model or {}).get("model_version_id")
        rows = db.execute(
            """SELECT p.prediction_id,p.predicted_choice,o.actual_choice
               FROM predictions p JOIN outcomes o ON o.prediction_id=p.prediction_id
               WHERE p.model_version_id=?""",
            (model_id,),
        ).fetchall()
        total = len(rows)
        correct = sum(row["predicted_choice"].strip().casefold() == row["actual_choice"].strip().casefold() for row in rows)
        accuracy = correct / total if total else 0.0
        verdict = "pass" if total >= args.min_cases and accuracy >= args.min_accuracy else "insufficient_or_fail"
        metrics = {"total": total, "correct": correct, "accuracy": accuracy, "min_cases": args.min_cases, "min_accuracy": args.min_accuracy}
        evaluation_id = f"evaluation-{uuid.uuid4().hex[:20]}"
        with db:
            db.execute(
                "INSERT INTO evaluations VALUES(?,?,?,?,?,?,?,?)",
                (evaluation_id, model_id, "prediction_outcome", args.dataset_ref, canonical(metrics), verdict, args.source_event_id, now()),
            )
        return {"evaluation_id": evaluation_id, "model_version_id": model_id, "verdict": verdict, "metrics": metrics}
    if args.action == "export":
        value = export_json(db)
        output = Path(args.output) if args.output else root_path(args.root) / "exports" / ("current_model.txt" if args.format == "txt" else "current_model.json")
        output.parent.mkdir(parents=True, exist_ok=True)
        content = export_text(value) if args.format == "txt" else json.dumps(value, ensure_ascii=False, indent=2) + "\n"
        output.write_text(content, encoding="utf-8")
        return {"status": "exported", "path": str(output), "sha256": hashlib.sha256(output.read_bytes()).hexdigest()}
    if args.action == "graph-export":
        output = Path(args.output) if args.output else root_path(args.root) / "exports" / "graphiti_episodes.jsonl"
        return graph_export(db, output)
    if args.action == "backup":
        output = Path(args.output) if args.output else root_path(args.root) / "backups" / f"pdm-{datetime.now():%Y%m%dT%H%M%S}.sqlite3"
        output.parent.mkdir(parents=True, exist_ok=True)
        target = sqlite3.connect(output)
        try:
            db.backup(target)
        finally:
            target.close()
        return {"status": "backed_up", "path": str(output), "sha256": hashlib.sha256(output.read_bytes()).hexdigest()}
    if args.action == "health":
        quick = db.execute("PRAGMA quick_check").fetchone()[0]
        foreign = [tuple(row) for row in db.execute("PRAGMA foreign_key_check").fetchall()]
        events = [row[0] for row in db.execute("SELECT content_sha256 FROM events ORDER BY recorded_at,event_id").fetchall()]
        stack_path = task_stack_path(args.root)
        stack_error: str | None = None
        try:
            # The stack is atomically replaced by writers, so a health read does
            # not need the writable lock file used by mutating stack commands.
            stack = load_task_stack(stack_path)
            task_stack = {
                "status": "healthy" if stack_path.exists() else "not_initialized",
                "path": str(stack_path),
                "active_frames": len(stack.active_frames),
                "resume_history": len(stack.resume_history),
                "top_frame_id": (
                    stack.active_frames[-1].frame_id
                    if stack.active_frames
                    else None
                ),
            }
        except (OSError, ValueError, ValidationError) as exc:
            stack_error = f"{type(exc).__name__}:{exc}"
            task_stack = {
                "status": "unhealthy",
                "path": str(stack_path),
                "error": stack_error,
            }
        packages: dict[str, bool] = {}
        import importlib.util

        for name in ("graphiti_core", "falkordb", "datasette", "mcp", "pydantic", "jsonschema"):
            packages[name] = importlib.util.find_spec(name) is not None
        counts = {table: db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0] for table in FACT_TABLES}
        return {
            "status": (
                "healthy"
                if quick == "ok" and not foreign and stack_error is None
                else "unhealthy"
            ),
            "db": str(path),
            "schema_version": SCHEMA_VERSION,
            "quick_check": quick,
            "foreign_key_errors": foreign,
            "event_chain_sha256": sha256_text("".join(events)),
            "counts": counts,
            "task_stack": task_stack,
            "optional_packages": packages,
            "authority": False,
        }
    raise ValueError(f"unsupported action: {args.action}")


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(description=__doc__)
    root.add_argument("--root")
    root.add_argument("--db")
    sub = root.add_subparsers(dest="action", required=True)
    sub.add_parser("init")
    schema = sub.add_parser("schema")
    schema.add_argument("--output")
    suspend = sub.add_parser("suspend-task")
    suspend.add_argument("--payload-json", required=True)
    sub.add_parser("peek-task")
    resume = sub.add_parser("resume-task")
    resume.add_argument("--frame-id", required=True)
    resume.add_argument("--parent-task-id", required=True)
    resume.add_argument("--window-role", required=True)
    resume.add_argument("--expected-parent-state-sha256", required=True)
    resume.add_argument(
        "--child-status",
        choices=["verified", "partial", "blocked", "not_applicable"],
        required=True,
    )
    resume.add_argument("--child-result-ref")
    seed = sub.add_parser("ingest-seed")
    seed.add_argument("--file", required=True)
    capture = sub.add_parser("capture")
    capture.add_argument("--event-id")
    capture.add_argument("--type", required=True, choices=["correction", "case", "decision", "outcome", "observation", "promotion", "maintenance"])
    capture.add_argument("--occurred-at")
    capture.add_argument("--source-kind", default="user_statement")
    capture.add_argument("--source-ref", required=True)
    capture.add_argument("--summary", required=True)
    capture.add_argument("--payload-json", default="{}")
    capture.add_argument("--parent-event-id")
    capture.add_argument("--actor", default="codex-owner")
    trace = sub.add_parser("record-trace")
    trace.add_argument("--payload-json", required=True)
    shaping = sub.add_parser("record-shaping-card")
    shaping.add_argument("--payload-json", required=True)
    propose = sub.add_parser("propose")
    propose.add_argument("--proposal-id")
    propose.add_argument("--type", required=True)
    propose.add_argument("--payload-json", required=True)
    propose.add_argument("--impact-scope-json", default="[]")
    propose.add_argument("--source-event-id", required=True)
    promote = sub.add_parser("promote")
    promote.add_argument("--proposal-id", required=True)
    promote.add_argument("--evaluation-id")
    promote.add_argument("--reason", required=True)
    promote.add_argument("--user-explicit", action="store_true")
    for name in ("retrieve", "explain", "simulate"):
        item = sub.add_parser(name)
        item.add_argument("--query", required=True)
        item.add_argument("--as-of")
        item.add_argument("--limit", type=int, default=5)
    perspective = sub.add_parser("perspective-packet")
    perspective.add_argument("--query", required=True)
    perspective.add_argument("--as-of")
    perspective.add_argument("--max-sources", type=int, default=3)
    perspective.add_argument(
        "--max-chars", type=int, default=PERSPECTIVE_PACKET_DEFAULT_MAX_CHARS
    )
    shape = sub.add_parser("shape-candidates")
    shape.add_argument("--payload-json", required=True)
    predict = sub.add_parser("predict")
    predict.add_argument("--prediction-id")
    predict.add_argument("--model-version-id")
    predict.add_argument("--scenario", required=True)
    predict.add_argument("--choice", required=True)
    predict.add_argument("--reasoning-json", required=True)
    predict.add_argument("--confidence", type=float, default=0.5)
    predict.add_argument("--source-event-id", required=True)
    outcome = sub.add_parser("record-outcome")
    outcome.add_argument("--prediction-id", required=True)
    outcome.add_argument("--actual-choice", required=True)
    outcome.add_argument("--result", required=True)
    outcome.add_argument("--source-event-id", required=True)
    evaluate = sub.add_parser("evaluate")
    evaluate.add_argument("--model-version-id")
    evaluate.add_argument("--dataset-ref", required=True)
    evaluate.add_argument("--source-event-id", required=True)
    evaluate.add_argument("--min-cases", type=int, default=3)
    evaluate.add_argument("--min-accuracy", type=float, default=0.8)
    replay = sub.add_parser("replay-eval")
    replay.add_argument("--file", required=True)
    replay.add_argument("--min-cases", type=int, default=5)
    replay.add_argument("--min-accuracy", type=float, default=0.8)
    export = sub.add_parser("export")
    export.add_argument("--format", choices=["json", "txt"], default="json")
    export.add_argument("--output")
    graph = sub.add_parser("graph-export")
    graph.add_argument("--output")
    backup = sub.add_parser("backup")
    backup.add_argument("--output")
    sub.add_parser("health")
    return root


def main() -> int:
    try:
        result = command(parser().parse_args())
        if result.get("schema_version") == PERSPECTIVE_PACKET_SCHEMA:
            print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
        else:
            print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    except (OSError, sqlite3.Error, ValueError, ValidationError) as exc:
        print(f"PDM_FAILED:{type(exc).__name__}:{exc}", file=sys.stderr)
        return 20


if __name__ == "__main__":
    raise SystemExit(main())
