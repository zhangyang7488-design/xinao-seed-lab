---
name: dispatch-luna-worker-pool
description: >
  Dispatch ordinary GPT-5.6 Luna Max workers through the canonical public Luna WorkerPool launcher
  (isomorphic to Terra/Grok ordinary WorkerPool labor). Default model_reasoning_effort=max.
  Use for bounded mechanical/high-volume delegated work: search, recompute, test, filter, extract,
  classify — when Luna Max has positive net benefit vs Grok/Terra. Luna may support ordinary XINAO
  research with mechanical, high-volume, independently checkable work. The task and scientific
  route must already be selected outside this Skill; Luna returns a candidate and Codex keeps final
  adoption and formal writing.
---

# Dispatch Luna Worker Pool（普通工人 · Luna Max · 与 Terra/Grok 同构）

## 这是什么

- **公开唯一入口：** `C:\Users\xx363\CodexLaunchers\Invoke-Codex-LunaWorkerPool.ps1`
- **后端：** `codex exec -m gpt-5.6-luna` + `model_reasoning_effort="max"`（**露娜最大模式**）
- **形态：** 通用有界 one-shot pool · candidate-only · exact pool/lane 回执
- **同构对象：** Terra / Grok **普通工人劳动**（public launcher + Selection + N 并行 + pool_summary）
- **不是：** OpenCode/API MCP 半生不熟栈；不是 formal science package 批；不是第二 Owner
- **不是：** `inner_luna` 默认 `low` + read-only 锥内探针（那是另一路径）
- **不是：** `ultra` 多 agent 模式（那是更高/另一档；本 v1 默认 **max** 单 agent）

## 何时用

优先 Luna Max 当：

- 大量搜索、复算、测试、筛选、抽取、分类、去重、客观可验变换
- 需要 **高努力** 但额度/成本比 Sol/Terra 更省的委派执行
- Sol 作 Owner，把有界工包派给 Luna 子劳动（社交共识：Sol 编排 + Luna Max 执行）
- 用户明确点名「露娜 / Luna / Luna Max / 最大模式」

相对选择：

| 场景 | 后端 |
|------|------|
| 常规外部候选 / 开放探索 | Grok 普通 |
| 复杂调试 / 长上下文 / 第二意见 / 采用前复核 | Terra 普通（默认 medium） |
| **大量有界机械+高努力执行** | **Luna Max（本 Skill）** |
| 父意图 / 正式采用 / 终验 | Sol Owner |

不要用本 Skill：

- 让 Luna 或 transport 替 Codex 选择科学父意图、研究路线、模式、采用或完成
- 需要 Owner 终验本身（你自己做）
- 想冒充 inner_luna low 探针输出为本 Pool

## 硬边界

- Codex Sol TUI = 唯一 Owner、正式采用、权威写入、汇流、终验
- Luna 只产候选；`worker_terminal` ≠ `owner_adopted` ≠ `effect_verified` ≠ `parent_complete`
- 不创建 resident pool / daemon / scheduler / 第二路由器
- Pause/Stop 立即停止范围内新派工与 mutation
- 不打印密钥；用本机已登录 Codex 认证
- `completion_claim_allowed=false`：pool 连通 ≠ 父任务完成
- Codex 客户端可能默认 **关 Max**；若报 effort 非法，先在设置里打开 Available reasoning efforts → Max

## 公开调用（必须 pwsh 7+）

### 0) Selection-only（只铸 receipt，不烧模型）

```powershell
$SelectionOnlyResult = & 'C:\Users\xx363\CodexLaunchers\Invoke-Codex-LunaWorkerPool.ps1' `
  -SelectionOnly -N 1 -Model 'gpt-5.6-luna' -ReasoningEffort max -Cwd $TaskCwd |
  ConvertFrom-Json -ErrorAction Stop

$SelectionReceipt = [string]$SelectionOnlyResult.selection_path
# schema: xinao.codex_luna_selection_only_result.v1
# model_invocation_count must be 0
# reasoning_effort should be max
```

### 1) 普通有界劳动（默认 Luna Max；自选并绑 receipt）

```powershell
& 'C:\Users\xx363\CodexLaunchers\Invoke-Codex-LunaWorkerPool.ps1' `
  -N $N `
  -PromptFile $PromptFile `
  -Cwd $TaskCwd `
  -Model 'gpt-5.6-luna' `
  -ReasoningEffort max `
  -Sandbox workspace-write `
  -MinResultChars 256 `
  -TimeoutSec 900
```

- 省略 `-SelectionPath`：launcher 自己写 selection receipt 再执行
- 默认 **已经是 max**；除非用户明确降档，不要习惯性改成 low/medium
- `$N` 由互补工包数与 Owner fan-in 决定

### 2) 验收

读返回 JSON 与 `pool_summary_path`（**不要**把 mutable `latest.json` 当唯一身份）：

必须看到：

- `schema_version=xinao.codex_luna_public_dispatch_result.v1`
- `all_ok=true` 且 `acceptance_contract_ok=true`（全部 lane accepted 时）
- 每个 lane：`worker_status/outcome=accepted`、`effective_output_accepted=true`、`exit_code=0`、`result_text_chars >= MinResultChars`
- lane / summary 中 `model=gpt-5.6-luna`、`reasoning_effort=max`（默认路径）
- `completion_claim_allowed=false`、`candidate_only=true`

然后：

1. 读各 lane `result.txt` / `latest.json`
2. Owner 按硬证据汇流（不多数票）
3. 需要正式采用时 **你** 写正式面；Luna 不写主权威

失败分型：

| 症状 | 处理 |
|------|------|
| `CODEX_LUNA_REQUIRES_PWSH7` | 用 pwsh7 调 public launcher |
| `CODEX_LUNA_PROMPT_REQUIRED` | 补 Prompt/PromptFile |
| `CODEX_LUNA_CWD_MISSING` | 显式存在的 Cwd |
| effort/max 非法 | Codex 设置打开 Max reasoning effort |
| lane `timeout` | 升 TimeoutSec 或拆工包；保留 evidence |
| lane `incomplete` | 加强 prompt 完成尺 / MinResultChars |
| exit≠0 | 读 lane err log；修输入封印后重派 |

## 与 Terra / Grok 对照（同构，不复刻实现）

| 能力 | Grok 普通 | Terra 普通 | **Luna Max** |
|------|-----------|------------|--------------|
| 公开 launcher | Invoke-Codex-GrokWorkerPool | Invoke-Codex-TerraWorkerPool | **Invoke-Codex-LunaWorkerPool** |
| Skill | dispatch-grok-worker-pool | dispatch-terra-worker-pool | **dispatch-luna-worker-pool** |
| 默认模型 | grok | gpt-5.6-terra | **gpt-5.6-luna** |
| 默认努力 | （Grok 侧） | medium | **max** |
| Selection receipt | 有 | 有 | 有 |
| N lane 并行 | 有 | 有 | 有 |
| pool_summary + lane latest | 有 | 有 | 有 |
| candidate-only | 有 | 有 | 有 |
| 证据在 D: | grok_worker_pool | codex_terra_worker_pool | **codex_luna_worker_pool** |

## 额度

Luna 烧 **Codex 订阅额度池**（与 Sol/Terra 同池）。相对 Sol/Terra 通常更省；**max 仍比 low/medium 更费**，按净收益选。

## 禁止

- 直接调 core 脚本绕过 public launcher（测试除外）
- 把 inner_luna / agents 子代理输出冒充本 WorkerPool
- 用 Luna 结果宣称父完成或科学父状态已经改变
- 把 `low` 机械锥冒充 Luna Max
- 第二 Owner / resident pool

## 热调用合同

本 Skill 与 `amplify-supervisor-worker` 是 Luna Max 的唯一热调用合同。旧 C 盘工人说明副本已退出活动架构，不得作为新窗口前置或恢复真源。
