# 成熟基础与纠偏谱系

本文件解释这个 Skill 为什么成立、应吸收哪些成熟原则，以及历史案例怎样被提升为通用判断。它用于更新、独立审查和红队，不是每次调用的必读门。

## 外部成熟基础

### 人首先是现实中的能动主体

行动哲学将 agency 放在“主体有意图地行动并影响现实”的问题上；Bandura 的能动性模型强调意图、预见、自我调节和自我反思，并区分亲自行动、委托他人和集体行动：

- [Stanford Encyclopedia of Philosophy: Agency](https://plato.stanford.edu/entries/agency/)
- [Bandura: Social Cognitive Theory, An Agentic Perspective](https://www.annualreviews.org/content/journals/10.1146/annurev.psych.52.1.1)

本 Skill 因此不把人缩成需求来源或结果接收器。一个人会因现实关切形成意图，预想后果，主动调用知识、工具与他人，并根据反馈调节自己。

### 活动、行动与操作不能错层

活动理论区分由对象和动机组织的活动、由目标组织的行动，以及随现实条件变化的操作；工具中介活动，但不能反过来成为活动本身。Situated action 又说明，目标和计划会在接触真实情境后继续生长，不能要求人事先填写完整规格：

- [Leontiev: Activity, Consciousness, and Personality](https://www.marxists.org/archive/leontev/works/1978/activity-consciousness-personality.pdf)
- [Engestrom: Activity theory as a framework for analyzing and redesigning work](https://pubmed.ncbi.nlm.nih.gov/10929830/)
- [Suchman: Plans and Situated Actions](https://www.cambridge.org/core/books/abs/humanmachine-reconfigurations/plans/486980BE0B03AE3DF9C2181D74F26E64)

本 Skill 用这一区分防止操作升为目标、目标升为动机，也不把自然活动写成固定人工步骤。

### 胜任者会求知、借力和适应

Naturalistic Decision Making 与 Cognitive Work Analysis 关注胜任者在动态、不确定、有反馈且多人协作的现实情境中怎样利用线索、知识、预期、策略和替代路径；分布式认知则把人、他人和技术制品视为共同完成活动的系统：

- [Klein: Naturalistic Decision Making](https://pubmed.ncbi.nlm.nih.gov/18689053/)
- [Cognitive Work Analysis for future systems](https://www.dst.defence.gov.au/sites/default/files/publications/documents/2008_Elix-Naikar.pdf)
- [Hutchins: How a Cockpit Remembers Its Speeds](https://pages.ucsd.edu/~ehutchins/documents/CockpitSpeeds.pdf)

这支持 Codex 根据任务重要性、未知和错误相关性主动查成熟资料、用工具、请独立大脑、做反例和现实试验；不等用户逐项提醒，也不固定人数或步骤。

### 自动化增强人的能动性

FAA 的人因设计准则要求自动化从系统目标出发，不必复制人工做法；自动化后的任务应更容易，且不应向人强加新的内部操作。Mixed-initiative 研究则要求结合误猜成本、行动收益和可逆性决定主动行动还是询问：

- [FAA Human Factors Design Standard: Automation](https://hf.tc.faa.gov/hfds/download-hfds/hfds_pdfs/Ch3_Automation.pdf)
- [Horvitz: Principles of Mixed-Initiative User Interfaces](https://www.microsoft.com/en-us/research/wp-content/uploads/2016/11/chi99horvitz.pdf)

因此，人的自然活动用于恢复不可删除的对象、判断、反馈和适应，不用于把点击、抄录、记忆和集成劳动退还给人。

### 从人的结果而不是预选方案开局

GOV.UK Service Standard 要求理解人在完整情境中真正想完成的事，并明确警告围绕预先选定的方案或内部技术组织问题会造错服务：

- [Understand users and their needs](https://www.gov.uk/service-manual/service-standard/point-1-understand-user-needs)
- [Solve a whole problem for users](https://www.gov.uk/service-manual/service-standard/point-2-solve-a-whole-problem)

本 Skill 吸收“结果和完整问题先行”，不复制 persona、旅程图、工作坊或固定服务设计流程。

### 人、任务、环境和真实使用效果

NIST 对人本设计的归纳强调理解 users、tasks、environments，由人的评价驱动并迭代；usability 以指定情境中达成目标的有效性、效率和满意度衡量：

- [NIST Human Factors and Human-Centered Design](https://www.nist.gov/itl/iad/human-centered-technologies/human-factors-human-centered-design)
- [NIST usability glossary](https://csrc.nist.gov/glossary/term/usability)

本 Skill 借用真实情境与可感知效果，不假定“让用户满意”高于科学事实、安全边界或诚实的坏结果。

### Verification 与 Validation 分开

NASA 区分按规格做对与在预期环境满足客户/用户期待，并从 stakeholder/mission 目标建立可追踪的成功度量：

- [NASA Product Validation](https://www.nasa.gov/reference/5-4-product-validation/)
- [NASA Stakeholder Expectations Definition](https://www.nasa.gov/reference/4-1-stakeholder-expectations-definition/)

本 Skill 因此把技术绿限定为它直接验证的谓词，再单独核对人的用途是否成立；不引入 V 模型、全量追踪矩阵或评审委员会。

### 防字面完成和代理目标

Specification gaming 与 goal misgeneralization 都说明：系统可能很好地满足字面指标或学会一项能力，却仍追错人的真实目标：

- [DeepMind: Specification gaming](https://deepmind.google/blog/specification-gaming-the-flip-side-of-ai-ingenuity/)
- [Goal Misgeneralization in Deep Reinforcement Learning](https://arxiv.org/abs/2210.01790)

这支持把主线、合同、指标、测试和 AI 自述都视为候选翻译。它们不能循环证明自己正确。

### 读取最终状态并审完整轨迹

成熟 agent 评测分别检查目标状态与行动轨迹，避免完成声明、单一分数或窄测试掩盖捷径和错误环境：

- [tau-bench](https://arxiv.org/abs/2406.12045)
- [Inspect scoring](https://inspect.aisi.org.uk/scoring.html)
- [OpenAI trustworthy evaluation foundations](https://openai.com/index/trustworthy-third-party-evaluations-foundations/)

本 Skill 借用“真实状态回读、证据限界、正反例和事后攻击”，不安装新评测平台，也不把每个任务变成基准测试。

## 历史纠偏怎样提升为通用模式

新澳主线的多次转向呈现出同一生成模式：人要一个真实结果；系统为了严谨和可控先造代理对象；代理随后从手段升为父目标、开工门或唯一下一步。系统越来越自洽，人的现实结果却没有更接近。

去掉项目专名后，历史上至少出现过这些同构变化：

| 当时的替代 | 人为什么觉得不对 | 提升后的通用原则 |
|---|---|---|
| 下游实时条件倒灌成上游测量的开工门 | 本来可先认识和验证的对象，被尚未需要的账户、支付或 live 条件阻断 | 下游实施条件不能自动成为上游认识条件 |
| 最终证据集合被误写成一次原子战役 | 可分批积累的证据因为单次资源不足而整体停摆 | 完成集合不等于执行形状；资源只约束调度 |
| 平台、Foundation 和认证成为真实研究前置 | 系统一直证明自己能做，却没有让真实对象进入研究 | 基础设施只能保持仪器身份，不能取得业务或科学父结果 |
| 单一 canary/固定输出代表整个研究生态 | 一个局部实例在等待，被解释为父级无事可做 | canary 证明窄通路，不代表开放活动或完整 Portfolio |
| 容易结算的字段和对象收窄了人的完整目标 | 错对象被实现得越稳定，离真正任务越远 | 先验对象匹配，再验工程正确 |
| “有限闭合”重新变成功能清单 | 未发生的失败获得建设权，真实消费者继续缺席 | 有限由当前真实消费者的具名失败限定，不由清单长度限定 |
| 人给出的优先级被实体化成研究内容 | 人在表达关注方向，系统却开始研究权重本身 | 路由、优先级和出口不能反向定义内容 |
| 人的定性意义被强迫换成内部数值和字段 | 用户已经作出实质选择，却还要替 AI 编译实现 | 人负责意义与重大选择，系统负责技术编译 |
| AI 自己写下的 checkpoint/RQ/交接取得意图权威 | 系统开始服从自己的旧文本，而不是继续理解当前的人 | 历史文本保存证据，不继承人的意图权威 |

这些案例的共同伤害不是“用户主观上不喜欢”，而是对象、因果链、角色、负担或完成语义发生了可观察替代。用户的异样感是报警器，不是错误成立的来源。

## 提升与使用边界

历史案例进入本 Skill 时必须去掉项目名、工具名、数量、路径和当时的修复形状，只保留：受保护的人类结果、发生的现实伤害、替代发生的翻译边、可证伪反事实和最薄通用原则。

最重要的反事实是：

> 即使所有当前文档、测试、容器、流程和回执都绿，一个不了解内部工程的人是否已经在现实中得到他要的变化？

若答案是否定的，先检查是否有手段取得了父结果身份。若答案肯定且证据来自真实消费者，应允许 `ALIGNED`，不制造整改。
