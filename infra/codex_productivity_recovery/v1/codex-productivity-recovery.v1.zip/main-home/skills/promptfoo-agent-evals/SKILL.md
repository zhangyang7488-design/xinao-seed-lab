---
name: promptfoo-agent-evals
description: Build and run repeatable local Promptfoo evaluations for prompts, model outputs, tool-using agents, MCP behavior, regressions, and red-team cases. Use when acceptance criteria need golden cases, deterministic assertions, structured JSON evidence, provider comparisons, or trajectory-level evaluation beyond ordinary unit tests.
---

# Promptfoo agent evals

Prefer an existing project-owned Promptfoo runner before invoking the CLI directly. A canonical
runner owns provider resolution, state isolation, retries, filtering, and evidence shape. In
`E:\XINAO_RESEARCH_WORKSPACES\S`, use:

```powershell
.\scripts\run_behavior_regression.ps1 -Profile context `
  -CasePattern '<affected case description>' -MaxConcurrency 1
```

Use the pinned CLI directly only when the project has no canonical runner:

`D:\XINAO_RESEARCH_RUNTIME\tools\promptfoo\node_modules\.bin\promptfoo.cmd`

## Workflow

1. Search the project catalog, README, and scripts for a canonical eval runner and use it when present.
2. Confirm the CLI reports version `0.121.18` when direct invocation is actually required.
3. Keep the eval config and fixtures with the project or in the task's D-drive evidence directory.
4. Prefer deterministic assertions (`equals`, `contains`, JSON schema, JavaScript/Python predicates) before model-graded assertions.
5. Use a local file, executable, or explicitly authorized provider. Never place API keys in the eval config or artifacts.
6. On Windows, `openai:codex-app-server` must receive the native `codex.exe`; reject `.cmd` and `.ps1` shims. Let the project runner resolve and preflight it whenever possible.
7. Give every direct run a writable, operation-scoped state directory on `D:`. Set `PROMPTFOO_CONFIG_DIR`, `PROMPTFOO_LOG_DIR`, `PROMPTFOO_CACHE_PATH`, `TEMP`, and `TMP` before the first CLI invocation; Promptfoo and its `tsx` loader otherwise touch the user profile even for `--version`.
8. Set `PROMPTFOO_DISABLE_TELEMETRY=1`, `PROMPTFOO_DISABLE_UPDATE=1`, `PROMPTFOO_DISABLE_DEBUG_LOG=1`, `PROMPTFOO_DISABLE_ERROR_LOG=1`, and `TSX_DISABLE_CACHE=1` for local runs.
9. Run without the web viewer or hosted service and export machine-readable JSON.
10. Inspect failing cases and raw outputs; a summary score alone is not completion evidence.

Direct fallback example (only when no canonical project runner exists):

```powershell
$operationId = [guid]::NewGuid().ToString('N')
$runState = Join-Path 'D:\XINAO_RESEARCH_RUNTIME\state\promptfoo\runs' $operationId
$configDir = Join-Path $runState 'config'
$logDir = Join-Path $runState 'logs'
$cacheDir = Join-Path $runState 'cache'
$tempDir = Join-Path $runState 'tmp'
New-Item -ItemType Directory -Force -Path $configDir, $logDir, $cacheDir, $tempDir | Out-Null

$env:PROMPTFOO_CONFIG_DIR = $configDir
$env:PROMPTFOO_LOG_DIR = $logDir
$env:PROMPTFOO_CACHE_PATH = $cacheDir
$env:PROMPTFOO_DISABLE_TELEMETRY = '1'
$env:PROMPTFOO_DISABLE_UPDATE = '1'
$env:PROMPTFOO_DISABLE_DEBUG_LOG = '1'
$env:PROMPTFOO_DISABLE_ERROR_LOG = '1'
$env:TSX_DISABLE_CACHE = '1'
$env:TEMP = $tempDir
$env:TMP = $tempDir
& 'D:\XINAO_RESEARCH_RUNTIME\tools\promptfoo\node_modules\.bin\promptfoo.cmd' eval `
  --config .\promptfooconfig.yaml --output .\results.json --no-cache
```

Use ordinary repository tests for deterministic program behavior. Add Promptfoo only when the evaluated object is a prompt, model/agent response, tool trajectory, or safety behavior. Do not start a resident server or install a second agent runtime.
