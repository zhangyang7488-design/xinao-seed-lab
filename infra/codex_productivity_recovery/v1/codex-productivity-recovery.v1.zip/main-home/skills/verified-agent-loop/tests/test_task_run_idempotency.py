from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from typing import Mapping


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "task_run.py"
LAUNCHER = SCRIPT.with_suffix(".cmd")
SKILL = Path(__file__).resolve().parents[1] / "SKILL.md"


def _run(
    root: Path, *args: str, env: Mapping[str, str] | None = None
) -> subprocess.CompletedProcess[str]:
    process_env = dict(env or {})
    if env is None:
        import os

        process_env = dict(os.environ)
        process_env.pop("CODEX_THREAD_ID", None)
    return subprocess.run(
        [sys.executable, str(SCRIPT), "--root", str(root), *args],
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        env=process_env,
    )


def test_windows_launcher_prevents_bare_python_file_open() -> None:
    assert LAUNCHER.is_file(), "a .cmd execution carrier is required on Windows"
    launcher_text = LAUNCHER.read_text(encoding="utf-8").lower()
    assert '"%systemroot%\\py.exe" -3 "%~dp0task_run.py" %*' in launcher_text

    skill_text = SKILL.read_text(encoding="utf-8")
    for subcommand in ("init", "event", "verify", "finish"):
        assert f"`scripts/task_run.cmd {subcommand}" in skill_text
        assert f"`scripts/task_run.py {subcommand}" not in skill_text

    completed = subprocess.run(
        ["cmd.exe", "/d", "/c", str(LAUNCHER), "--help"],
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    assert completed.returncode == 0, completed.stderr
    assert "usage: task_run.py" in completed.stdout


def _init(root: Path, run_id: str = "run-1") -> Path:
    completed = _run(
        root,
        "init",
        "--run-id",
        run_id,
        "--mode",
        "bounded_task",
        "--objective",
        "prove task-run idempotency",
        "--risk",
        "reversible_local",
        "--completion",
        "event is durable",
    )
    assert completed.returncode == 0, completed.stderr
    return root / run_id


def _event_args(
    event_id: str,
    *,
    evidence: str = "evidence#sha256=abc",
    side_effect_id: str = "se:test",
    expected_events_count: int | None = None,
    expected_events_sha256: str | None = None,
) -> tuple[str, ...]:
    arguments = [
        "event",
        "--run-id",
        "run-1",
        "--event-id",
        event_id,
        "--actor",
        "runtime-consumer",
        "--kind",
        "result",
        "--phase",
        "effect_verified",
        "--summary",
        "effect verified",
        "--evidence-ref",
        evidence,
        "--target",
        "wk:test",
        "--exit-code",
        "0",
        "--side-effect-id",
        side_effect_id,
    ]
    if expected_events_count is not None:
        arguments.extend(["--expected-events-count", str(expected_events_count)])
    if expected_events_sha256 is not None:
        arguments.extend(["--expected-events-sha256", expected_events_sha256])
    return tuple(arguments)


def _events(run_dir: Path) -> list[dict[str, object]]:
    return [
        json.loads(line)
        for line in (run_dir / "events.jsonl").read_text(encoding="utf-8").splitlines()
    ]


def _module():
    spec = importlib.util.spec_from_file_location("verified_task_run", SCRIPT)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_concurrent_same_stable_event_id_appends_once(tmp_path: Path) -> None:
    run_dir = _init(tmp_path)
    with ThreadPoolExecutor(max_workers=2) as executor:
        results = list(
            executor.map(
                lambda _: _run(tmp_path, *_event_args("evt-stable-1")), range(2)
            )
        )

    assert [result.returncode for result in results] == [0, 0]
    payloads = [json.loads(result.stdout) for result in results]
    assert {payload["event_id"] for payload in payloads} == {"evt-stable-1"}
    assert sorted(payload["replayed"] for payload in payloads) == [False, True]
    assert [event["event_id"] for event in _events(run_dir)].count("evt-stable-1") == 1
    assert (
        json.loads((run_dir / "state.json").read_text(encoding="utf-8"))["events_count"]
        == 2
    )


def test_same_event_id_with_changed_semantics_is_rejected_without_append(
    tmp_path: Path,
) -> None:
    run_dir = _init(tmp_path)
    assert _run(tmp_path, *_event_args("evt-stable-1")).returncode == 0
    before = (run_dir / "events.jsonl").read_bytes()

    changed = _run(
        tmp_path,
        *_event_args("evt-stable-1", evidence="different#sha256=def"),
    )

    assert changed.returncode == 2
    assert "changed event semantics" in changed.stderr
    assert (run_dir / "events.jsonl").read_bytes() == before


def test_stable_side_effect_cannot_move_to_another_event_id(tmp_path: Path) -> None:
    run_dir = _init(tmp_path)
    assert _run(tmp_path, *_event_args("evt-stable-1")).returncode == 0
    before = (run_dir / "events.jsonl").read_bytes()

    conflict = _run(tmp_path, *_event_args("evt-stable-2"))

    assert conflict.returncode == 2
    assert "different event_id" in conflict.stderr
    assert (run_dir / "events.jsonl").read_bytes() == before


def test_expected_event_count_is_an_atomic_append_precondition(tmp_path: Path) -> None:
    run_dir = _init(tmp_path)
    initial_sha256 = hashlib.sha256((run_dir / "events.jsonl").read_bytes()).hexdigest()
    first = _run(
        tmp_path,
        *_event_args(
            "evt-head-1",
            expected_events_count=1,
            expected_events_sha256=initial_sha256,
        ),
    )
    assert first.returncode == 0, first.stderr
    before = (run_dir / "events.jsonl").read_bytes()

    stale = _run(
        tmp_path,
        *_event_args(
            "evt-head-2",
            side_effect_id="se:head-2",
            expected_events_count=1,
        ),
    )
    assert stale.returncode == 2
    assert "event head changed" in stale.stderr
    assert (run_dir / "events.jsonl").read_bytes() == before

    stale_hash = _run(
        tmp_path,
        *_event_args(
            "evt-head-3",
            side_effect_id="se:head-3",
            expected_events_count=2,
            expected_events_sha256=initial_sha256,
        ),
    )
    assert stale_hash.returncode == 2
    assert "event head changed" in stale_hash.stderr
    assert (run_dir / "events.jsonl").read_bytes() == before

    replay = _run(
        tmp_path,
        *_event_args(
            "evt-head-1",
            expected_events_count=1,
            expected_events_sha256=initial_sha256,
        ),
    )
    assert replay.returncode == 0, replay.stderr
    assert json.loads(replay.stdout)["replayed"] is True


def test_one_fsynced_event_tail_repairs_state_and_replays(tmp_path: Path) -> None:
    run_dir = _init(tmp_path)
    module = _module()
    event = module._event(
        run_id="run-1",
        actor="runtime-consumer",
        kind="result",
        phase="effect_verified",
        summary="effect verified",
        evidence_refs=["evidence#sha256=abc"],
        target="wk:test",
        exit_code=0,
        retry_class="none",
        side_effect_id="se:test",
        event_id="evt-stable-1",
    )
    module._append_event(run_dir / "events.jsonl", event)

    replay = _run(tmp_path, *_event_args("evt-stable-1"))

    assert replay.returncode == 0, replay.stderr
    payload = json.loads(replay.stdout)
    assert payload["replayed"] is True
    assert payload["projection_repaired"] is True
    assert len(_events(run_dir)) == 2
    state = json.loads((run_dir / "state.json").read_text(encoding="utf-8"))
    assert state["events_count"] == 2
    assert state["current_phase"] == "effect_verified"
    assert _run(tmp_path, "validate", "--run-id", "run-1").returncode == 0


def test_unknown_multi_event_tail_and_state_lead_fail_closed(tmp_path: Path) -> None:
    first = _init(tmp_path / "multi")
    module = _module()
    for ordinal in (1, 2):
        module._append_event(
            first / "events.jsonl",
            module._event(
                run_id="run-1",
                actor="runtime-consumer",
                kind="result",
                phase="effect_verified",
                summary=f"effect {ordinal}",
                evidence_refs=[f"evidence-{ordinal}#sha256=abc"],
                target=f"wk:{ordinal}",
                side_effect_id=f"se:{ordinal}",
                event_id=f"evt-{ordinal}",
            ),
        )
    multi = _run(tmp_path / "multi", "show", "--run-id", "run-1")
    assert multi.returncode == 2
    assert "exceeds the recoverable one-event tail" in multi.stderr

    second = _init(tmp_path / "lead")
    state_path = second / "state.json"
    state = json.loads(state_path.read_text(encoding="utf-8"))
    state["events_count"] = 2
    state_path.write_text(json.dumps(state), encoding="utf-8")
    lead = _run(tmp_path / "lead", "show", "--run-id", "run-1")
    assert lead.returncode == 2
    assert "cannot be recovered safely" in lead.stderr


def test_finished_event_carries_terminal_status_for_tail_recovery(
    tmp_path: Path,
) -> None:
    run_dir = _init(tmp_path)
    module = _module()
    terminal = module._event(
        run_id="run-1",
        actor="coordinator",
        kind="result",
        phase="finished",
        summary="partial closure",
        terminal_status="partial",
        event_id="evt-finish",
    )
    module._append_event(run_dir / "events.jsonl", terminal)

    shown = _run(tmp_path, "show", "--run-id", "run-1")

    assert shown.returncode == 0, shown.stderr
    payload = json.loads(shown.stdout)
    assert payload["projection_repaired"] is True
    assert payload["state"]["status"] == "partial"
    assert payload["state"]["events_count"] == 2


def test_init_auto_binds_current_session_before_returning_success(
    tmp_path: Path,
) -> None:
    import os

    root = tmp_path / "runs"
    receipt_path = tmp_path / "binding.json"
    binder_path = tmp_path / "fake_frontier_binder.py"
    binder_path.write_text(
        """
import json
import os
from pathlib import Path

def bind_session(*, session_id, run_directory, allowed_run_root, **_kwargs):
    receipt = {
        'session_id': session_id,
        'run_directory': str(Path(run_directory).resolve()),
        'allowed_roots': [str(Path(item).resolve()) for item in allowed_run_root],
        'status': 'bound',
    }
    Path(os.environ['TEST_BINDING_RECEIPT']).write_text(json.dumps(receipt), encoding='utf-8')
    return receipt
""".lstrip(),
        encoding="utf-8",
    )
    env = {
        **os.environ,
        "CODEX_THREAD_ID": "session-auto-bind",
        "XINAO_SESSION_FRONTIER_BINDER": str(binder_path),
        "XINAO_SESSION_FRONTIER_RUN_ROOTS": str(root),
        "TEST_BINDING_RECEIPT": str(receipt_path),
    }

    completed = _run(
        root,
        "init",
        "--run-id",
        "run-bound",
        "--mode",
        "bounded_task",
        "--objective",
        "bind the verified task run",
        "--risk",
        "reversible_local",
        "--completion",
        "binding is visible",
        env=env,
    )

    assert completed.returncode == 0, completed.stderr
    output = json.loads(completed.stdout)
    assert output["session_binding"]["status"] == "bound"
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    assert receipt["session_id"] == "session-auto-bind"
    assert receipt["run_directory"] == str((root / "run-bound").resolve())


def test_init_binding_failure_removes_the_created_run(tmp_path: Path) -> None:
    import os

    root = tmp_path / "runs"
    binder_path = tmp_path / "failing_frontier_binder.py"
    binder_path.write_text(
        """
def bind_session(**_kwargs):
    raise RuntimeError('forced bind failure')
""".lstrip(),
        encoding="utf-8",
    )
    env = {
        **os.environ,
        "CODEX_THREAD_ID": "session-bind-fails",
        "XINAO_SESSION_FRONTIER_BINDER": str(binder_path),
        "XINAO_SESSION_FRONTIER_RUN_ROOTS": str(root),
    }

    completed = _run(
        root,
        "init",
        "--run-id",
        "run-bind-fails",
        "--mode",
        "bounded_task",
        "--objective",
        "leave no ghost task run",
        "--risk",
        "reversible_local",
        "--completion",
        "failed binding is atomic",
        env=env,
    )

    assert completed.returncode == 2
    assert "initialized run rolled back without a residual run" in completed.stderr
    assert not (root / "run-bind-fails").exists()


def test_init_binding_failure_preserves_foreign_run_evidence(tmp_path: Path) -> None:
    import os

    root = tmp_path / "runs"
    binder_path = tmp_path / "foreign_writing_frontier_binder.py"
    binder_path.write_text(
        """
from pathlib import Path

def bind_session(*, run_directory, **_kwargs):
    Path(run_directory, 'foreign.txt').write_text('preserve me', encoding='utf-8')
    raise RuntimeError('forced bind failure after foreign write')
""".lstrip(),
        encoding="utf-8",
    )
    env = {
        **os.environ,
        "CODEX_THREAD_ID": "session-bind-foreign",
        "XINAO_SESSION_FRONTIER_BINDER": str(binder_path),
        "XINAO_SESSION_FRONTIER_RUN_ROOTS": str(root),
    }

    completed = _run(
        root,
        "init",
        "--run-id",
        "run-bind-foreign",
        "--mode",
        "bounded_task",
        "--objective",
        "preserve foreign evidence",
        "--risk",
        "reversible_local",
        "--completion",
        "foreign bytes survive cleanup",
        env=env,
    )

    run_dir = root / "run-bind-foreign"
    assert completed.returncode == 2
    assert "foreign or changed entries were preserved" in completed.stderr
    assert (run_dir / "foreign.txt").read_text(encoding="utf-8") == "preserve me"
    assert not (run_dir / "task.json").exists()
    assert not (run_dir / "evidence.json").exists()
    assert not (run_dir / "events.jsonl").exists()
    assert not (run_dir / "state.json").exists()


def test_init_marks_unrecoverable_root_without_breaking_isolated_run(
    tmp_path: Path,
) -> None:
    import os

    requested_root = tmp_path / "unsupported"
    env = {
        **os.environ,
        "CODEX_THREAD_ID": "session-would-be-unbound",
        "XINAO_SESSION_FRONTIER_RUN_ROOTS": str(tmp_path / "canonical"),
    }

    completed = _run(
        requested_root,
        "init",
        "--run-id",
        "run-rejected",
        "--mode",
        "bounded_task",
        "--objective",
        "must not become an unbound run",
        "--risk",
        "reversible_local",
        "--completion",
        "no hidden compact gap",
        env=env,
    )

    assert completed.returncode == 0, completed.stderr
    output = json.loads(completed.stdout)
    assert output["session_binding"]["status"] == "not_applicable"
    assert "outside compact-recoverable roots" in output["session_binding"]["reason"]
    assert (requested_root / "run-rejected" / "task.json").is_file()
