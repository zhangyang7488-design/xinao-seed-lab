#!/usr/bin/env python3
"""Create and maintain a compact, local, evidence-indexed Codex task run."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import re
import sys
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator, Sequence

SCHEMA_VERSION = "codex.verified-task-run.v1"
DEFAULT_ROOT = Path(
    os.environ.get(
        "XINAO_CODEX_RUN_ROOT",
        r"D:\XINAO_RESEARCH_RUNTIME\state\Codex_Situation_Island\runs",
    )
)
DEFAULT_SESSION_FRONTIER_BINDER = Path(
    os.environ.get(
        "XINAO_SESSION_FRONTIER_BINDER",
        r"E:\XINAO_RESEARCH_WORKSPACES\S\scripts\manage_session_frontier.py",
    )
)
DEFAULT_SESSION_FRONTIER_RUN_ROOTS = (
    DEFAULT_ROOT,
    Path(r"D:\XINAO_RESEARCH_RUNTIME\state\codex_task_runs"),
)
RUN_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$")
EVENT_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,199}$")
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
SECRET_RE = re.compile(
    r"(?i)\b(api[_ -]?key|authorization|password|secret|token)"
    r"(\s*[:=]\s*)([^\s,;]+)"
)
MODES = ("dialogue", "plan_only", "bounded_task", "continuous")
RISKS = ("read_only", "reversible_local", "external", "irreversible")
STATUSES = ("verified", "partial", "blocked", "unverified")
EVENT_KINDS = (
    "observation",
    "action",
    "result",
    "failure",
    "checkpoint",
    "reflection",
)
RETRY_CLASSES = ("none", "transient", "deterministic")
VERDICTS = ("pass", "fail", "unverified")


class RunError(RuntimeError):
    """A safe-to-display task run validation error."""


def _utc_now() -> str:
    return (
        datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    )


def _clean_text(value: str, *, field: str, limit: int = 2_000) -> str:
    text = str(value).strip()
    if not text:
        raise RunError(f"{field} must not be empty")
    if "\x00" in text:
        raise RunError(f"{field} contains a NUL byte")
    text = SECRET_RE.sub(
        lambda match: f"{match.group(1)}{match.group(2)}<redacted>", text
    )
    if len(text) > limit:
        raise RunError(f"{field} exceeds {limit} characters")
    return text


def _clean_many(values: Sequence[str], *, field: str, limit: int = 1_000) -> list[str]:
    return [_clean_text(value, field=field, limit=limit) for value in values]


def _run_id(value: str | None) -> str:
    if value is None:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        return f"{stamp}-{uuid.uuid4().hex[:8]}"
    normalized = value.strip()
    if not RUN_ID_RE.fullmatch(normalized) or normalized in {".", ".."}:
        raise RunError("run_id must match [A-Za-z0-9][A-Za-z0-9._-]{0,79}")
    return normalized


def _event_id(value: str | None) -> tuple[str, bool]:
    if value is None:
        return str(uuid.uuid4()), False
    normalized = value.strip()
    if not EVENT_ID_RE.fullmatch(normalized) or normalized in {".", ".."}:
        raise RunError("event_id must match [A-Za-z0-9][A-Za-z0-9._:-]{0,199}")
    return normalized, True


def _run_dir(root: Path, run_id: str) -> Path:
    base = root.expanduser().resolve()
    candidate = (base / run_id).resolve()
    if candidate.parent != base:
        raise RunError("run_id escaped the run root")
    return candidate


@contextmanager
def _exclusive_lock(run_dir: Path, timeout_seconds: float = 5.0) -> Iterator[None]:
    run_dir.mkdir(parents=True, exist_ok=True)
    lock_path = run_dir / ".lock"
    handle = lock_path.open("a+b")
    try:
        handle.seek(0, os.SEEK_END)
        if handle.tell() == 0:
            handle.write(b"0")
            handle.flush()
        deadline = time.monotonic() + timeout_seconds
        while True:
            try:
                handle.seek(0)
                if os.name == "nt":
                    import msvcrt

                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl

                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError as exc:
                if time.monotonic() >= deadline:
                    raise RunError("task run is busy; retry shortly") from exc
                time.sleep(0.05)
        yield
    finally:
        try:
            handle.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        finally:
            handle.close()


def _read_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise RunError(f"missing run file: {path.name}") from exc
    except json.JSONDecodeError as exc:
        raise RunError(f"invalid JSON in {path.name}: {exc}") from exc
    if not isinstance(data, dict):
        raise RunError(f"{path.name} must contain a JSON object")
    return data


def _write_json_atomic(path: Path, value: dict[str, Any]) -> None:
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    payload = json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _rollback_failed_init(
    directory: Path,
    *,
    directory_created_here: bool,
    owned_sha256: dict[Path, str],
) -> list[str]:
    """Remove only unchanged init-owned bytes; preserve foreign or changed evidence."""
    for path, expected_sha256 in owned_sha256.items():
        try:
            if path.parent != directory or path.is_symlink() or not path.is_file():
                continue
            if _sha256_file(path) == expected_sha256:
                path.unlink()
        except OSError:
            continue

    if directory_created_here:
        lock_path = directory / ".lock"
        try:
            entries = list(directory.iterdir())
            if (
                entries == [lock_path]
                and lock_path.is_file()
                and not lock_path.is_symlink()
                and lock_path.read_bytes() == b"0"
            ):
                lock_path.unlink()
                directory.rmdir()
        except OSError:
            pass

    if not directory.exists():
        return []
    try:
        return sorted(item.name for item in directory.iterdir())
    except OSError:
        return ["<unreadable-run-directory>"]


def _session_frontier_run_roots() -> tuple[Path, ...]:
    configured = os.environ.get("XINAO_SESSION_FRONTIER_RUN_ROOTS")
    candidates = (
        [Path(item) for item in configured.split(os.pathsep) if item.strip()]
        if configured
        else list(DEFAULT_SESSION_FRONTIER_RUN_ROOTS)
    )
    roots: list[Path] = []
    for candidate in candidates:
        root = candidate.expanduser().resolve()
        if root not in roots:
            roots.append(root)
    if not roots:
        raise RunError("no compact-recoverable task-run root is configured")
    return tuple(roots)


def _prepare_session_binding(
    root: Path,
) -> tuple[str, Any, tuple[Path, ...], str | None] | dict[str, str] | None:
    session_id = str(os.environ.get("CODEX_THREAD_ID") or "").strip()
    if not session_id:
        return None
    run_root = root.expanduser().resolve()
    allowed_roots = _session_frontier_run_roots()
    if run_root not in allowed_roots:
        return {
            "status": "not_applicable",
            "reason": f"task-run root is outside compact-recoverable roots: {run_root}",
        }
    binder_path = (
        Path(
            os.environ.get("XINAO_SESSION_FRONTIER_BINDER")
            or DEFAULT_SESSION_FRONTIER_BINDER
        )
        .expanduser()
        .resolve()
    )
    if not binder_path.is_file():
        raise RunError(f"session frontier binder is missing: {binder_path}")
    spec = importlib.util.spec_from_file_location(
        "xinao_session_frontier_binder", binder_path
    )
    if spec is None or spec.loader is None:
        raise RunError("session frontier binder cannot be loaded")
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
    except Exception as exc:
        raise RunError(f"session frontier binder import failed: {exc}") from exc
    if not callable(getattr(module, "bind_session", None)):
        raise RunError("session frontier binder lacks bind_session")
    expected_current_run_id = None
    if callable(getattr(module, "load_binding", None)):
        try:
            current = module.load_binding(
                session_id=session_id,
                allowed_run_root=allowed_roots,
            )
            expected_current_run_id = str(current.get("run_id") or "") or None
        except Exception as exc:
            frontier_error = getattr(module, "FrontierProjectionError", None)
            if frontier_error is None or not isinstance(exc, frontier_error):
                raise RunError(
                    f"existing session binding preflight failed: {exc}"
                ) from exc
    return session_id, module, allowed_roots, expected_current_run_id


def _bind_prepared_session(
    prepared: tuple[str, Any, tuple[Path, ...], str | None] | dict[str, str] | None,
    directory: Path,
) -> dict[str, Any]:
    if prepared is None:
        return {"status": "not_applicable", "reason": "CODEX_THREAD_ID is absent"}
    if isinstance(prepared, dict):
        return prepared
    session_id, module, allowed_roots, expected_current_run_id = prepared
    try:
        result = module.bind_session(
            session_id=session_id,
            run_directory=directory,
            allowed_run_root=allowed_roots,
            expected_current_run_id=expected_current_run_id,
        )
    except Exception as exc:
        raise RunError(f"session binding failed: {exc}") from exc
    return {**result, "status": "bound"}


def _append_event(path: Path, event: dict[str, Any]) -> None:
    payload = json.dumps(
        event, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(payload + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def _event(
    *,
    run_id: str,
    actor: str,
    kind: str,
    phase: str,
    summary: str,
    evidence_refs: Sequence[str] = (),
    target: str | None = None,
    exit_code: int | None = None,
    duration_ms: int | None = None,
    retry_class: str = "none",
    side_effect_id: str | None = None,
    event_id: str | None = None,
    terminal_status: str | None = None,
) -> dict[str, Any]:
    identifier, keyed = _event_id(event_id)
    event = {
        "schema_version": SCHEMA_VERSION,
        "event_id": identifier,
        "run_id": run_id,
        "timestamp": _utc_now(),
        "actor": _clean_text(actor, field="actor", limit=120),
        "kind": kind,
        "phase": _clean_text(phase, field="phase", limit=120),
        "summary": _clean_text(summary, field="summary"),
        "evidence_refs": _clean_many(evidence_refs, field="evidence_ref"),
        "target": None if target is None else _clean_text(target, field="target"),
        "exit_code": exit_code,
        "duration_ms": duration_ms,
        "retry_class": retry_class,
        "side_effect_id": (
            None
            if side_effect_id is None
            else _clean_text(side_effect_id, field="side_effect_id", limit=200)
        ),
    }
    if keyed:
        event["idempotency_keyed"] = True
    if terminal_status is not None:
        if terminal_status not in STATUSES:
            raise RunError("terminal_status is invalid")
        event["terminal_status"] = terminal_status
    return event


def _event_semantics(event: dict[str, Any]) -> dict[str, Any]:
    return {
        key: event.get(key)
        for key in (
            "actor",
            "kind",
            "phase",
            "summary",
            "evidence_refs",
            "target",
            "exit_code",
            "duration_ms",
            "retry_class",
            "side_effect_id",
            "terminal_status",
        )
    }


def _load_run(root: Path, run_id: str) -> tuple[Path, dict[str, Any], dict[str, Any]]:
    directory = _run_dir(root, run_id)
    task = _read_json(directory / "task.json")
    state = _read_json(directory / "state.json")
    if task.get("run_id") != run_id or state.get("run_id") != run_id:
        raise RunError("run_id does not match persisted state")
    return directory, task, state


def _command_init(args: argparse.Namespace) -> dict[str, Any]:
    run_id = _run_id(args.run_id)
    directory = _run_dir(args.root, run_id)
    objective = _clean_text(args.objective, field="objective", limit=4_000)
    criteria = _clean_many(args.completion, field="completion criterion")
    if args.mode in {"bounded_task", "continuous"} and not criteria:
        raise RunError(
            "bounded_task and continuous runs require at least one completion criterion"
        )
    prepared_binding = _prepare_session_binding(args.root)
    now = _utc_now()
    task = {
        "schema_version": SCHEMA_VERSION,
        "run_id": run_id,
        "request_hash": hashlib.sha256(
            json.dumps(
                {"objective": objective, "criteria": criteria},
                ensure_ascii=False,
                sort_keys=True,
            ).encode("utf-8")
        ).hexdigest(),
        "created_at": now,
        "mode": args.mode,
        "objective": objective,
        "scope": {
            "read_roots": _clean_many(args.read_root, field="read_root"),
            "write_roots": _clean_many(args.write_root, field="write_root"),
            "external_effects": _clean_many(
                args.external_effect, field="external_effect"
            ),
        },
        "risk": args.risk,
        "limits": {
            "max_agents": args.max_agents,
            "max_attempts": args.max_attempts,
            "deadline_sec": args.deadline_sec,
        },
        "completion_criteria": criteria,
        "stop_conditions": _clean_many(args.stop, field="stop condition"),
    }
    state = {
        "schema_version": SCHEMA_VERSION,
        "run_id": run_id,
        "status": "in_progress",
        "created_at": now,
        "updated_at": now,
        "current_phase": "initialized",
        "events_count": 1,
        "transient_retries_used": 0,
        "last_summary": "Task envelope initialized",
    }
    evidence = {
        "schema_version": SCHEMA_VERSION,
        "run_id": run_id,
        "criteria": [
            {
                "index": index,
                "criterion": criterion,
                "verdict": "pending",
                "observations": [],
            }
            for index, criterion in enumerate(criteria, start=1)
        ],
    }
    directory_created_here = not directory.exists()
    owned_sha256: dict[Path, str] = {}
    binding_error: RunError | None = None
    with _exclusive_lock(directory):
        if (directory / "task.json").exists():
            raise RunError(f"run already exists: {run_id}")
        _write_json_atomic(directory / "task.json", task)
        _write_json_atomic(directory / "evidence.json", evidence)
        _append_event(
            directory / "events.jsonl",
            _event(
                run_id=run_id,
                actor=args.actor,
                kind="checkpoint",
                phase="initialized",
                summary="Task envelope initialized",
            ),
        )
        _write_json_atomic(directory / "state.json", state)
        owned_sha256 = {
            path: _sha256_file(path)
            for path in (
                directory / "task.json",
                directory / "evidence.json",
                directory / "events.jsonl",
                directory / "state.json",
            )
        }
        try:
            session_binding = _bind_prepared_session(prepared_binding, directory)
        except RunError as exc:
            binding_error = exc

    if binding_error is not None:
        residual_entries = _rollback_failed_init(
            directory,
            directory_created_here=directory_created_here,
            owned_sha256=owned_sha256,
        )
        if residual_entries:
            residual = ", ".join(residual_entries)
            raise RunError(
                f"{binding_error}; unchanged init files were rolled back, "
                f"but foreign or changed entries were preserved: {residual}"
            ) from binding_error
        raise RunError(
            f"{binding_error}; initialized run rolled back without a residual run"
        ) from binding_error
    return {
        "ok": True,
        "run_id": run_id,
        "directory": str(directory),
        "state": state,
        "session_binding": session_binding,
    }


def _command_event(args: argparse.Namespace) -> dict[str, Any]:
    run_id = _run_id(args.run_id)
    directory = _run_dir(args.root, run_id)
    with _exclusive_lock(directory):
        directory, task, state = _load_run(args.root, run_id)
        events = _read_events(directory / "events.jsonl")
        state, projection_repaired = _reconcile_state_projection(
            directory=directory,
            run_id=run_id,
            state=state,
            events=events,
            allow_one_event_tail=True,
        )
        if args.kind == "reflection" and not args.evidence_ref:
            raise RunError("reflection events require external evidence references")
        event = _event(
            run_id=run_id,
            actor=args.actor,
            kind=args.kind,
            phase=args.phase,
            summary=args.summary,
            evidence_refs=args.evidence_ref,
            target=args.target,
            exit_code=args.exit_code,
            duration_ms=args.duration_ms,
            retry_class=args.retry_class,
            side_effect_id=args.side_effect_id,
            event_id=args.event_id,
        )
        if args.event_id:
            existing = next(
                (item for item in events if item.get("event_id") == event["event_id"]),
                None,
            )
            if existing is not None:
                if _event_semantics(existing) != _event_semantics(event):
                    raise RunError("event_id replay changed event semantics")
                return {
                    "ok": True,
                    "run_id": run_id,
                    "event_id": existing["event_id"],
                    "replayed": True,
                    "projection_repaired": projection_repaired,
                    "state": state,
                }
            if args.side_effect_id:
                conflict = next(
                    (
                        item
                        for item in events
                        if item.get("idempotency_keyed") is True
                        and item.get("phase") == event["phase"]
                        and item.get("target") == event["target"]
                        and item.get("side_effect_id") == event["side_effect_id"]
                    ),
                    None,
                )
                if conflict is not None:
                    raise RunError(
                        "stable side effect already belongs to a different event_id"
                    )
        if args.expected_events_count is not None and args.expected_events_count != len(
            events
        ):
            raise RunError(
                "event head changed: "
                f"expected_events_count={args.expected_events_count} "
                f"observed_events_count={len(events)}"
            )
        if args.expected_events_sha256 is not None:
            if not SHA256_RE.fullmatch(args.expected_events_sha256):
                raise RunError("expected_events_sha256 is invalid")
            observed_events_sha256 = hashlib.sha256(
                (directory / "events.jsonl").read_bytes()
            ).hexdigest()
            if args.expected_events_sha256 != observed_events_sha256:
                raise RunError(
                    "event head changed: "
                    f"expected_events_sha256={args.expected_events_sha256} "
                    f"observed_events_sha256={observed_events_sha256}"
                )
        if state.get("status") != "in_progress":
            raise RunError(f"run is already closed with status={state.get('status')}")
        if args.kind == "failure" and args.retry_class == "transient":
            used = int(state.get("transient_retries_used", 0)) + 1
            if used > int(task["limits"]["max_attempts"]):
                raise RunError("transient retry budget exhausted")
            state["transient_retries_used"] = used
        _append_event(directory / "events.jsonl", event)
        state.update(
            {
                "updated_at": event["timestamp"],
                "current_phase": event["phase"],
                "events_count": int(state.get("events_count", 0)) + 1,
                "last_summary": event["summary"],
            }
        )
        _write_json_atomic(directory / "state.json", state)
    return {
        "ok": True,
        "run_id": run_id,
        "event_id": event["event_id"],
        "replayed": False,
        "projection_repaired": projection_repaired,
        "state": state,
    }


def _command_verify(args: argparse.Namespace) -> dict[str, Any]:
    run_id = _run_id(args.run_id)
    directory = _run_dir(args.root, run_id)
    with _exclusive_lock(directory):
        directory, _, state = _load_run(args.root, run_id)
        events = _read_events(directory / "events.jsonl")
        state, _ = _reconcile_state_projection(
            directory=directory,
            run_id=run_id,
            state=state,
            events=events,
            allow_one_event_tail=True,
        )
        if state.get("status") != "in_progress":
            raise RunError(f"run is already closed with status={state.get('status')}")
        evidence = _read_json(directory / "evidence.json")
        criteria = evidence.get("criteria")
        if not isinstance(criteria, list) or not 1 <= args.criterion <= len(criteria):
            raise RunError("criterion index is out of range")
        refs = _clean_many(args.evidence_ref, field="evidence_ref")
        if args.verdict == "pass" and not refs:
            raise RunError(
                "a passing criterion requires at least one evidence reference"
            )
        observation = {
            "checked_at": _utc_now(),
            "checker": _clean_text(args.checker, field="checker", limit=120),
            "verdict": args.verdict,
            "observed_terminal_state": _clean_text(
                args.observed, field="observed terminal state", limit=4_000
            ),
            "evidence_refs": refs,
        }
        record = criteria[args.criterion - 1]
        record["verdict"] = args.verdict
        record.setdefault("observations", []).append(observation)
        _write_json_atomic(directory / "evidence.json", evidence)
        event = _event(
            run_id=run_id,
            actor=args.checker,
            kind="result",
            phase="verification",
            summary=f"Criterion {args.criterion}: {args.verdict}",
            evidence_refs=refs,
        )
        _append_event(directory / "events.jsonl", event)
        state.update(
            {
                "updated_at": event["timestamp"],
                "current_phase": "verification",
                "events_count": int(state.get("events_count", 0)) + 1,
                "last_summary": event["summary"],
            }
        )
        _write_json_atomic(directory / "state.json", state)
    return {"ok": True, "run_id": run_id, "criterion": record}


def _command_finish(args: argparse.Namespace) -> dict[str, Any]:
    run_id = _run_id(args.run_id)
    directory = _run_dir(args.root, run_id)
    with _exclusive_lock(directory):
        directory, _, state = _load_run(args.root, run_id)
        events = _read_events(directory / "events.jsonl")
        state, _ = _reconcile_state_projection(
            directory=directory,
            run_id=run_id,
            state=state,
            events=events,
            allow_one_event_tail=True,
        )
        if state.get("status") != "in_progress":
            raise RunError(f"run is already closed with status={state.get('status')}")
        evidence = _read_json(directory / "evidence.json")
        criteria = evidence.get("criteria", [])
        if args.status == "verified":
            incomplete = [
                item.get("index")
                for item in criteria
                if item.get("verdict") != "pass"
                or not item.get("observations")
                or not item["observations"][-1].get("evidence_refs")
            ]
            if incomplete:
                raise RunError(
                    f"verified finish refused; incomplete criteria: {incomplete}"
                )
        event = _event(
            run_id=run_id,
            actor=args.actor,
            kind="result",
            phase="finished",
            summary=args.summary,
            evidence_refs=args.evidence_ref,
            terminal_status=args.status,
        )
        _append_event(directory / "events.jsonl", event)
        state.update(
            {
                "status": args.status,
                "updated_at": event["timestamp"],
                "current_phase": "finished",
                "events_count": int(state.get("events_count", 0)) + 1,
                "last_summary": event["summary"],
            }
        )
        _write_json_atomic(directory / "state.json", state)
    return {"ok": True, "run_id": run_id, "state": state}


def _read_events(path: Path) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except FileNotFoundError as exc:
        raise RunError("missing run file: events.jsonl") from exc
    for line_number, line in enumerate(lines, start=1):
        try:
            event = json.loads(line)
        except json.JSONDecodeError as exc:
            raise RunError(f"invalid events.jsonl line {line_number}: {exc}") from exc
        if not isinstance(event, dict):
            raise RunError(f"events.jsonl line {line_number} is not an object")
        events.append(event)
    return events


def _reconcile_state_projection(
    *,
    directory: Path,
    run_id: str,
    state: dict[str, Any],
    events: list[dict[str, Any]],
    allow_one_event_tail: bool,
) -> tuple[dict[str, Any], bool]:
    """Repair only the known append-fsync/state-replace crash window.

    ``events.jsonl`` is the write-ahead fact chain.  A state projection may lag
    by exactly one valid tail event; larger or opposite drift remains fail-closed.
    """

    if not events:
        raise RunError("events.jsonl must contain the initialized event")
    if any(event.get("run_id") != run_id for event in events):
        raise RunError("an event has the wrong run_id")
    identifiers = [str(event.get("event_id") or "") for event in events]
    if any(not identifier for identifier in identifiers) or len(
        set(identifiers)
    ) != len(identifiers):
        raise RunError("events.jsonl contains a missing or duplicate event_id")
    try:
        state_count = int(state.get("events_count", -1))
    except (TypeError, ValueError) as exc:
        raise RunError("state events_count is invalid") from exc
    if state_count < 1 or state_count > len(events):
        raise RunError("state/events projection cannot be recovered safely")

    projected_tail = events[state_count - 1]
    if state_count == len(events):
        if (
            projected_tail.get("idempotency_keyed") is not True
            and projected_tail.get("terminal_status") is None
        ):
            # Historical runs predate the recoverable projection contract and
            # sometimes carried manually curated phase/status summaries.
            return state, False
        if state.get("current_phase") != projected_tail.get("phase") or state.get(
            "last_summary"
        ) != projected_tail.get("summary"):
            raise RunError("state does not match its declared event prefix")
        terminal_status = projected_tail.get("terminal_status")
        if terminal_status is not None and state.get("status") != terminal_status:
            raise RunError("state terminal status does not match the final event")
        if terminal_status is None and projected_tail.get("phase") != "finished":
            if state.get("status") != "in_progress":
                raise RunError("non-terminal event chain has a closed state")
        return state, False

    if not allow_one_event_tail or len(events) != state_count + 1:
        raise RunError("state/events drift exceeds the recoverable one-event tail")
    if state.get("current_phase") != projected_tail.get("phase") or state.get(
        "last_summary"
    ) != projected_tail.get("summary"):
        raise RunError("state does not match its declared event prefix")
    if state.get("status") != "in_progress":
        raise RunError("a closed state cannot acquire an unprojected event tail")
    tail = events[-1]
    terminal_status = tail.get("terminal_status")
    if tail.get("phase") == "finished" and terminal_status not in STATUSES:
        raise RunError("finished tail lacks a recoverable terminal_status")
    if tail.get("phase") != "finished" and terminal_status is not None:
        raise RunError("non-finished tail cannot carry terminal_status")
    state.update(
        {
            "status": terminal_status or "in_progress",
            "updated_at": tail.get("timestamp"),
            "current_phase": tail.get("phase"),
            "events_count": len(events),
            "transient_retries_used": sum(
                event.get("kind") == "failure"
                and event.get("retry_class") == "transient"
                for event in events
            ),
            "last_summary": tail.get("summary"),
        }
    )
    _write_json_atomic(directory / "state.json", state)
    return state, True


def _command_show(args: argparse.Namespace) -> dict[str, Any]:
    run_id = _run_id(args.run_id)
    directory = _run_dir(args.root, run_id)
    with _exclusive_lock(directory):
        directory, task, state = _load_run(args.root, run_id)
        events = _read_events(directory / "events.jsonl")
        state, projection_repaired = _reconcile_state_projection(
            directory=directory,
            run_id=run_id,
            state=state,
            events=events,
            allow_one_event_tail=True,
        )
        return {
            "ok": True,
            "task": task,
            "state": state,
            "evidence": _read_json(directory / "evidence.json"),
            "events": events,
            "projection_repaired": projection_repaired,
        }


def _command_validate(args: argparse.Namespace) -> dict[str, Any]:
    payload = _command_show(args)
    run_id = payload["task"]["run_id"]
    events = payload["events"]
    state = payload["state"]
    if any(event.get("run_id") != run_id for event in events):
        raise RunError("an event has the wrong run_id")
    if int(state.get("events_count", -1)) != len(events):
        raise RunError("state events_count does not match events.jsonl")
    if state.get("status") == "verified":
        for criterion in payload["evidence"].get("criteria", []):
            if criterion.get("verdict") != "pass":
                raise RunError("verified run contains a non-passing criterion")
    return {
        "ok": True,
        "run_id": run_id,
        "events_count": len(events),
        "status": state["status"],
    }


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    subparsers = parser.add_subparsers(dest="command", required=True)

    init = subparsers.add_parser(
        "init", help="Create task.json, state.json, events.jsonl, evidence.json"
    )
    init.add_argument("--run-id")
    init.add_argument("--mode", choices=MODES, required=True)
    init.add_argument("--objective", required=True)
    init.add_argument("--risk", choices=RISKS, required=True)
    init.add_argument("--completion", action="append", default=[])
    init.add_argument("--read-root", action="append", default=[])
    init.add_argument("--write-root", action="append", default=[])
    init.add_argument("--external-effect", action="append", default=[])
    init.add_argument("--stop", action="append", default=[])
    init.add_argument("--max-agents", type=int, default=3)
    init.add_argument("--max-attempts", type=int, default=2)
    init.add_argument("--deadline-sec", type=int, default=1_800)
    init.add_argument("--actor", default="coordinator")
    init.set_defaults(handler=_command_init)

    event = subparsers.add_parser("event", help="Append one compact redacted run event")
    event.add_argument("--run-id", required=True)
    event.add_argument("--event-id")
    event.add_argument("--actor", required=True)
    event.add_argument("--kind", choices=EVENT_KINDS, required=True)
    event.add_argument("--phase", required=True)
    event.add_argument("--summary", required=True)
    event.add_argument("--evidence-ref", action="append", default=[])
    event.add_argument("--target")
    event.add_argument("--exit-code", type=int)
    event.add_argument("--duration-ms", type=int)
    event.add_argument("--retry-class", choices=RETRY_CLASSES, default="none")
    event.add_argument("--side-effect-id")
    event.add_argument("--expected-events-count", type=int)
    event.add_argument("--expected-events-sha256")
    event.set_defaults(handler=_command_event)

    verify = subparsers.add_parser(
        "verify", help="Record a terminal-state check for one criterion"
    )
    verify.add_argument("--run-id", required=True)
    verify.add_argument("--criterion", type=int, required=True)
    verify.add_argument("--verdict", choices=VERDICTS, required=True)
    verify.add_argument("--observed", required=True)
    verify.add_argument("--evidence-ref", action="append", default=[])
    verify.add_argument("--checker", default="verifier")
    verify.set_defaults(handler=_command_verify)

    finish = subparsers.add_parser(
        "finish", help="Close a run with a four-state outcome"
    )
    finish.add_argument("--run-id", required=True)
    finish.add_argument("--status", choices=STATUSES, required=True)
    finish.add_argument("--summary", required=True)
    finish.add_argument("--evidence-ref", action="append", default=[])
    finish.add_argument("--actor", default="coordinator")
    finish.set_defaults(handler=_command_finish)

    for name, help_text, handler in (
        ("show", "Print the complete compact run record", _command_show),
        ("validate", "Validate the four run files and event count", _command_validate),
    ):
        command = subparsers.add_parser(name, help=help_text)
        command.add_argument("--run-id", required=True)
        command.set_defaults(handler=handler)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = _parser()
    args = parser.parse_args(argv)
    if getattr(args, "max_agents", 1) < 1:
        parser.error("--max-agents must be positive")
    if getattr(args, "max_attempts", 0) < 0:
        parser.error("--max-attempts must be non-negative")
    if getattr(args, "deadline_sec", 1) < 1:
        parser.error("--deadline-sec must be positive")
    try:
        result = args.handler(args)
    except RunError as exc:
        print(
            json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False),
            file=sys.stderr,
        )
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
