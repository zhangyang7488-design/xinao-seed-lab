@echo off
setlocal
if not exist "%SystemRoot%\py.exe" (
  >&2 echo task_run launcher error: %SystemRoot%\py.exe is unavailable
  exit /b 127
)
"%SystemRoot%\py.exe" -3 "%~dp0task_run.py" %*
exit /b %errorlevel%
