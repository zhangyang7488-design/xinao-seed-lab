# Source patterns

Use this table to map mechanisms to Codex primitives. Do not install an entire framework when a
native primitive plus a thin adapter already covers the need.

| Source | Borrow | Bind to Codex | Avoid |
|---|---|---|---|
| [OpenHands](https://github.com/OpenHands/OpenHands) (MIT core) | atomic steps, append-only events, stuck detection | local run ledger + native tools | service/UI/runtime duplication |
| [mini-SWE-agent](https://github.com/SWE-agent/mini-swe-agent) (MIT) | simple loop, step/time limits, trajectories | bounded plan + compact evidence | raw thought storage, Bash-only shell |
| [LangGraph](https://github.com/langchain-ai/langgraph) (MIT) | checkpoints, fan-out/fan-in, idempotent resume | checkpoint + subagents + operation IDs | full graph runtime for ordinary work |
| [OpenAI Agents SDK](https://github.com/openai/openai-agents-python) (MIT) | manager/workers, HITL, guardrails, typed handoff | native subagents + scoped approvals | duplicate runner or cloud trace by default |
| [PydanticAI](https://github.com/pydantic/pydantic-ai) (MIT) | Dataset/Case/Evaluator, deterministic assertions | local eval fixtures and tests | orchestration backend stack |
| [AutoGen](https://github.com/microsoft/autogen) (MIT code) | termination conditions, candidate narrowing | explicit stop/budget | always-on group chat |
| [Aider](https://github.com/Aider-AI/aider) (Apache-2.0) | ask/code distinction, token-budgeted repo map | mode route + code graph top-K | auto commit or dirty-worktree commit |
| [Letta](https://github.com/letta-ai/letta) (Apache-2.0) | small core memory + searchable archive | checkpoint + scoped local Mem0 | another resident agent service |
| [Magentic-UI](https://github.com/microsoft/magentic-ui) (MIT) | plan visibility, interruption, takeover | commentary + HITL + computer/browser tools | duplicate desktop shell |
| [Playwright](https://github.com/microsoft/playwright) (Apache-2.0) | structured browser state and deterministic actions | Playwright skill / browser tools | coordinate-first visual control |

## Selection tests

Before adding a mechanism, answer:

1. Which verified current capability is missing?
2. Can a global instruction, skill, hook, memory field, native tool, or eval fill it?
3. Does it require a daemon, duplicate identity, cloud trace, or broad secret access?
4. Is the component maintained, permissively licensed, pinned, and locally testable?
5. What observable test proves the new mechanism helps rather than adds context and failure modes?

Reject additions that only rename planning, reflection, memory, or tool use without improving a
measured outcome.
