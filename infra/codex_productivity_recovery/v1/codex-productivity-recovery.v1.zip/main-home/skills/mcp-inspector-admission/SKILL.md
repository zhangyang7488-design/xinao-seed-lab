---
name: mcp-inspector-admission
description: Admit or reject an MCP server using the pinned MCP Inspector CLI, isolated startup, tools and resource discovery, a harmless real call, an error-path check, and post-exit residue checks. Use before adding or upgrading a local or remote MCP server, when configured-only MCP claims need behavioral evidence, or when an MCP regression must be reproduced without attaching to a user-owned live session.
---

# MCP Inspector admission

Use the pinned CLI at:

`D:\XINAO_RESEARCH_RUNTIME\tools\mcp-inspector\node_modules\.bin\mcp-inspector.cmd`

The admitted Inspector version is `0.22.0`. Read that version from `D:\XINAO_RESEARCH_RUNTIME\tools\mcp-inspector\node_modules\@modelcontextprotocol\inspector\package.json`. Never call `mcp-inspector --version`: version `0.22.0` has no version flag and interprets that token as a server command, which starts the UI/proxy path. Use explicit `--cli` mode only; do not start its browser UI or proxy as a resident service.

This integration is `partial`. Use it only for an explicitly requested, human-supervised, short-lived, secret-free local stdio canary. Do not use it for HTTP/SSE, authenticated endpoints, a shared live MCP process, or unattended execution. If the caller cannot enforce a bounded observation window and identify the exact spawned process tree for cleanup, do not run it.

## Admission workflow

1. Record the candidate server's exact executable, arguments, version or commit, license, package/lock/entrypoint hashes, required directories, and network endpoints. This partial integration forbids real secrets and authenticated remote admission.
2. Spawn a new isolated candidate process. Do not attach Inspector to an MCP process owned by a desktop or TUI session.
3. Run `tools/list`. If applicable, also run `resources/list`, `resources/templates/list`, and `prompts/list`. Compare the advertised surface with the intended narrow scope.
4. Call one harmless deterministic tool with explicit arguments. A successful handshake or tool list alone is not admission evidence.
5. Exercise one invalid tool name or invalid argument and require a bounded protocol error rather than a hang, crash storm, or external mutation. Inspect the JSON `isError` field and error content; Inspector `0.22.0` can return process exit code `0` for an MCP tool error.
6. Let Inspector and the candidate exit normally. Confirm no candidate/Inspector process, listener, window, task, service, launcher change, or hook remains.
7. Report the tested claim scope: exact candidate version/hash, transport, arguments, permissions, tool subset, success/error cases, and residue check. Mark only that scope `verified`, `partial`, `blocked`, or `unverified`; never infer whole-server or production readiness from one successful tool.

For a stdio server:

```powershell
$inspector = 'D:\XINAO_RESEARCH_RUNTIME\tools\mcp-inspector\node_modules\.bin\mcp-inspector.cmd'
& $inspector --cli <server-command> <server-args> --method tools/list
& $inspector --cli <server-command> <server-args> --method tools/call `
  --tool-name <safe-tool> --tool-arg key=value
```

Do not use `@latest`, a global npm install, a long-running Inspector UI, HTTP/SSE, headers, or authentication with this partial integration.

## Acceptance boundaries

- Discovery, a real call, the failure path, and exit cleanup are separate checks.
- A reference/demo MCP server is not production-ready merely because Inspector can call it.
- Reject duplicate filesystem, shell, browser, memory, or agent-runtime surfaces unless a measured gap outweighs the added owner, permission, and lifecycle cost.
- Do not enable hooks, auto-approval, startup persistence, dashboards, or shared HTTP transport as part of admission.
- Do not promote this Skill itself to `verified` until a fail-closed launcher supplies a hard timeout, rejects non-CLI/unknown top-level arguments, and guarantees exact child-tree convergence without a resident controller.
