---
name: ast-grep-structural-search
description: Use the pinned ast-grep CLI for AST-aware code search, pattern matching, and bounded structural rewrites. Trigger when plain text or regex search is too imprecise, when locating syntax-shaped code across a repository, or when a mechanical code transformation should preserve unrelated syntax.
---

# ast-grep structural search

Use the pinned executable at:

`D:\XINAO_RESEARCH_RUNTIME\tools\ast-grep\node_modules\.bin\sg.cmd`

## Search

1. Confirm `sg --version` reports `ast-grep 0.44.1`.
2. Prefer `rg` for ordinary text. Use ast-grep only when syntax structure matters.
3. Pass an explicit language and the narrowest path or glob.
4. Request JSON when another command or test will consume the matches.

Example:

```powershell
& 'D:\XINAO_RESEARCH_RUNTIME\tools\ast-grep\node_modules\.bin\sg.cmd' run `
  --lang python --pattern 'print($A)' --json=compact .
```

## Rewrite

1. Run the pattern as a read-only search first and inspect every match.
2. Preserve the user's dirty worktree. Use an isolated worktree or disposable copy for broad rewrites.
3. Preview with `--rewrite`; add `--update-all` only after the match set is correct and the requested scope authorizes edits.
4. Inspect the real diff and run the repository's formatter, tests, and relevant negative checks.
5. Report the exact command, match count, changed files, and test evidence.

Never replace semantic review with a successful exit code. Do not install a floating `latest` version when this pinned executable is missing; report the missing capability or repair it through the existing pinned package root.
