# Codex Situation Island（薄连续性与事故证据）

本目录不是任务 Owner、科学入口、研究平台、上下文目录或第二控制面。

唯一活动启动器官是：

- `scripts/session_start_continuity_pointer_v1.ps1`：只在 fresh SessionStart 提醒“把当前口语增量放回仍存活父帧；成熟工程只补手段；高杠杆收敛与过渡须做有界同构闭包；确实继续未完成新澳时才读 C 薄入口与 native STATUS”；缺失或冲突时 fail-open，不选择任务、科学问题、路线、Goal、工人或完成状态，也不在普通回合展开整套个人模型。

其余可保留对象只有两类：

- `state/` 中仍有真实消费者的有界运行/恢复事实；这些事实只减少重复定位和技术运维负担，不产生授权或任务。
- `runs/` 与 `contracts/` 中的事故、来源和冷证据；只有当前任务明确命中时按需读取，不自动加载。

旧 `session_start_context`、compact frontier、predecision 注入、context catalog、core index 与 maintenance map 已从活动面移除。它们的完整 preimage 位于：

`E:\XINAO_COLD_STORAGE\xinao-global-clean-preimage-20260803-v1\situation-island-preclean.tar`

当前 Hook 的唯一真边界是 `C:\Users\xx363\.codex\hooks.json` 与 Codex fresh-process 的实际 `hooks/list` / SessionStart 行为；本目录中的历史报告和测试不得反向恢复旧 Hook。
