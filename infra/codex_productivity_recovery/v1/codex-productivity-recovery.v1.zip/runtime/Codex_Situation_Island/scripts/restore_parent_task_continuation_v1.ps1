#Requires -Version 5.1

[CmdletBinding()]
param(
    [string]$SessionId = $env:CODEX_THREAD_ID,
    [string]$StateRoot = $env:CODEX_ACTIVE_TASK_STATE_ROOT
)

$ErrorActionPreference = 'Stop'
$utf8 = [Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8
if ([string]::IsNullOrWhiteSpace($StateRoot)) {
    $StateRoot = 'D:\XINAO_RESEARCH_RUNTIME\state\codex\active-task-continuation'
}
if ($SessionId -notmatch '^[A-Za-z0-9._-]{1,128}$') {
    throw 'ACTIVE_TASK_SESSION_ID_INVALID'
}
$sessionRoot = Join-Path ([IO.Path]::GetFullPath($StateRoot)) $SessionId
$target = Join-Path $sessionRoot 'active_task_continuation.v1.json'
if (-not (Test-Path -LiteralPath $target -PathType Leaf)) {
    throw 'ACTIVE_TASK_CHILD_BINDING_MISSING'
}
$child = Get-Content -LiteralPath $target -Raw -Encoding UTF8 |
    ConvertFrom-Json -Depth 15 -ErrorAction Stop
$ref = $child.parent_binding_ref
if ($null -eq $ref -or [string]::IsNullOrWhiteSpace([string]$ref.path)) {
    throw 'ACTIVE_TASK_PARENT_BINDING_REF_MISSING'
}
$historyRoot = [IO.Path]::GetFullPath((Join-Path $sessionRoot 'bindings')).TrimEnd('\')
$parentPath = [IO.Path]::GetFullPath([string]$ref.path)
if (-not $parentPath.StartsWith($historyRoot + '\', [StringComparison]::OrdinalIgnoreCase) -or
    -not (Test-Path -LiteralPath $parentPath -PathType Leaf)) {
    throw 'ACTIVE_TASK_PARENT_BINDING_REF_UNSAFE'
}
$observedSha256 = (Get-FileHash -LiteralPath $parentPath -Algorithm SHA256).Hash.ToLowerInvariant()
if (-not [string]::Equals($observedSha256, [string]$ref.sha256, [StringComparison]::Ordinal)) {
    throw 'ACTIVE_TASK_PARENT_BINDING_HASH_MISMATCH'
}
$parent = Get-Content -LiteralPath $parentPath -Raw -Encoding UTF8 |
    ConvertFrom-Json -Depth 15 -ErrorAction Stop
if ([string]$parent.schema_version -cne 'xinao.active_task_continuation.v1' -or
    [string]$parent.session_id -cne $SessionId -or
    [string]$parent.task_id -cne [string]$child.parent_task_id -or
    [string]$parent.task_id -cne [string]$child.continuation.return_task_id) {
    throw 'ACTIVE_TASK_PARENT_BINDING_LINEAGE_MISMATCH'
}
$parent | Add-Member -NotePropertyName restored_from_child_task_id -NotePropertyValue ([string]$child.task_id) -Force
$parent | Add-Member -NotePropertyName restored_at -NotePropertyValue ([DateTimeOffset]::Now.ToString('o')) -Force
$temp = Join-Path $sessionRoot ('.active_task_continuation.restore.' + [guid]::NewGuid().ToString('N') + '.tmp')
[IO.File]::WriteAllText($temp, ($parent | ConvertTo-Json -Depth 15), $utf8)
Move-Item -LiteralPath $temp -Destination $target -Force
[Console]::WriteLine((([ordered]@{
    status = 'parent_restored'
    task_id = [string]$parent.task_id
    restored_from_child_task_id = [string]$child.task_id
    path = $target
}) | ConvertTo-Json -Compress))
