#Requires -Version 5.1

$ErrorActionPreference = 'Stop'
$utf8 = [Text.UTF8Encoding]::new($false)
[Console]::InputEncoding = $utf8
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8

function Write-Allow {
    [Console]::WriteLine('{"continue":true}')
}

function Get-BoundedReasonText {
    param(
        [object]$Value,
        [int]$MaxChars = 240
    )
    $text = ([string]$Value -replace '\s+', ' ').Trim()
    if ($text.Length -gt $MaxChars) {
        return $text.Substring(0, $MaxChars) + '...'
    }
    return $text
}

try {
    $raw = [Console]::In.ReadToEnd()
    $event = $raw | ConvertFrom-Json
    if ($event.hook_event_name -ne 'Stop' -or [bool]$event.stop_hook_active) {
        Write-Allow
        exit 0
    }

    $transcript = [string]$event.transcript_path
    if ([string]::IsNullOrWhiteSpace($transcript) -or -not (Test-Path -LiteralPath $transcript -PathType Leaf)) {
        Write-Allow
        exit 0
    }

    $resolvedTranscript = [IO.Path]::GetFullPath($transcript)
    $allowedRoots = @(
        [IO.Path]::GetFullPath('C:\Users\xx363\.codex\sessions'),
        [IO.Path]::GetFullPath('C:\Users\xx363\.codex-s-hardmode-account-b\sessions')
    )
    $testSessionRoot = [Environment]::GetEnvironmentVariable('CODEX_HOOK_TEST_SESSION_ROOT')
    if (-not [string]::IsNullOrWhiteSpace($testSessionRoot)) {
        $allowedRoots += [IO.Path]::GetFullPath($testSessionRoot)
    }
    $insideKnownSessionRoot = $false
    foreach ($root in $allowedRoots) {
        if ($resolvedTranscript.StartsWith($root + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
            $insideKnownSessionRoot = $true
            break
        }
    }
    if (-not $insideKnownSessionRoot -or [IO.Path]::GetExtension($resolvedTranscript) -ne '.jsonl') {
        Write-Allow
        exit 0
    }

    $latestPlanInput = $null
    $latestPlanAt = $null
    $latestUserAt = $null
    foreach ($line in Get-Content -LiteralPath $resolvedTranscript -Tail 1200 -Encoding UTF8) {
        try {
            $row = $line | ConvertFrom-Json -Depth 20
            if ($row.type -ne 'response_item') {
                continue
            }
            if ($row.payload.type -eq 'message' -and [string]$row.payload.role -ceq 'user') {
                try { $latestUserAt = [DateTimeOffset]::Parse([string]$row.timestamp) } catch {
                    $latestUserAt = $null
                }
                continue
            }
            if ($row.payload.type -ne 'custom_tool_call' -or
                $line.IndexOf('update_plan', [StringComparison]::OrdinalIgnoreCase) -lt 0) {
                continue
            }
            $name = [string]$row.payload.name
            $inputText = [string]$row.payload.input
            if ($name -eq 'update_plan' -or $inputText -match '(?s)\btools\.update_plan\s*\(') {
                $latestPlanInput = $inputText
                try { $latestPlanAt = [DateTimeOffset]::Parse([string]$row.timestamp) } catch {
                    $latestPlanAt = $null
                }
            }
        } catch {
            continue
        }
    }

    if ([string]::IsNullOrWhiteSpace($latestPlanInput)) {
        Write-Allow
        exit 0
    }

    $hasOpenParentWork = $latestPlanInput -match '(?i)["'']?status["'']?\s*:\s*["''](?:pending|in_progress)["'']'
    if (-not $hasOpenParentWork) {
        Write-Allow
        exit 0
    }

    # A plan label is not a parent frame. Only a named active continuation can
    # support a finalization block, and a plan older than the latest user
    # increment is stale evidence rather than a live return point.
    if ($null -eq $latestPlanAt -or $null -eq $latestUserAt -or $latestPlanAt -lt $latestUserAt) {
        Write-Allow
        exit 0
    }
    $activeBinding = $null
    try {
        $sessionId = [string]$event.session_id
        if ($sessionId -match '^[A-Za-z0-9._-]{1,128}$') {
            $stateRoot = [Environment]::GetEnvironmentVariable('CODEX_ACTIVE_TASK_STATE_ROOT')
            if ([string]::IsNullOrWhiteSpace($stateRoot)) {
                $stateRoot = 'D:\XINAO_RESEARCH_RUNTIME\state\codex\active-task-continuation'
            }
            $manifestPath = Join-Path (Join-Path ([IO.Path]::GetFullPath($stateRoot)) $sessionId) 'active_task_continuation.v1.json'
            if (Test-Path -LiteralPath $manifestPath -PathType Leaf) {
                $candidate = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 |
                    ConvertFrom-Json -Depth 15 -ErrorAction Stop
                if ([string]$candidate.schema_version -ceq 'xinao.active_task_continuation.v1' -and
                    [string]$candidate.session_id -ceq $sessionId -and
                    [string]$candidate.stop_state -ceq 'active' -and
                    -not [string]::IsNullOrWhiteSpace([string]$candidate.task_id) -and
                    -not [string]::IsNullOrWhiteSpace([string]$candidate.scope) -and
                    -not [string]::IsNullOrWhiteSpace([string]$candidate.completion_condition)) {
                    $activeBinding = $candidate
                }
            }
        }
    } catch { $activeBinding = $null }
    if ($null -eq $activeBinding) {
        Write-Allow
        exit 0
    }

    $taskId = Get-BoundedReasonText -Value $activeBinding.task_id -MaxChars 128
    $scope = Get-BoundedReasonText -Value $activeBinding.scope -MaxChars 240
    $completion = Get-BoundedReasonText -Value $activeBinding.completion_condition -MaxChars 240
    $reason = "具名活动绑定仍为 active，且本轮用户增量之后写入的计划仍有开放项：task=$taskId; scope=$scope; completion=$completion。仅据这一个精确对象复核是否存在明确 Pause/Stop、真实用户关口、已证阻塞或父结果验收；若都不存在，继续它的合法机器前沿。不得从计划标签复活别的任务，也不得要求用户重说继续。"
    $payload = [ordered]@{
        decision = 'block'
        reason = $reason
    }

    if ([string]::IsNullOrWhiteSpace($testSessionRoot)) {
        try {
            $logRoot = 'D:\XINAO_RESEARCH_RUNTIME\state\codex\intent-action-baseline'
            New-Item -ItemType Directory -Path $logRoot -Force | Out-Null
            $receipt = [ordered]@{
                observed_at = [DateTimeOffset]::Now.ToString('o')
                event = 'stop_gate_blocked_once'
                session_id = [string]$event.session_id
                turn_id = [string]$event.turn_id
                transcript_path = $resolvedTranscript
                basis = 'named active binding plus a post-user update_plan with open work'
                task_id = $taskId
                scope = $scope
            }
            Add-Content -LiteralPath (Join-Path $logRoot 'stop_gate_events.jsonl') -Value ($receipt | ConvertTo-Json -Compress) -Encoding UTF8
        } catch {
            # Telemetry is non-authoritative and must never turn a safe recheck into a hard failure.
        }
    }

    [Console]::WriteLine(($payload | ConvertTo-Json -Depth 4 -Compress))
} catch {
    Write-Allow
}
exit 0
