#Requires -Version 5.1

[CmdletBinding()]
param(
    [string]$SessionId = $env:CODEX_THREAD_ID,
    [Parameter(Mandatory = $true)][ValidatePattern('^[A-Za-z0-9._:-]{1,160}$')][string]$TaskId,
    [string]$ParentTaskId = '',
    [Parameter(Mandatory = $true)][ValidateSet('DISCUSS','ANALYZE','DESIGN','EXECUTE','VALIDATE','PAUSED')][string]$ActiveMode,
    [Parameter(Mandatory = $true)][ValidateSet('current_user_turn','surviving_parent')][string]$TaskSource,
    [Parameter(Mandatory = $true)][ValidateSet('same_parent_increment','new_parent','correction','pause','resume')][string]$UserTurnRelation,
    [Parameter(Mandatory = $true)][string[]]$BoundRoots,
    [Parameter(Mandatory = $true)][ValidateSet('read_only','file_write','configuration','local_process','worker_dispatch','test_execution','runtime_state','repository_write')][string[]]$AllowedEffects,
    [Parameter(Mandatory = $true)][string]$Scope,
    [Parameter(Mandatory = $true)][string]$CompletionCondition,
    [ValidateSet('exact','none')][string]$ContinuationStatus = 'none',
    [string]$ReturnTaskId = '',
    [string]$ReturnRepository = '',
    [string]$ReturnPoint = '',
    [ValidateSet('DISCUSS','ANALYZE','DESIGN','EXECUTE','VALIDATE','PAUSED')][string]$ReturnMode = 'ANALYZE',
    [string]$StateRoot = $env:CODEX_ACTIVE_TASK_STATE_ROOT
)

$ErrorActionPreference = 'Stop'
$utf8 = [Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8

if ([string]::IsNullOrWhiteSpace($StateRoot)) {
    $StateRoot = 'D:\XINAO_RESEARCH_RUNTIME\state\codex\active-task-continuation'
}
if ($SessionId -notmatch '^[A-Za-z0-9._-]{1,128}$') {
    throw 'ACTIVE_TASK_SESSION_ID_INVALID'
}
if ($BoundRoots.Count -eq 0) { throw 'ACTIVE_TASK_BOUND_ROOT_REQUIRED' }
if ($AllowedEffects.Count -eq 0) { throw 'ACTIVE_TASK_ALLOWED_EFFECT_REQUIRED' }
if ($ContinuationStatus -eq 'exact' -and (
    [string]::IsNullOrWhiteSpace($ReturnTaskId) -or
    [string]::IsNullOrWhiteSpace($ReturnPoint)
)) {
    throw 'ACTIVE_TASK_EXACT_CONTINUATION_INCOMPLETE'
}

$sessionRoot = Join-Path ([IO.Path]::GetFullPath($StateRoot)) $SessionId
$seedPath = Join-Path $sessionRoot 'latest_user_increment.v1.json'
if (-not (Test-Path -LiteralPath $seedPath -PathType Leaf)) {
    throw 'ACTIVE_TASK_USER_INCREMENT_SEED_MISSING'
}
$seed = Get-Content -LiteralPath $seedPath -Raw -Encoding UTF8 | ConvertFrom-Json -Depth 10
if ([string]$seed.schema_version -cne 'xinao.user_task_increment_seed.v1' -or
    [string]$seed.session_id -cne $SessionId -or
    [string]::IsNullOrWhiteSpace([string]$seed.prompt_sha256)) {
    throw 'ACTIVE_TASK_USER_INCREMENT_SEED_INVALID'
}

$target = Join-Path $sessionRoot 'active_task_continuation.v1.json'
$existing = $null
if (Test-Path -LiteralPath $target -PathType Leaf) {
    try {
        $existing = Get-Content -LiteralPath $target -Raw -Encoding UTF8 |
            ConvertFrom-Json -Depth 15 -ErrorAction Stop
        if ([string]$existing.schema_version -cne 'xinao.active_task_continuation.v1' -or
            [string]$existing.session_id -cne $SessionId) {
            throw 'ACTIVE_TASK_EXISTING_BINDING_INVALID'
        }
    } catch { throw 'ACTIVE_TASK_EXISTING_BINDING_INVALID' }
}
$isChild = $false
if ($TaskSource -eq 'surviving_parent') {
    if ($null -eq $existing) {
        throw 'ACTIVE_TASK_SURVIVING_PARENT_MISSING'
    }
    $sameTask = [string]$existing.task_id -ceq $TaskId
    $isChild = (-not $sameTask -and [string]$existing.task_id -ceq $ParentTaskId)
    if (-not $sameTask -and -not $isChild) {
        throw 'ACTIVE_TASK_SURVIVING_PARENT_LINEAGE_MISMATCH'
    }
    if ($isChild -and (
        $ContinuationStatus -ne 'exact' -or
        [string]$ReturnTaskId -cne [string]$existing.task_id
    )) {
        throw 'ACTIVE_TASK_CHILD_REQUIRES_EXACT_PARENT_RETURN'
    }
}

$normalizedRoots = @(
    foreach ($root in $BoundRoots) {
        if ([string]::IsNullOrWhiteSpace($root)) { continue }
        $full = [IO.Path]::GetFullPath($root).TrimEnd('\')
        if (-not (Test-Path -LiteralPath $full)) {
            throw "ACTIVE_TASK_BOUND_ROOT_MISSING: $full"
        }
        $full
    }
)
$normalizedRoots = @($normalizedRoots | Sort-Object -Unique)
if ($normalizedRoots.Count -eq 0) { throw 'ACTIVE_TASK_BOUND_ROOT_REQUIRED' }

$parentBindingRef = $null
if ($isChild) {
    $historyRoot = Join-Path $sessionRoot 'bindings'
    New-Item -ItemType Directory -Path $historyRoot -Force | Out-Null
    $existingJson = $existing | ConvertTo-Json -Depth 15
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try {
        $existingSha256 = ([BitConverter]::ToString(
            $algorithm.ComputeHash($utf8.GetBytes($existingJson))
        )).Replace('-', '').ToLowerInvariant()
    } finally { $algorithm.Dispose() }
    $existingBindingId = if (
        [string]$existing.binding_id -match '^atc_[0-9a-f]{32}$'
    ) { [string]$existing.binding_id } else { 'atc_' + $existingSha256.Substring(0, 32) }
    $historyPath = Join-Path $historyRoot ($existingBindingId + '.json')
    if (-not (Test-Path -LiteralPath $historyPath -PathType Leaf)) {
        [IO.File]::WriteAllText($historyPath, $existingJson, $utf8)
    }
    $parentBindingRef = [ordered]@{
        binding_id = $existingBindingId
        task_id = [string]$existing.task_id
        path = $historyPath
        sha256 = $existingSha256
    }
}
elseif ($null -ne $existing -and
    [string]$existing.task_id -ceq $TaskId -and
    $null -ne $existing.parent_binding_ref) {
    $parentBindingRef = $existing.parent_binding_ref
}

$manifest = [ordered]@{
    schema_version = 'xinao.active_task_continuation.v1'
    binding_id = 'atc_' + [guid]::NewGuid().ToString('N')
    authority = 'current_user_turn_plus_surviving_parent_plus_live_facts'
    session_id = $SessionId
    task_id = $TaskId
    parent_task_id = $ParentTaskId
    task_source = $TaskSource
    authorizing_user_turn = [string]$seed.turn_id
    source_prompt_sha256 = [string]$seed.prompt_sha256
    user_turn_relation = $UserTurnRelation
    active_mode = $ActiveMode
    bound_roots = $normalizedRoots
    allowed_effects = @($AllowedEffects | Sort-Object -Unique)
    scope = $Scope
    completion_condition = $CompletionCondition
    continuation = [ordered]@{
        status = $ContinuationStatus
        return_task_id = $ReturnTaskId
        return_repository = $ReturnRepository
        return_point = $ReturnPoint
        return_mode = $ReturnMode
    }
    parent_binding_ref = $parentBindingRef
    stop_state = if ($ActiveMode -eq 'PAUSED') { 'paused' } else { 'active' }
    superseded_by = $null
    observed_cwd = [string]$seed.cwd
    bound_at = [DateTimeOffset]::Now.ToString('o')
}

$temp = Join-Path $sessionRoot ('.active_task_continuation.' + [guid]::NewGuid().ToString('N') + '.tmp')
[IO.File]::WriteAllText($temp, ($manifest | ConvertTo-Json -Depth 8), $utf8)
Move-Item -LiteralPath $temp -Destination $target -Force

[Console]::WriteLine((([ordered]@{
    status = 'bound'
    task_id = $TaskId
    active_mode = $ActiveMode
    continuation_status = $ContinuationStatus
    binding_relation = if ($isChild) { 'child_of_surviving_parent' } elseif ($null -ne $existing) { 'updated_or_superseded' } else { 'initial' }
    path = $target
}) | ConvertTo-Json -Compress))
