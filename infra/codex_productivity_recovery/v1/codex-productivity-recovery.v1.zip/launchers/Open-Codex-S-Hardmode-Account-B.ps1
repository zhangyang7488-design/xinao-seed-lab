﻿# Codex S Hardmode twin - Account B (Windows PowerShell 5.1+)
# Codex S Hardmode twin - Account B (blank spare for new Codex login)
# Workdir=S; L0/AGENTS/skills follow main .codex; auth isolated (never copied from main).
$ErrorActionPreference = "Stop"
$Host.UI.RawUI.WindowTitle = "Codex S Hardmode - Account B"

$mandatoryLevel = & whoami.exe /groups | Select-String -Pattern "S-1-16-(12288|16384)"
if (-not $mandatoryLevel) {
    throw "WINDOWS_ELEVATION_REQUIRED: use OPEN CODEX S HARDMODE Account B.lnk"
}

$mainCodexHome = "C:\Users\xx363\.codex"
$codexHome = "C:\Users\xx363\.codex-s-hardmode-account-b"
$workdir = "E:\XINAO_RESEARCH_WORKSPACES\S"
$runtime = "D:\XINAO_RESEARCH_RUNTIME"
$powerShellHome = "D:\XINAO_RESEARCH_RUNTIME\tools\powershell\7.6.4"
$powerShellExe = Join-Path $powerShellHome "pwsh.exe"
$expectedPowerShellSha256 = "DB6DD81183FE57D22E03B911EC9A30A2FD7C40542E97743615355A6FB44F458F"
$slotReadme = Join-Path $codexHome "ACCOUNT_SLOT_README.txt"

function Write-Info([string]$Msg, [string]$Color = "Gray") {
    Write-Host $Msg -ForegroundColor $Color
}

function Write-Utf8Bom([string]$Path, [string]$Content) {
    $enc = New-Object System.Text.UTF8Encoding $true
    [System.IO.File]::WriteAllText($Path, $Content, $enc)
}

function Ensure-Junction([string]$Link, [string]$Target) {
    if (-not (Test-Path -LiteralPath $Target)) { return }
    if (Test-Path -LiteralPath $Link) {
        $item = Get-Item -LiteralPath $Link -Force
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { return }
        return
    }
    $parent = Split-Path -Parent $Link
    if (-not (Test-Path -LiteralPath $parent)) {
        New-Item -ItemType Directory -Force -Path $parent | Out-Null
    }
    cmd /c "mklink /J `"$Link`" `"$Target`"" | Out-Null
}

function Sync-SharedL0FromMain {
    foreach ($name in @("skills", "agents", "rules", "plugins")) {
        Ensure-Junction (Join-Path $codexHome $name) (Join-Path $mainCodexHome $name)
    }
    $mainAgents = Join-Path $mainCodexHome "AGENTS.md"
    if (Test-Path -LiteralPath $mainAgents) {
        Copy-Item -LiteralPath $mainAgents -Destination (Join-Path $codexHome "AGENTS.md") -Force
    }
    foreach ($extra in @("hooks.json", "cold-capabilities.config.toml", "inner-luna.config.toml", "inner-terra.config.toml", "inner-sol-verifier.config.toml")) {
        $src = Join-Path $mainCodexHome $extra
        if (Test-Path -LiteralPath $src) {
            Copy-Item -LiteralPath $src -Destination (Join-Path $codexHome $extra) -Force
        }
    }
}

function Sync-ConfigFromMainKeepAuth {
    $mainCfg = Join-Path $mainCodexHome "config.toml"
    if (-not (Test-Path -LiteralPath $mainCfg)) {
        throw "CODEX_S_CONFIG_MISSING: $mainCfg"
    }
    $slotCfg = Join-Path $codexHome "config.toml"
    Copy-Item -LiteralPath $mainCfg -Destination $slotCfg -Force

    # Account B shares the main capability/config shape, but any nested Codex or
    # Node REPL consumer must still resolve the B home. Otherwise a retained
    # browser/code-mode capability can silently cross the auth/session boundary.
    $slotConfigText = [System.IO.File]::ReadAllText($slotCfg)
    $slotConfigText = $slotConfigText.Replace(
        "NODE_REPL_TRUSTED_CODE_PATHS = '$mainCodexHome'",
        "NODE_REPL_TRUSTED_CODE_PATHS = '$codexHome'"
    )
    $slotConfigText = $slotConfigText.Replace(
        "CODEX_HOME = '$mainCodexHome'",
        "CODEX_HOME = '$codexHome'"
    )
    Write-Utf8Bom $slotCfg $slotConfigText

    $readme = @"
ACCOUNT SLOT B - Codex S Hardmode twin (blank spare)
====================================================
Purpose: same S workdir + same L0/AGENTS/skills as main Hardmode.
Isolation: CODEX_HOME=$codexHome
Auth: this folder auth.json only - NOT shared with:
  - C:\Users\xx363\.codex
  - C:\Users\xx363\.codex-s-hardmode-deepseek-v4flash
  - C:\Users\xx363\.codex-deepseek-v4pro

Tomorrow: open this window and log in with the new Codex account.
Synced each launch from main: config.toml, AGENTS.md, skills/agents/rules/plugins junctions.
The copied config is rewritten only for B-local CODEX_HOME / Node REPL trusted paths.
Not synced: auth.json, sessions.
"@
    Write-Utf8Bom $slotReadme $readme
}

function Resolve-CodexCommand {
    $c = Get-Command codex.cmd -ErrorAction SilentlyContinue
    if ($c) { return $c }
    $c = Get-Command codex -ErrorAction SilentlyContinue
    if ($c) { return $c }
    $bundled = "C:\Users\xx363\AppData\Roaming\npm\node_modules\@openai\codex\node_modules\@openai\codex-win32-x64\vendor\x86_64-pc-windows-msvc\bin\codex.exe"
    if (Test-Path -LiteralPath $bundled) {
        return [pscustomobject]@{ Source = $bundled }
    }
    throw "CODEX_COMMAND_NOT_FOUND"
}

foreach ($path in @($mainCodexHome, $workdir, $runtime, $powerShellHome)) {
    if (-not (Test-Path -LiteralPath $path -PathType Container)) {
        throw "CODEX_S_REQUIRED_PATH_MISSING: $path"
    }
}
if (-not (Test-Path -LiteralPath $powerShellExe -PathType Leaf)) {
    throw "CODEX_S_POWERSHELL_MISSING: $powerShellExe"
}
if ((Get-FileHash -LiteralPath $powerShellExe -Algorithm SHA256).Hash -ne $expectedPowerShellSha256) {
    throw "CODEX_S_POWERSHELL_HASH_MISMATCH"
}
$pathTail = @($env:Path -split ';' | Where-Object { $_ -and $_ -ine $powerShellHome })
$env:Path = (@($powerShellHome) + $pathTail) -join ';'

New-Item -ItemType Directory -Force -Path $codexHome | Out-Null

# Isolation: never write main Hardmode or V4pro homes
$forbiddenWriteRoots = @($mainCodexHome, "C:\Users\xx363\.codex-deepseek-v4pro", "C:\Users\xx363\.codex-s-hardmode-deepseek-v4flash")
function Assert-NotForbiddenWrite([string]$Path) {
    $full = [IO.Path]::GetFullPath($Path)
    foreach ($root in $forbiddenWriteRoots) {
        $r = [IO.Path]::GetFullPath($root)
        if ($full.Equals($r, [StringComparison]::OrdinalIgnoreCase) -or $full.StartsWith($r.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) {
            throw "ISOLATION_VIOLATION_WRITE_OTHER_SLOT: $full"
        }
    }
}
Write-Info "ISOLATION: writes only under $codexHome. Main .codex is read-only for this app." "DarkCyan"
Assert-NotForbiddenWrite $codexHome

Sync-SharedL0FromMain
Sync-ConfigFromMainKeepAuth

foreach ($name in @(
    "XINAO_CANONICAL_REPO", "XINAO_BLUEPRINT_REPO", "XINAO_LEGACY_BLUEPRINT_REPO",
    "XINAO_COMPAT_RUNTIME", "XINAO_COMPAT_RUNTIME_ROOT",
    "XINAO_CODEX_SITUATION_ISLAND", "XINAO_CODEX_SITUATION_REF",
    "XINAO_CODEX_CAPABILITY_REF", "XINAO_CODEX_MATURE_CAPABILITY_CATALOG_REF",
    "XINAO_DUAL_BRAIN_TURN_DRAIN", "XINAO_COORD_ROLE", "AM_ME", "AM_ROOT",
    "XINAO_INGRESS_BASE_URL", "XINAO_ROUTE_PROFILE",
    "OPENAI_BASE_URL", "OPENAI_API_BASE", "OPENAI_MODEL",
    "CODEX_MODEL", "CODEX_API_BASE_URL", "CODEX_MODEL_PROVIDER",
    "DEEPSEEK_API_KEY", "CODEX_BRIDGE_PROXY_KEY", "PROXY_AUTH_KEY"
)) {
    Remove-Item -LiteralPath "Env:\$name" -ErrorAction SilentlyContinue
}

$env:CODEX_HOME = $codexHome
$env:XINAO_REPO = $workdir
$env:XINAO_RUNTIME = $runtime
$env:XINAO_HARDMODE = "S_HARDMODE_TWIN_ACCOUNT_B"
$env:XINAO_ACCOUNT_SLOT = "account-b-spare"

if ([Console]::IsInputRedirected -or [Console]::IsOutputRedirected) {
    throw "CODEX_S_INTERACTIVE_TERMINAL_REQUIRED"
}

$authPath = Join-Path $codexHome "auth.json"
$hasAuth = Test-Path -LiteralPath $authPath

Write-Host "CODEX S | Hardmode twin | Account B (spare)" -ForegroundColor Cyan
Write-Host "CODEX_HOME=$codexHome"
Write-Host "WORKDIR=$workdir  (S + main L0 linked)"
Write-Host "AUTH=$(if ($hasAuth) { 'present (this slot only)' } else { 'EMPTY - login new Codex account here' })"
Write-Host "MAIN_L0_SOURCE=$mainCodexHome\AGENTS.md"
Write-Host "NOTE: auth.json is never copied from main Hardmode."
Write-Host ""

Set-Location -LiteralPath $workdir
$codexCommand = Resolve-CodexCommand
& $codexCommand.Source --cd $workdir --dangerously-bypass-approvals-and-sandbox

$exitCode = $LASTEXITCODE
if ($null -eq $exitCode) { $exitCode = 0 }
if ($exitCode -ne 0) {
    Write-Info "exit=$exitCode" "Yellow"
    if (-not $hasAuth) {
        Write-Info "If login is required: complete new Codex login in THIS window only." "Yellow"
    }
    Read-Host "Press Enter to close"
    exit $exitCode
}
