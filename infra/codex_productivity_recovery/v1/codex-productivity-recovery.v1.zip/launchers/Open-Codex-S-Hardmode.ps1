﻿$ErrorActionPreference = "Stop"

$mandatoryLevel = & whoami.exe /groups | Select-String -Pattern "S-1-16-(12288|16384)"
if (-not $mandatoryLevel) {
    throw "WINDOWS_ELEVATION_REQUIRED: launch with OPEN CODEX S HARDMODE.lnk"
}

$codexHome = "C:\Users\xx363\.codex"
$workdir = "E:\XINAO_RESEARCH_WORKSPACES\S"
$runtime = "D:\XINAO_RESEARCH_RUNTIME"
$powerShellHome = "D:\XINAO_RESEARCH_RUNTIME\tools\powershell\7.6.4"
$powerShellExe = Join-Path $powerShellHome "pwsh.exe"
$expectedPowerShellSha256 = "DB6DD81183FE57D22E03B911EC9A30A2FD7C40542E97743615355A6FB44F458F"

foreach ($path in @($codexHome, $workdir, $runtime, $powerShellHome)) {
    if (-not (Test-Path -LiteralPath $path -PathType Container)) {
        throw "CODEX_S_REQUIRED_PATH_MISSING: $path"
    }
}
if (-not (Test-Path -LiteralPath $powerShellExe -PathType Leaf)) {
    throw "CODEX_S_POWERSHELL_MISSING: $powerShellExe"
}
if ((Get-FileHash -LiteralPath $powerShellExe -Algorithm SHA256).Hash -ne $expectedPowerShellSha256) {
    throw "CODEX_S_POWERSHELL_HASH_MISMATCH"
}
$pathTail = @($env:Path -split ';' | Where-Object { $_ -and $_ -ine $powerShellHome })
$env:Path = (@($powerShellHome) + $pathTail) -join ';'

$configPath = Join-Path $codexHome "config.toml"
if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) {
    throw "CODEX_S_CONFIG_MISSING: $configPath"
}

$env:CODEX_HOME = $codexHome
$env:XINAO_REPO = $workdir
$env:XINAO_RUNTIME = $runtime

# Remove inherited legacy identity, retired coordination, compatibility, and
# provider overrides.  The launcher starts Codex; it does not restore a
# scientific route, checkpoint, queue, or second-owner identity.
foreach ($name in @(
    "XINAO_CANONICAL_REPO",
    "XINAO_BLUEPRINT_REPO",
    "XINAO_LEGACY_BLUEPRINT_REPO",
    "XINAO_COMPAT_RUNTIME",
    "XINAO_COMPAT_RUNTIME_ROOT",
    "XINAO_CODEX_SITUATION_ISLAND",
    "XINAO_CODEX_SITUATION_REF",
    "XINAO_CODEX_CAPABILITY_REF",
    "XINAO_CODEX_MATURE_CAPABILITY_CATALOG_REF",
    "XINAO_DUAL_BRAIN_TURN_DRAIN",
    "XINAO_COORD_ROLE",
    "AM_ME",
    "AM_ROOT",
    "XINAO_INGRESS_BASE_URL",
    "XINAO_ROUTE_PROFILE",
    "XINAO_HARDMODE",
    "OPENAI_BASE_URL",
    "OPENAI_API_BASE",
    "OPENAI_MODEL",
    "CODEX_MODEL",
    "CODEX_API_BASE_URL",
    "CODEX_MODEL_PROVIDER"
)) {
    Remove-Item -LiteralPath "Env:\$name" -ErrorAction SilentlyContinue
}

$codexCommand = Get-Command codex.cmd -ErrorAction SilentlyContinue
if (-not $codexCommand) {
    $codexCommand = Get-Command codex -ErrorAction SilentlyContinue
}
if (-not $codexCommand) {
    throw "CODEX_COMMAND_NOT_FOUND"
}

Set-Location -LiteralPath $workdir

$configuredModel = "default"
$modelLine = Select-String -LiteralPath $configPath -Pattern '^\s*model\s*=' | Select-Object -First 1
if ($modelLine) {
    $configuredModel = ($modelLine.Line -split '=', 2)[1].Trim().Trim('"')
}

Write-Host "CODEX S · direct clean launch" -ForegroundColor Cyan
Write-Host "CODEX_HOME=$codexHome"
Write-Host "WORKDIR=$workdir"
Write-Host "RUNTIME=$runtime"
Write-Host "MODEL=$configuredModel"
Write-Host ""

if ([Console]::IsInputRedirected -or [Console]::IsOutputRedirected) {
    throw "CODEX_S_INTERACTIVE_TERMINAL_REQUIRED"
}

& $codexCommand.Source --cd $workdir --dangerously-bypass-approvals-and-sandbox
$exitCode = $LASTEXITCODE
if ($null -eq $exitCode) {
    $exitCode = 0
}
if ($exitCode -ne 0) {
    throw "CODEX_S_LAUNCH_FAILED: codex exited with $exitCode"
}
